export default {
  appUrl: 'http://localhost:3000',
  apiEndpoint: 'http://localhost:8000/api',
};

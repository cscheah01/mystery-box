import {
  postRequest,
  getRequest,
  patchRequest,
  deleteRequest,
  multipartPatchRequest,
} from '../utils/apiHelper';
import config from '../../config';

export const getShippingAddressDetails = () => {
  return getRequest(`${config.apiEndpoint}/user/shipping_address`);
};

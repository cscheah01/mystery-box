import {
  postRequest,
  getRequest,
  deleteRequest,
  multipartPostRequest,
  multipartPatchRequest,
} from '../utils/apiHelper';
import config from '../../config';

export const createBox = (data) => {
  return multipartPostRequest(`${config.apiEndpoint}/admin/box`, data);
};

export const getBoxDetails = (data) => {
  return getRequest(`${config.apiEndpoint}/admin/box/${data.id}`);
};

export const updateBox = (id, data) => {
  return multipartPatchRequest(`${config.apiEndpoint}/admin/box/${id}`, data);
};

export const getBoxList = (data) => {
  return postRequest(`${config.apiEndpoint}/admin/box/table-list`, data);
};

export const deleteBox = (data) => {
  return deleteRequest(`${config.apiEndpoint}/admin/box/${data.id}`);
};

export const getAllBox = (data) => {
  return postRequest(`${config.apiEndpoint}/box-list`, data);
};

export const getSingleBoxDetails = (data) => {
  return getRequest(`${config.apiEndpoint}/box-details/${data.id}`);
};

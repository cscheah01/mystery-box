import { postRequest, deleteRequest, getRequest } from '../utils/apiHelper';
import config from '../../config';

export const getBoxItemList = (data) => {
  return postRequest(`${config.apiEndpoint}/admin/box-item/table-list`, data);
};

export const deleteBoxItem = (data) => {
  return deleteRequest(`${config.apiEndpoint}/admin/box-item/${data.id}`);
};

export const getBoxItem = (data) => {
  return getRequest(`${config.apiEndpoint}/admin/box-item/${data.id}`);
};

export const getAllBoxItem = (data) => {
  return getRequest(`${config.apiEndpoint}/items/${data.id}`);
};

import {
  postRequest,
  getRequest,
  patchRequest,
  deleteRequest,
  multipartPatchRequest,
} from '../utils/apiHelper';
import config from '../../config';

export const getProfileDetails = () => {
  return getRequest(`${config.apiEndpoint}/user/profile`);
};

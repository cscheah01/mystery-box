import {
  postRequest,
  getRequest,
  deleteRequest,
  multipartPostRequest,
  multipartPatchRequest,
} from '../utils/apiHelper';
import config from '../../config';

export const createProduct = (data) => {
  return multipartPostRequest(`${config.apiEndpoint}/admin/product`, data);
};

export const getProductDetails = (data) => {
  return getRequest(`${config.apiEndpoint}/admin/product/${data.id}`);
};

export const updateProduct = (id, data) => {
  return multipartPatchRequest(
    `${config.apiEndpoint}/admin/product/${id}`,
    data
  );
};

export const getProductList = (data) => {
  return postRequest(`${config.apiEndpoint}/admin/product/table-list`, data);
};

export const deleteProduct = (data) => {
  return deleteRequest(`${config.apiEndpoint}/admin/product/${data.id}`);
};

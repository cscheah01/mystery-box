import {
  postRequest,
  getRequest,
  patchRequest,
  deleteRequest,
} from '../utils/apiHelper';
import config from '../../config';

export const createProductCategory = (data) => {
  return postRequest(`${config.apiEndpoint}/admin/product-category`, {
    name: data.name,
  });
};

export const getProductCategoryDetails = (data) => {
  return getRequest(`${config.apiEndpoint}/admin/product-category/${data.id}`);
};

export const updateProductCategory = (data) => {
  return patchRequest(
    `${config.apiEndpoint}/admin/product-category/${data.id}`,
    {
      name: data.name,
    }
  );
};

export const getProductCategoryList = (data) => {
  return postRequest(
    `${config.apiEndpoint}/admin/product-category/table-list`,
    data
  );
};

export const deleteProductCategory = (data) => {
  return deleteRequest(
    `${config.apiEndpoint}/admin/product-category/${data.id}`
  );
};

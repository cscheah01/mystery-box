import {
  postRequest,
  getRequest,
  patchRequest,
  deleteRequest,
} from '../utils/apiHelper';
import config from '../../config';

export const createStaff = (data) => {
  return postRequest(`${config.apiEndpoint}/admin/staff`, {
    name: data.name,
    email: data.email,
    password: data.password,
  });
};

export const getStaffDetails = (data) => {
  return getRequest(`${config.apiEndpoint}/admin/staff/${data.id}`);
};

export const updateStaff = (data) => {
  return patchRequest(`${config.apiEndpoint}/admin/staff/${data.id}`, {
    name: data.name,
    email: data.email,
    password: data.password,
  });
};

export const getStaffList = (data) => {
  return postRequest(`${config.apiEndpoint}/admin/staff/table-list`, data);
};

export const deleteStaff = (data) => {
  return deleteRequest(`${config.apiEndpoint}/admin/staff/${data.id}`);
};

import {
  postRequest,
  getRequest,
  patchRequest,
  deleteRequest,
} from '../utils/apiHelper';
import config from '../../config';

export const createBoxCategory = (data) => {
  return postRequest(`${config.apiEndpoint}/admin/box-category`, {
    name: data.name,
  });
};

export const getBoxCategoryDetails = (data) => {
  return getRequest(`${config.apiEndpoint}/admin/box-category/${data.id}`);
};

export const updateBoxCategory = (data) => {
  return patchRequest(`${config.apiEndpoint}/admin/box-category/${data.id}`, {
    name: data.name,
  });
};

export const getBoxCategoryList = (data) => {
  return postRequest(
    `${config.apiEndpoint}/admin/box-category/table-list`,
    data
  );
};

export const deleteBoxCategory = (data) => {
  return deleteRequest(`${config.apiEndpoint}/admin/box-category/${data.id}`);
};

export const getAllBoxCategory = () => {
  return getRequest(`${config.apiEndpoint}/box-category-list`);
};

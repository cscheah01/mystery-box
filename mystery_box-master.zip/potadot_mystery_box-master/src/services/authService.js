import { postRequest } from '../utils/apiHelper';
import config from '../../config';

export const login = (data) => {
  return postRequest(`${config.apiEndpoint}/login`, {
    email: data.email,
    password: data.password,
  });
};

export const logout = () => {
  return postRequest(`${config.apiEndpoint}/logout`);
};

import axios from 'axios';
import config from '../../config';

export default (GetServerSidePropsFunction) => async (ctx) => {
  const token = ctx.req.cookies?.jwt || null;

  const response = await axios
    .get(`${config.apiEndpoint}/profile`, {
      headers: { Authorization: `Bearer ${token}` },
    })
    .catch((err) => err.response);

  const responseData = response.data;

  if (!responseData.success) {
    return {
      redirect: {
        destination: 'admin/login',
        permanent: false,
      },
    };
  }

  return await GetServerSidePropsFunction(ctx);
};

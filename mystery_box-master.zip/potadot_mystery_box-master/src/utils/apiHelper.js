import axios from 'axios';
import config from '../../config';

const getToken = async () => {
  const response = await axios.get(`${config.appUrl}/api/get-token`);

  return response.data.token;
};

export const getRequest = async (url) => {
  const token = await getToken();

  const response = await axios
    .get(url, { headers: { Authorization: `Bearer ${token}` } })
    .catch((err) => err.response);

  return response;
};

export const postRequest = async (url, data) => {
  const token = await getToken();

  const response = await axios
    .post(url, data, { headers: { Authorization: `Bearer ${token}` } })
    .catch((err) => err.response);

  return response;
};

export const multipartPostRequest = async (url, data) => {
  const token = await getToken();

  const response = await axios
    .post(url, data, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'multipart/form-data',
      },
    })
    .catch((err) => err.response);

  return response;
};

export const patchRequest = async (url, data) => {
  const token = await getToken();

  const response = await axios
    .patch(url, data, { headers: { Authorization: `Bearer ${token}` } })
    .catch((err) => err.response);

  return response;
};

export const multipartPatchRequest = async (url, data) => {
  const token = await getToken();

  data.append('_method', 'PATCH');

  const response = await axios
    .post(url, data, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'multipart/form-data',
      },
    })
    .catch((err) => err.response);

  return response;
};

export const deleteRequest = async (url) => {
  const token = await getToken();

  const response = await axios
    .delete(url, { headers: { Authorization: `Bearer ${token}` } })
    .catch((err) => err.response);

  return response;
};

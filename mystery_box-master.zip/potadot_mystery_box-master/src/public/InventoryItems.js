import React, { useState } from 'react';
import { Box, Grid, Typography } from '@mui/material';
import shoe from '../assets/img/Shoe.png';
import emptyImage from '../assets/img/empty-image.png';
import Image from 'next/image';

export default function InventoryItems() {
  const [src, setSrc] = useState(shoe);
  return (
    <Box
      sx={{
        bgcolor: '#4d4d4d',
        border: 0.5,
        borderColor: '#646262',
        borderRadius: 2,
        mb: 5,
        p: 1,
      }}
    >
      <Grid container>
        <Grid
          item
          xs={12}
          sx={{
            mb: 2,
          }}
        >
          <Box
            sx={{
              width: { xs: '100px', lg: '150px' },
              height: { xs: '100px', lg: '150px' },
              position: 'relative',
              margin: 'auto',
              overflow: 'hidden',
            }}
          >
            <Image
              src={src}
              layout="fill"
              objectFit="cover"
              onError={() => setSrc(emptyImage)}
            />
          </Box>
        </Grid>
        <Grid item xs={12}>
          <Typography
            variant="h6"
            sx={{
              fontWeight: 'bold',
              color: '#ffffff',
              textAlign: 'center',
              mt: 2,
            }}
          >
            RM 1000.00
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography
            noWrap
            variant="h6"
            sx={{ fontWeight: 'bold', color: '#ff9800', textAlign: 'center' }}
          >
            Shoe 1
          </Typography>
        </Grid>
      </Grid>
    </Box>
  );
}

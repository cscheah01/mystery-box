import React from 'react';
import { Box, Typography } from '@mui/material';
import Image from 'next/image';
import mysteryBox from '../../../assets/img/mystery-box.png';

export default function Items({ isSpinning, winningIndex }) {
  let numbers = [...Array(15).keys()];
  let output = [];
  for (var i = 0; i < 10; i++) {
    output.push(...numbers);
  }

  let style = {
    transition: 'all 5000ms cubic-bezier(0, 0, 0.28, 1) 0s',
    transform: 'matrix(1, 0, 0, 1, ' + winningIndex * -1 + ', 0)',
  };

  return (
    <>
      <Box sx={{ overflow: 'hidden' }}>
        <Box
          style={isSpinning ? style : null}
          sx={{
            display: 'inline-flex',
            transform: 'matrix(1, 0, 0, 1, -93, 0)',
          }}
        >
          {output.map((number, index) => {
            return (
              <Box
                key={index}
                sx={{
                  bgcolor: 'grey.900',
                  border: 0.5,
                  borderColor: '#646262',
                  py: 2,
                  px: 1,
                  mx: 1,
                }}
              >
                <Box
                  sx={{
                    position: 'relative',
                    width: '150px',
                    height: '150px',
                    mb: 2,
                  }}
                >
                  <Image src={mysteryBox} layout="fill" objectFit="cover" />
                </Box>

                <Typography
                  sx={{
                    fontWeight: 'bold',
                    textAlign: 'center',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    display: '-webkit-box',
                    WebkitLineClamp: '1',
                    WebkitBoxOrient: 'vertical',
                  }}
                  color="common.white"
                >
                  Item {number}
                </Typography>
              </Box>
            );
          })}
        </Box>
      </Box>
    </>
  );
}

import React, { useState } from 'react';
import Items from './Items';
import useSound from 'use-sound';
import { Box, Button } from '@mui/material';

export default function Roulette() {
  // const [lastWin, setLastWin] = useState('');
  const [isSpinning, setIsSpinning] = useState(false);
  const [winningIndex, setWinningIndex] = useState('');

  const create_obj = () => {
    let obj = {};
    for (let i = 0; i < 15; i++) {
      if (i === 0) {
        obj[i] = [5980, 6035];
      } else {
        let last = obj[i - 1][1];
        obj[i] = [
          Math.round((last + 20) * 100) / 100,
          Math.round((last + 20 + 55) * 100) / 100,
        ];
      }
    }
    return obj;
  };

  const pick_random_number = (obj) => {
    let keys = Object.keys(obj);
    let random_key = keys[(keys.length * Math.random()) << 0];
    let range_arr = obj[random_key];
    let random_offset =
      Math.random() * (range_arr[1] - range_arr[0]) + range_arr[0];
    return random_offset;
  };

  const getResult = (chosen, obj) => {
    for (var key in obj) {
      if (obj[key][0] <= chosen && obj[key][1] >= chosen) {
        return key;
      }
    }
  };

  const [spinningSound] = useSound('/audio/spinning.mp3');
  const [spinningEndSound] = useSound('/audio/spinning-end.mp3');

  const spin = () => {
    const number_obj = create_obj();
    const chosen_number = pick_random_number(number_obj);
    const result = getResult(chosen_number, number_obj);

    setIsSpinning(true);
    setWinningIndex(chosen_number);
    spinningSound();

    setTimeout(() => {
      setIsSpinning(false);
      // setLastWin(result);
      spinningEndSound();

      clearTimeout();
    }, 5500);
    return result;
  };

  return (
    <>
      <Box sx={{ position: 'relative', py: 2 }}>
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            left: 'calc(50% - 2.5px)',
            zIndex: 100,
            width: '3px',
            height: '100%',
            backgroundColor: 'common.white',
            display: 'block',
          }}
        />
        <Items isSpinning={isSpinning} winningIndex={winningIndex} />
      </Box>

      <Box sx={{ textAlign: 'center', mt: 5, mb: 10 }}>
        <Button
          variant="contained"
          onClick={() => {
            spin();
          }}
        >
          TRY FOR FREE
        </Button>
      </Box>
    </>
  );
}

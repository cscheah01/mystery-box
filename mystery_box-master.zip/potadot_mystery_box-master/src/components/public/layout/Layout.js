import React from 'react';
import { ThemeProvider, Box } from '@mui/material';
import theme from '../../../theme';
import Header from './Header';
import Footer from './Footer';

export default function Layout({ children }) {
  return (
    <ThemeProvider theme={theme}>
      <Box paddingBottom={5} bgcolor="#000000">
        <Header />
        {children}
      </Box>
      <Footer />
    </ThemeProvider>
  );
}

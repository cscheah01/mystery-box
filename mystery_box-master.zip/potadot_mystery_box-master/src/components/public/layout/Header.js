import React, { useState } from 'react';
import {
  AppBar,
  Grid,
  Box,
  Toolbar,
  IconButton,
  Typography,
  Menu,
  Container,
  Button,
  MenuItem,
} from '@mui/material';

import MenuIcon from '@mui/icons-material/Menu';
import AdbIcon from '@mui/icons-material/Adb';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import GTranslateIcon from '@mui/icons-material/GTranslate';
import ErrorIcon from '@mui/icons-material/Error';
import PersonIcon from '@mui/icons-material/Person';
import PersonAddAltIcon from '@mui/icons-material/PersonAddAlt';
import GroupsIcon from '@mui/icons-material/Groups';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';
import CardGiftcardIcon from '@mui/icons-material/CardGiftcard';
import Link from 'next/link';
import logo from '../../../assets/img/logo-transparent.png';
import Image from 'next/image';

const pages = [
  'Mystery Boxes',
  'Promo Boxes',
  'Affiliates',
  'Change Language',
  'How It Works',
];
const languages = ['English'];

export default function Header() {
  const [anchorElNav, setAnchorElNav] = useState(null);
  const [anchorElLanguage, setAnchorElLanguage] = useState(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };
  const handleOpenLanguageMenu = (event) => {
    setAnchorElLanguage(event.currentTarget);
  };
  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };
  const handleCloseLanguageMenu = () => {
    setAnchorElLanguage(null);
  };

  return (
    <AppBar position="fixed">
      <Box
        sx={{
          display: 'flex',
          backgroundColor: '#000000',
          px: { xs: 1, md: 8, lg: 15, xl: 22 },
          alignItems: 'center',
        }}
      >
        <Box
          sx={{
            flexGrow: 1,
            display: { xs: 'none', md: 'flex' },
            alignItems: 'center',
          }}
        >
          <Button
            onClick={handleOpenLanguageMenu}
            sx={{ mr: 2, color: '#ffffff' }}
            startIcon={<GTranslateIcon sx={{ fontSize: 18 }} />}
          >
            <Typography
              variant="caption"
              sx={{ fontWeight: 'bold', lineHeight: 0 }}
            >
              ENGLISH
            </Typography>
            <KeyboardArrowDownIcon />
          </Button>
          <Menu
            sx={{ mt: '35px' }}
            id="menu-appbar"
            anchorEl={anchorElLanguage}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            keepMounted
            transformOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            open={Boolean(anchorElLanguage)}
            onClose={handleCloseLanguageMenu}
          >
            {languages.map((language) => (
              <MenuItem key={language} onClick={handleCloseLanguageMenu}>
                <Typography textAlign="center">{language}</Typography>
              </MenuItem>
            ))}
          </Menu>

          <ErrorIcon sx={{ mr: 1 }} />
          <Typography
            variant="caption"
            sx={{ fontWeight: 'bold', lineHeight: 0 }}
          >
            HOW IT WORKS
          </Typography>
        </Box>
        <Box
          sx={{
            display: 'flex',
            flexGrow: { xs: 1, md: 0 },
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Link passHref href={'login'}>
            <Button
              sx={{ color: '#ffffff', mr: 2, fontWeight: 'bold' }}
              startIcon={<PersonIcon />}
            >
              Login
            </Button>
          </Link>
          <Link passHref href={'register'}>
            <Button
              sx={{ color: '#ffffff', fontWeight: 'bold' }}
              startIcon={<PersonAddAltIcon />}
            >
              Register
            </Button>
          </Link>
        </Box>
      </Box>

      <Container
        maxWidth={false}
        sx={{
          '&': {
            p: 0,
          },
        }}
      >
        <Toolbar disableGutters sx={{ px: { xs: 2.2, md: 8, lg: 15, xl: 22 } }}>
          <Box sx={{ display: { xs: 'none', md: 'flex' } }}>
            <Image src={logo} width="180" height="50" layout={'fixed'} />
          </Box>

          <Box sx={{ flexGrow: 1, display: { xs: 'flex', md: 'none' } }}>
            <IconButton
              size="large"
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleOpenNavMenu}
              color="inherit"
            >
              <MenuIcon />
            </IconButton>
            <Menu
              id="menu-appbar"
              anchorEl={anchorElNav}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
              open={Boolean(anchorElNav)}
              onClose={handleCloseNavMenu}
              sx={{
                display: { xs: 'block', md: 'none' },
              }}
            >
              {pages.map((page) => (
                <MenuItem key={page} onClick={handleCloseNavMenu}>
                  <Typography textAlign="center">{page}</Typography>
                </MenuItem>
              ))}
            </Menu>
          </Box>

          <Box sx={{ flexGrow: 1, display: { xs: 'flex', md: 'none' } }}>
            <Image src={logo} width="180" height="50" layout={'fixed'} />
          </Box>

          <Box
            sx={{
              flexGrow: 1,
              my: 3,
              alignItems: 'center',
              display: { xs: 'none', md: 'flex' },
              ml: 5,
            }}
          >
            <Grid container columnSpacing={4}>
              <Grid item>
                <Link passHref href={'/'}>
                  <Button
                    sx={{ color: '#ffffff', fontWeight: 'bold' }}
                    startIcon={<CardGiftcardIcon sx={{ color: '#3f51b5' }} />}
                  >
                    <Typography sx={{ fontWeight: 'bold', lineHeight: 0 }}>
                      MYSTERY BOXES
                    </Typography>
                  </Button>
                </Link>
              </Grid>
              <Grid item>
                <Link passHref href={'/'}>
                  <Button
                    sx={{ color: '#ffffff', fontWeight: 'bold' }}
                    startIcon={<LocalOfferIcon sx={{ color: '#3f51b5' }} />}
                  >
                    <Typography sx={{ fontWeight: 'bold', lineHeight: 0 }}>
                      PROMO BOXES
                    </Typography>
                  </Button>
                </Link>
              </Grid>
              <Grid item>
                <Link passHref href={'/'}>
                  <Button
                    sx={{ color: '#ffffff', fontWeight: 'bold' }}
                    startIcon={<GroupsIcon sx={{ color: '#3f51b5' }} />}
                  >
                    <Typography sx={{ fontWeight: 'bold', lineHeight: 0 }}>
                      AFFILIATES
                    </Typography>
                  </Button>
                </Link>
              </Grid>
            </Grid>
          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
}

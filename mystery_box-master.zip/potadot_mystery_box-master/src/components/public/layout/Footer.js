import React from 'react';
import { Box, Grid, Typography } from '@mui/material';

import AdbIcon from '@mui/icons-material/Adb';
import FacebookOutlinedIcon from '@mui/icons-material/FacebookOutlined';
import visaLogo from '../../../assets/img/visa-logo.png';
import masterLogo from '../../../assets/img/master-logo.png';
import Image from 'next/image';
import Link from 'next/link';

export default function Layout() {
  return (
    <footer>
      <Box bgcolor="grey.900" color="#ffffff">
        <Box paddingX={{ xs: 4, sm: 6, md: 8.6, lg: 15, xl: 22 }} paddingTop={10}>
          <Grid
            container
            columnSpacing={{ xs: 1, sm: 1, md: 10 }}
            sx={{
              display: 'flex',
            }}
          >
            <Grid item xs={12} md={3}>
              <Grid container>
                <Grid
                  item
                  xs={12}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: { xs: 'center', md: 'left' },
                    mb: 5,
                  }}
                >
                  <AdbIcon sx={{ mr: 1 }} />
                  <Typography
                    variant="h6"
                    sx={{
                      fontFamily: 'monospace',
                      fontWeight: 700,
                    }}
                  >
                    LOGO
                  </Typography>
                </Grid>
                <Grid
                  item
                  xs={12}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    mb: 2,
                    justifyContent: { xs: 'center', md: 'left' },
                  }}
                >
                  <Typography
                    variant="subtitle2"
                    sx={{
                      fontWeight: 700,
                    }}
                  >
                    COMPANY NAME
                  </Typography>
                </Grid>
                <Grid
                  item
                  xs={12}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    textAlign: { xs: 'center', md: 'left' },
                    mb: { xs: 5, md: 3 },
                  }}
                >
                  <Typography
                    fontSize={12}
                    sx={{
                      fontWeight: 700,
                    }}
                  >
                    It has survived not only five centuries, but also the leap
                    into electronic typesetting, remaining essentially
                    unchanged. It was popularised in the 1960s with the release
                    of Letraset sheets containing Lorem Ipsum passages, and more
                    recently with desktop publishing software like Aldus
                    PageMaker including versions of Lorem Ipsum.
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={12} md={3}>
              <Grid container>
                <Grid
                  item
                  xs={12}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    mb: 2,
                  }}
                >
                  <Typography
                    variant="body1"
                    sx={{
                      mr: 2,
                      display: 'flex',
                      fontWeight: 700,
                      color: 'inherit',
                      textDecoration: 'none',
                      fontWeight: 'bold',
                    }}
                  >
                    SOCIAL MEDIA
                  </Typography>
                </Grid>
                <Grid
                  item
                  xs={12}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    mb: { xs: 5, md: 0 },
                  }}
                >
                  <FacebookOutlinedIcon sx={{ mr: 1 }} />
                  <Typography variant="subtitle2">
                    <Link href={'/'} passHref>
                      <a
                        style={{
                          color: '#ffffff',
                          fontWeight: 700,
                          textDecoration: 'none',
                        }}
                      >
                        www.facebook.com
                      </a>
                    </Link>
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={12} md={3}>
              <Grid container>
                <Grid
                  item
                  xs={12}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    mt: { xs: 3, md: 0 },
                    mb: 2,
                  }}
                >
                  <Typography
                    variant="body1"
                    sx={{
                      fontWeight: 700,
                    }}
                  >
                    NAVIGATION LINKS
                  </Typography>
                </Grid>
                <Grid
                  item
                  xs={12}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    mb: 2,
                  }}
                >
                  <Typography variant="subtitle2">
                    <Link href={'/'} passHref>
                      <a
                        style={{
                          color: '#ffffff',
                          fontWeight: 700,
                          textDecoration: 'none',
                        }}
                      >
                        FAQ
                      </a>
                    </Link>
                  </Typography>
                </Grid>
                <Grid
                  item
                  xs={12}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    mb: 2,
                  }}
                >
                  <Typography variant="subtitle2">
                    <Link href={'/'} passHref>
                      <a
                        style={{
                          color: '#ffffff',
                          fontWeight: 700,
                          textDecoration: 'none',
                        }}
                      >
                        Contact Us
                      </a>
                    </Link>
                  </Typography>
                </Grid>
                <Grid
                  item
                  xs={12}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    mb: 2,
                  }}
                >
                  <Typography variant="subtitle2">
                    <Link href={'/'} passHref>
                      <a
                        style={{
                          color: '#ffffff',
                          fontWeight: 700,
                          textDecoration: 'none',
                        }}
                      >
                        Shipping & Refund
                      </a>
                    </Link>
                  </Typography>
                </Grid>
                <Grid
                  item
                  xs={12}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    mb: 2,
                  }}
                >
                  <Typography variant="subtitle2">
                    <Link href={'/'} passHref>
                      <a
                        style={{
                          color: '#ffffff',
                          fontWeight: 700,
                          textDecoration: 'none',
                        }}
                      >
                        Term of Service
                      </a>
                    </Link>
                  </Typography>
                </Grid>
                <Grid
                  item
                  xs={12}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    mb: { xs: 5, md: 0 },
                  }}
                >
                  <Typography variant="subtitle2">
                    <Link href={'/'} passHref>
                      <a
                        style={{
                          color: '#ffffff',
                          fontWeight: 700,
                          textDecoration: 'none',
                        }}
                      >
                        Privacy
                      </a>
                    </Link>
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={12} md={3}>
              <Grid container>
                <Grid
                  item
                  xs={12}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    mt: { xs: 3, md: 0 },
                    mb: 2,
                  }}
                >
                  <Typography
                    variant="body1"
                    sx={{
                      fontWeight: 700,
                    }}
                  >
                    PAYMENT OPTION
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Image src={visaLogo} objectFit="contain" width={'100%'} />
                </Grid>
                <Grid item xs={12}>
                  <Image src={masterLogo} objectFit="contain" width={'100%'} />
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Box>
        <Box
          sx={{
            display: 'flex',
            backgroundColor: '#000000',
            px: { xs: 2, md: 15, lg: 22 },
            py: 1,
            justifyContent: { xs: 'center', md: 'left' },
            alignItems: 'center',
          }}
        >
          <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>
            © 2022 Potadot Web & System Solutions PLT All Right Reserved.
          </Typography>
        </Box>
      </Box>
    </footer>
  );
}

import React, { useState } from 'react';
import { Box, Grid, Typography, Button } from '@mui/material';
import emptyImage from '../../../assets/img/empty-image.png';
import Image from 'next/image';
import Link from 'next/link';

export default function SingleBox({ data }) {
  const [src, setSrc] = useState(data.image);

  return (
    <Box
      sx={{
        p: 2,
        bgcolor: 'grey.900',
        border: 0.5,
        borderColor: '#646262',
        mb: { xs: 5 },
      }}
    >
      <Grid container>
        <Grid
          item
          xs={12}
          sx={{
            mb: 2,
          }}
        >
          <Box
            sx={{
              width: { xs: '100px', lg: '150px' },
              height: { xs: '100px', lg: '150px' },
              position: 'relative',
              margin: 'auto',
              overflow: 'hidden',
            }}
          >
            <Image
              src={src}
              layout="fill"
              objectFit="cover"
              onError={() => setSrc(emptyImage)}
            />
          </Box>
        </Grid>
        <Grid item xs={12}>
          <Typography
            noWrap
            variant="h6"
            sx={{
              fontWeight: 'bold',
              color: '#ff9800',
              textAlign: 'center',
              fontSize: { xs: 14, md: 18 },
            }}
          >
            {data.name}
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography
            variant="h6"
            sx={{
              fontWeight: 'bold',
              color: '#ffffff',
              textAlign: 'center',
              fontSize: { xs: 14, md: 18 },
            }}
          >
            RM {data.price}
          </Typography>
        </Grid>
        <Grid item xs={12} sx={{ textAlign: 'center' }}>
          <Link
            href={`/single-box/${data.id}`}
            passHref
            sx={{ textDecoration: 'none' }}
          >
            <Button
              variant="contained"
              sx={{
                mt: 1,
                mb: -6,
                borderRadius: '30px',
                fontSize: { xs: 12, md: 14 },
              }}
            >
              UnBox Now
            </Button>
          </Link>
        </Grid>
      </Grid>
    </Box>
  );
}

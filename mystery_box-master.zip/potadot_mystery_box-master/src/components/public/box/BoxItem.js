import React, { useState } from 'react';
import { Box, Grid, Typography } from '@mui/material';
import emptyImage from '../../../assets/img/empty-image.png';
import Image from 'next/image';

export default function BoxItem({ data }) {
  const [src, setSrc] = useState(data.image);
  return (
    <Box
      key={data.id}
      sx={{
        bgcolor: 'grey.900',
        border: 0.5,
        borderColor: '#646262',
        borderRadius: 5,
        mb: 5,
        p: 1,
      }}
    >
      <Grid container>
        <Grid item xs={6} sx={{ mb: 2 }}>
          <Typography
            noWrap
            sx={{
              fontWeight: 'bold',
              color: '#ffffff',
              textAlign: 'left',
              pl: 1,
              fontSize: { xs: 14, md: 16 },
            }}
          >
            {data.product_category}
          </Typography>
        </Grid>
        <Grid item xs={6}>
          <Typography
            sx={{
              fontWeight: 'bold',
              color: '#ffffff',
              textAlign: 'end',
              pr: 1,
              fontSize: { xs: 14, md: 16 },
            }}
          >
            0.02%
          </Typography>
        </Grid>
        <Grid
          item
          xs={12}
          sx={{
            mb: 2,
          }}
        >
          <Box
            sx={{
              width: { xs: '100px', md: '150px' },
              height: { xs: '100px', md: '150px' },
              position: 'relative',
              margin: 'auto',
              overflow: 'hidden',
            }}
          >
            <Image
              src={src}
              layout="fill"
              objectFit="cover"
              onError={() => setSrc(emptyImage)}
            />
          </Box>
        </Grid>
        <Grid item xs={12}>
          <Typography
            variant="h6"
            noWrap
            sx={{
              fontWeight: 'bold',
              color: '#ff9800',
              textAlign: 'center',
              fontSize: { xs: 14, md: 18 },
            }}
          >
            {data.name}
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography
            variant="h6"
            sx={{
              fontWeight: 'bold',
              color: '#ffffff',
              textAlign: 'center',
              fontSize: { xs: 14, md: 18 },
            }}
          >
            RM {data.price}
          </Typography>
        </Grid>
      </Grid>
    </Box>
  );
}

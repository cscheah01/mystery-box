import React, { useState, useEffect } from 'react';
import { TextField, Card, CardContent, CardActions, Grid } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useSnackbar } from 'notistack';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/material.css';

export default function ShippingInformationForm({ data, onSubmit }) {
  const { enqueueSnackbar } = useSnackbar();

  const phoneRegExp =
    /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

  const formik = useFormik({
    initialValues: {
      name: '',
      phone_number: '',
      address: '',
      state: '',
      city: '',
      postcode: '',
      ...data,
    },
    validationSchema: Yup.object({
      name: Yup.string().required(),
      phone_number: Yup.string().matches(
        phoneRegExp,
        'Phone number is not valid'
      ),
      address: Yup.string().required(),
      state: Yup.string().required(),
      city: Yup.string().required(),
      postcode: Yup.string().required(),
    }),
    onSubmit: async (values, { setErrors }) => {
      const response = await onSubmit(values);

      const responseData = response.data;

      if (responseData.success) {
        enqueueSnackbar(responseData.message, {
          variant: 'success',
          autoHideDuration: 3000,
        });
      } else if (response.status == 422) {
        enqueueSnackbar('Please check your input.', {
          variant: 'error',
          autoHideDuration: 3000,
        });

        setErrors(responseData.message);
      }
    },
  });

  const onSubmitClick = () => {
    if (Object.keys(formik.errors).length > 0) {
      enqueueSnackbar('Please check your input.', {
        variant: 'error',
        autoHideDuration: 3000,
      });
    }
  };

  const [borderPhoneNumberField, setBorderPhoneNumberField] = useState(false);
  useEffect(() => {
    if (formik.errors.phone_number != null) {
      setBorderPhoneNumberField('#f44336');
    } else {
      setBorderPhoneNumberField('#ffffff3b');
    }
  }, [formik.errors.phone_number]);

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Card>
          <CardContent>
            <Grid container spacing={2} sx={{ pt: 2 }}>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Full Name"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="name"
                  value={formik.values.name}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(formik.touched.name && formik.errors.name)}
                  helperText={formik.touched.name && formik.errors.name}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <PhoneInput
                  containerStyle={{
                    color: '#ffffff',
                    marginTop: 2,
                    marginBottom: 1,
                  }}
                  inputStyle={{
                    backgroundColor: '#1e1e1e',
                    color: '#ffffff',
                    width: '100%',
                    borderColor: borderPhoneNumberField,
                  }}
                  dropdownStyle={{ color: '#000000' }}
                  value={formik.values.phone_number}
                  onChange={(phone) => {
                    formik.values.phone_number = phone;
                    formik.errors.phone_number = null;
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  label="Address"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="text"
                  rows={3}
                  multiline
                  value={formik.values.address}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(formik.touched.address && formik.errors.address)}
                  helperText={formik.touched.address && formik.errors.address}
                />
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField
                  label="State"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="state"
                  value={formik.values.state}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(formik.touched.state && formik.errors.state)}
                  helperText={formik.touched.state && formik.errors.state}
                />
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField
                  label="City"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="city"
                  value={formik.values.city}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(formik.touched.city && formik.errors.city)}
                  helperText={formik.touched.city && formik.errors.city}
                />
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField
                  label="Postcode"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="postcode"
                  value={formik.values.postcode}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(
                    formik.touched.postcode && formik.errors.postcode
                  )}
                  helperText={formik.touched.postcode && formik.errors.postcode}
                />
              </Grid>
            </Grid>
          </CardContent>
          <CardActions>
            <Grid container spacing={1} justifyContent="center">
              <Grid item sx={{ pb: 2 }}>
                <LoadingButton
                  variant="contained"
                  type="submit"
                  loading={formik.isSubmitting}
                  disabled={formik.isSubmitting}
                  onClick={() => {
                    onSubmitClick();
                  }}
                >
                  Save Change
                </LoadingButton>
              </Grid>
            </Grid>
          </CardActions>
        </Card>
      </form>
    </>
  );
}

import React, { useEffect, useState } from "react";
import {
  TextField,
  Card,
  CardContent,
  CardActions,
  Grid,
  Typography,
  Button,
  Box,
  FormGroup,
  Divider,
} from "@mui/material";
import LoadingButton from "@mui/lab/LoadingButton";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useSnackbar } from "notistack";
import Image from "next/image";
import emptyImage from "../../../../assets/img/empty-image.png";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/material.css";

export default function AccountDetailsForm({ data, onSubmit }) {
  const { enqueueSnackbar } = useSnackbar();
  const [profileImage, setProfileImage] = useState();
  const [profileImageURL, setProfileImageURL] = useState(null);

  const supportedFormats = ["image/jpg", "image/jpeg", "image/png"];
  const phoneRegExp =
    /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;
  const formik = useFormik({
    initialValues: {
      name: "",
      phone_number: "",
      email: "",
      image: "",
      bank_name: "",
      bank_account_number: "",
      bank_account_name: "",
      ...data,
    },
    validationSchema: Yup.object({
      name: Yup.string().required(),
      email: Yup.string().required().email(),
      phone_number: Yup.string()
        .nullable()
        .matches(phoneRegExp, "Phone number is not valid"),
      bank_name: Yup.string().nullable(),
      bank_account_number: Yup.string().nullable(),
      bank_account_name: Yup.string().nullable(),
    }),
    onSubmit: async (values, { setErrors }) => {
      const formData = new FormData();

      // if (values.image != '') {
      //   formData.append('image', values.image);
      // }

      // formData.append('name', values.name);
      // formData.append('email', values.email);
      // if (values.phone_number != '') {
      //   formData.append('phone_number', values.phone_number);
      // }
      // if (values.bank_name != null) {
      //   formData.append('bank_name', values.bank_name);
      // }
      // if (values.bank_account_number != null) {
      //   formData.append('bank_account_number', values.bank_account_number);
      // }
      // if (values.bank_account_name != null) {
      //   formData.append('bank_account_name', values.bank_account_name);
      // }

      // const response = await onSubmit(formData);

      const responseData = response.data;

      if (responseData.success) {
        enqueueSnackbar(responseData.message, {
          variant: "success",
          autoHideDuration: 3000,
        });
      } else if (response.status == 422) {
        enqueueSnackbar("Please check your input.", {
          variant: "error",
          autoHideDuration: 3000,
        });

        setErrors(responseData.message);
      }
    },
  });

  useEffect(() => {
    const file = profileImage;

    if (file) {
      formik.values.image = file;
      let reader = new FileReader();
      reader.onload = function (event) {
        setProfileImageURL(event.target.result);
      };
      reader.readAsDataURL(file);
    }
  }, [profileImage]);

  const onSubmitClick = () => {
    if (Object.keys(formik.errors).length > 0) {
      enqueueSnackbar("Please check your input.", {
        variant: "error",
        autoHideDuration: 3000,
      });
    }
  };

  const [borderPhoneNumberField, setBorderPhoneNumberField] = useState(false);
  useEffect(() => {
    if (formik.errors.phone_number != null) {
      setBorderPhoneNumberField("#f44336");
    } else {
      setBorderPhoneNumberField("#ffffff3b");
    }
  }, [formik.errors.phone_number]);

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Card>
          <CardContent>
            <Box sx={{ color: "#ffffff" }}>
              <Typography variant="h6">Account Details</Typography>
            </Box>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Box
                  sx={{
                    border: 2,
                    borderColor: "#9e9e9e",
                    borderRadius: 30,
                    margin: "auto",
                    width: "150px",
                    height: "150px",
                    position: "relative",
                    overflow: "hidden",
                    alignItems: "center",
                  }}
                >
                  {formik.values.image != "" ? (
                    <Image src={profileImageURL} layout="fill" />
                  ) : (
                    <Image src={emptyImage} layout="fill" />
                  )}
                </Box>
              </Grid>
              <Grid item xs={12}>
                <FormGroup>
                  <Box
                    sx={{
                      margin: "auto",
                      display: "flex",
                    }}
                  >
                    <Button variant="contained" component="label">
                      Upload File
                      <input
                        type="file"
                        hidden
                        name="image"
                        onChange={(e) => {
                          setProfileImage(e.target.files[0]);
                        }}
                      />
                    </Button>
                    <Typography
                      sx={{
                        display:
                          formik.errors.image != null &&
                          formik.touched.image != null
                            ? "block"
                            : "none",
                        color: "#D14343",
                        fontWeight: 400,
                        lineHeight: 1.66,
                        fontSize: "0.75rem",
                        mt: "3px",
                        mr: 2,
                        mb: 0,
                        ml: 2,
                        alignSelf: "center",
                      }}
                    >
                      {formik.errors.image}
                    </Typography>
                    <Typography
                      sx={{
                        ml: 2,
                        alignSelf: "center",
                        display: formik.values.image != "" ? "block" : "none",
                      }}
                    >
                      {formik.values.image != ""
                        ? formik.values.image.name
                        : formik.values.image}
                    </Typography>
                  </Box>
                </FormGroup>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Full Name"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="name"
                  value={formik.values.name}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(formik.touched.name && formik.errors.name)}
                  helperText={formik.touched.name && formik.errors.name}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <PhoneInput
                  containerStyle={{
                    color: "#ffffff",
                    marginTop: 2,
                    marginBottom: 1,
                  }}
                  inputStyle={{
                    backgroundColor: "#1e1e1e",
                    color: "#ffffff",
                    width: "100%",
                    borderColor: borderPhoneNumberField,
                  }}
                  dropdownStyle={{ color: "#000000" }}
                  value={formik.values.phone_number}
                  onChange={(phone) => {
                    formik.values.phone_number = phone;
                    formik.errors.phone_number = null;
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Email"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="email"
                  value={formik.values.email}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(formik.touched.email && formik.errors.email)}
                  helperText={formik.touched.email && formik.errors.email}
                />
              </Grid>
            </Grid>
            <Divider sx={{ my: 3 }} />
            <Box sx={{ pb: 2, color: "#ffffff" }}>
              <Typography variant="h6">Bank Details</Typography>
            </Box>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Bank Name"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="bank_name"
                  value={formik.values.bank_name}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(
                    formik.touched.bank_name && formik.errors.bank_name
                  )}
                  helperText={
                    formik.touched.bank_name && formik.errors.bank_name
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Account Name"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="bank_account_name"
                  value={formik.values.bank_account_name}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(
                    formik.touched.bank_account_name &&
                      formik.errors.bank_account_name
                  )}
                  helperText={
                    formik.touched.bank_account_name &&
                    formik.errors.bank_account_name
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Account Number"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="bank_account_number"
                  value={formik.values.bank_account_number}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(
                    formik.touched.bank_account_number &&
                      formik.errors.bank_account_number
                  )}
                  helperText={
                    formik.touched.bank_account_number &&
                    formik.errors.bank_account_number
                  }
                />
              </Grid>
            </Grid>
          </CardContent>
          <CardActions>
            <Grid container spacing={1} justifyContent="center">
              <Grid item sx={{ pb: 2 }}>
                <LoadingButton
                  variant="contained"
                  type="submit"
                  loading={formik.isSubmitting}
                  disabled={formik.isSubmitting}
                  onClick={() => {
                    onSubmitClick();
                  }}
                >
                  Save Change
                </LoadingButton>
              </Grid>
            </Grid>
          </CardActions>
        </Card>
      </form>
    </>
  );
}

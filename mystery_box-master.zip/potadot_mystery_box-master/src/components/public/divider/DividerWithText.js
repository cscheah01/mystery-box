import React from 'react';
import { Typography, Divider } from '@mui/material';

export default function Home({ text }) {
  return (
    <>
      <Divider
        sx={{
          '&::before,&::after': {
            borderTop: 7,
            borderColor: '#3f51b5',
          },
        }}
      >
        <Typography
          sx={{
            fontSize: { xs: '20px', md: '24px' },
            color: '#ffffff',
            fontWeight: 'bold',
            textAlign: 'center',
            px: { sm: 0, md: 4 },
          }}
        >
          {text}
        </Typography>
      </Divider>
    </>
  );
}

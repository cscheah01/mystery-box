import React from 'react';
import { Skeleton, Box } from '@mui/material';
import DividerWithText from '../divider/DividerWithText';

export default function PublicPageSkeleton() {
  return (
    <>
      <Box sx={{ px: { xs: 4, md: 8.5 }, paddingTop: 20 }}>
        <DividerWithText text={'LIST OF MYSTERY BOXES'} />
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'center',
          }}
        >
          <Box
            sx={{
              marginTop: '5%',
              width: '100%',
            }}
          >
            <Skeleton animation="wave" height={'100px'} width={'100%'} />
          </Box>
        </Box>

        <Box sx={{ my: 10 }}>
          <Skeleton animation="wave" height={'300px'} />
        </Box>
      </Box>
    </>
  );
}

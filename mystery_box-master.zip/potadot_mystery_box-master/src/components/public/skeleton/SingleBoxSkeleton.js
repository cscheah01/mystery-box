import React from 'react';
import { Skeleton, Box, Grid, Typography } from '@mui/material';
import DividerWithText from '../divider/DividerWithText';

export default function SingleBoxSkeleton() {
  return (
    <>
      <Box sx={{ px: { xs: 4, md: 8.5 }, paddingTop: { xs: 15, md: 20 } }}>
        <DividerWithText text={'BOX DETAILS'} />
        <Box
          sx={{
            bgcolor: 'grey.900',
            border: 0.5,
            borderColor: '#646262',
            borderRadius: 10,
            mx: { xs: 1, sm: 2, md: 5 },
            my: 5,
            pt: { xs: 2, md: 5 },
            pb: 5,
            px: 2,
          }}
        >
          <Grid container>
            <Grid
              item
              xs={12}
              md={6}
              sx={{
                mb: 2,
              }}
            >
              <Box
                sx={{
                  width: { xs: '150px', md: '300px' },
                  height: { xs: '150px', md: '300px' },
                  position: 'relative',
                  margin: 'auto',
                  overflow: 'hidden',
                }}
              >
                <Skeleton animation="wave" height={'300px'} />
              </Box>
            </Grid>
            <Grid item xs={12} md={6}>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Typography sx={{ m: 1 }} variant="h4">
                    <Skeleton animation="wave" />
                  </Typography>
                  <Typography sx={{ m: 1 }} variant="h4">
                    <Skeleton animation="wave" />
                  </Typography>
                  <Typography sx={{ m: 1 }} variant="h4">
                    <Skeleton animation="wave" />
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Box>
        <DividerWithText text={'WHAT ITEMS IN THE BOX'} />

        <Box sx={{ my: 5 }}>
          <Typography sx={{ m: 1 }} variant="h4">
            <Skeleton animation="wave" width={'100%'} height={'100px'} />
          </Typography>
        </Box>
      </Box>
    </>
  );
}

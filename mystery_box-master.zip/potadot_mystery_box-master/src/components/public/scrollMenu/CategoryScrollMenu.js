import React, { useState, useContext, useEffect } from 'react';
import { Typography, IconButton, Button } from '@mui/material';
import { ScrollMenu, VisibilityContext } from 'react-horizontal-scrolling-menu';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';

function LeftArrow() {
  const {
    getPrevItem,
    isFirstItemVisible,
    scrollToItem,
    visibleItemsWithoutSeparators,
    initComplete,
  } = useContext(VisibilityContext);

  const [disabled, setDisabled] = useState(
    !initComplete || (initComplete && isFirstItemVisible)
  );
  useEffect(() => {
    if (visibleItemsWithoutSeparators.length) {
      setDisabled(isFirstItemVisible);
    }
  }, [isFirstItemVisible, visibleItemsWithoutSeparators]);

  const clickHandler = () => {
    const prevItem = getPrevItem();
    scrollToItem(prevItem?.entry?.target, 'smooth', 'start');
  };

  return (
    <IconButton
      disabled={disabled}
      onClick={() => clickHandler()}
      sx={{
        display: disabled ? 'none' : 'flex',
        height: '100%',
        width: '25px',
        bgcolor: '#222222',
        borderRadius: '10px',
        color: '#ffffff',
        mr: 1,
      }}
    >
      <KeyboardArrowLeftIcon />
    </IconButton>
  );
}

function RightArrow() {
  const {
    getNextItem,
    isLastItemVisible,
    scrollToItem,
    visibleItemsWithoutSeparators,
  } = useContext(VisibilityContext);

  const clickHandler = () => {
    const nextItem = getNextItem();
    scrollToItem(nextItem?.entry?.target, 'smooth', 'end');
  };

  useEffect(() => {
    if (visibleItemsWithoutSeparators.length) {
      setDisabled(isLastItemVisible);
    }
  }, [isLastItemVisible, visibleItemsWithoutSeparators]);

  const [disabled, setDisabled] = useState(
    !visibleItemsWithoutSeparators.length && isLastItemVisible
  );

  return (
    <IconButton
      disabled={disabled}
      onClick={() => clickHandler()}
      sx={{
        display: disabled ? 'none' : 'flex',
        height: '100%',
        width: '25px',
        bgcolor: '#222222',
        borderRadius: '10px',
        color: '#ffffff',
        ml: 1,
      }}
    >
      <KeyboardArrowRightIcon />
    </IconButton>
  );
}

function Card({ onClick, selectedCategory, title, itemId }) {
  const visibility = useContext(VisibilityContext);

  return (
    <Button
      key={itemId}
      onClick={() => onClick(visibility)}
      sx={{
        display: 'flex',
        width: { xs: '120px', md: '170px' },
        height: { xs: '50px', md: '60px' },
        bgcolor: '#222222',
        borderRadius: '10px',
        alignItems: 'center',
        justifyContent: 'center',
        mx: 0.5,
        opacity: selectedCategory ? 1 : 0.6,
      }}
      tabIndex={0}
    >
      <Typography
        sx={{
          color: '#ff9800',
          fontWeight: 'bold',
          fontSize: { xs: 14, md: 18 },
        }}
      >
        {title}
      </Typography>
    </Button>
  );
}

export default function Home({ categories, setFilter }) {
  const [selectedCategory, setSelectedCategory] = useState(0);

  const handleClick = (id) => () => {
    setSelectedCategory(id);
  };

  useEffect(() => {
    setFilter(selectedCategory);
  }, [selectedCategory]);

  return (
    <>
      <ScrollMenu LeftArrow={LeftArrow} RightArrow={RightArrow}>
        <Card
          itemId={0}
          title={'All'}
          key={0}
          onClick={handleClick(0)}
          selectedCategory={selectedCategory == 0}
        />
        {categories.map((category) => (
          <Card
            itemId={category.id}
            title={category.name}
            key={category.id}
            onClick={handleClick(category.id)}
            selectedCategory={selectedCategory == category.id}
          />
        ))}
      </ScrollMenu>
    </>
  );
}

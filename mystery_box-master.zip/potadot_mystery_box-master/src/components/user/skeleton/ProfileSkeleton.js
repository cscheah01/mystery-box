import React from 'react';
import { Skeleton, Box, Button, Typography } from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';

export default function DetailsSkeleton() {
  return (
    <>
      <Box sx={{ px: { xs: 4, md: 10 }, paddingTop: 20 }}>
        <Box
          sx={{
            backgroundColor: '#212121',
          }}
        >
          <Box
            sx={{
              backgroundColor: '#4D4D4D',
              px: 3,
              py: 2,
              color: '#ffffff',
              display: 'flex',
            }}
          >
            <Box sx={{ flexGrow: 1 }}>
              <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
                <Skeleton animation="wave" width={100} height={65} />
              </Typography>
              <Typography variant="body2">Wallet Balance</Typography>
            </Box>

            <Button startIcon={<AddCircleOutlineIcon />}>
              Add Money To Wallet
            </Button>
          </Box>

          <Skeleton animation="wave" height={'300px'} />
        </Box>
      </Box>

      <Box sx={{ px: { xs: 4, md: 10 }, paddingTop: 5 }}>
        <Box
          sx={{
            backgroundColor: '#212121',
            borderRadius: 5,
          }}
        >
          <Box
            sx={{
              backgroundColor: '#4D4D4D',
              px: 3,
              py: 2,
              color: '#ffffff',
              display: 'flex',
            }}
          >
            <Box sx={{ flexGrow: 1 }}>
              <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
                Shipping Information
              </Typography>
            </Box>
          </Box>

          <Skeleton animation="wave" height={'300px'} />
        </Box>
      </Box>
    </>
  );
}

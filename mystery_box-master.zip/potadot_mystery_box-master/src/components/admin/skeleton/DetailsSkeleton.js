import React from 'react';
import { Skeleton, Box, Grid, Typography } from '@mui/material';

export default function DetailsSkeleton() {
  return (
    <>
      <Box
        sx={{
          alignItems: 'center',
          display: 'flex',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          m: -1,
        }}
      >
        <Typography sx={{ m: 1 }} variant="h4">
          <Skeleton animation="wave" width={200} />
        </Typography>
        <Box sx={{ m: 1 }}>
          <Grid container spacing={1} justifyContent="flex-end">
            <Grid item>
              <Skeleton animation="wave" width={65} height={65} />
            </Grid>
          </Grid>
        </Box>
      </Box>

      <Skeleton
        animation="wave"
        variant="rounded"
        height={150}
        sx={{ mt: 3 }}
      />
    </>
  );
}

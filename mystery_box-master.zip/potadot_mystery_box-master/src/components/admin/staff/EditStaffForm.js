import React from 'react';
import {
  TextField,
  Card,
  CardContent,
  CardActions,
  Grid,
  Typography,
  Divider,
  Box,
} from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useSnackbar } from 'notistack';

export default function EditStaffForm({ onSubmit, data }) {
  const { enqueueSnackbar } = useSnackbar();

  const formik = useFormik({
    initialValues: {
      name: '',
      email: '',
      password: '',
      confirm_password: '',
      ...data,
    },
    validationSchema: Yup.object({
      name: Yup.string().required(),
      email: Yup.string().required().email(),
      password: Yup.string().min(8),
      confirm_password: Yup.string()
        .oneOf([Yup.ref('password')], 'Confirm passwords is not match')
        .when('password', {
          is: (password) => password != null,
          then: Yup.string().required(),
        }),
    }),
    onSubmit: async (values, { setErrors }) => {
      const response = await onSubmit(values);

      const responseData = response.data;

      if (responseData.success) {
        enqueueSnackbar(responseData.message, {
          variant: 'success',
          autoHideDuration: 3000,
        });
      } else if (response.status == 422) {
        enqueueSnackbar('Please check your input.', {
          variant: 'error',
          autoHideDuration: 3000,
        });

        setErrors(responseData.message);
      }
    },
  });

  const onSubmitClick = () => {
    if (Object.keys(formik.errors).length > 0) {
      enqueueSnackbar('Please check your input.', {
        variant: 'error',
        autoHideDuration: 3000,
      });
    }
  };

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Card>
          <CardContent>
            <Typography variant="subtitle1" mb={3}>
              General Details
            </Typography>

            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Name"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="name"
                  value={formik.values.name}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(formik.touched.name && formik.errors.name)}
                  helperText={formik.touched.name && formik.errors.name}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Email"
                  type="email"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="email"
                  value={formik.values.email}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(formik.touched.email && formik.errors.email)}
                  helperText={formik.touched.email && formik.errors.email}
                />
              </Grid>
            </Grid>

            <Box py={3}>
              <Divider />
            </Box>

            <Typography variant="subtitle1" mb={3}>
              Password
            </Typography>

            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Password"
                  type="password"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="password"
                  value={formik.values.password}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(
                    formik.touched.password && formik.errors.password
                  )}
                  helperText={formik.touched.password && formik.errors.password}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Confirm Password"
                  type="password"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="confirm_password"
                  value={formik.values.confirm_password}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(
                    formik.touched.confirm_password &&
                      formik.errors.confirm_password
                  )}
                  helperText={
                    formik.touched.confirm_password &&
                    formik.errors.confirm_password
                  }
                />
              </Grid>
            </Grid>
          </CardContent>
          <CardActions>
            <Grid container spacing={1} justifyContent="flex-end">
              <Grid item>
                <LoadingButton
                  variant="contained"
                  type="submit"
                  loading={formik.isSubmitting}
                  disabled={formik.isSubmitting}
                  onClick={() => {
                    onSubmitClick();
                  }}
                >
                  Save
                </LoadingButton>
              </Grid>
            </Grid>
          </CardActions>
        </Card>
      </form>
    </>
  );
}

import React, { useState, useEffect } from 'react';
import { Card, CardContent, Grid, Typography, Divider } from '@mui/material';

export default function StaffDetails({ data }) {
  const [staff, setStaff] = useState({});

  useEffect(() => {
    setStaff(data);
  }, [data]);

  return (
    <>
      <Card>
        <CardContent>
          <Typography variant="subtitle1" mb={3}>
            General Details
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Typography variant="subtitle2">Name</Typography>
              <Typography>{staff.name}</Typography>
            </Grid>
            <Grid item xs={12}>
              <Divider />
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle2">Email</Typography>
              <Typography>{staff.email}</Typography>
            </Grid>
            <Grid item xs={12}>
              <Divider />
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle2">Created At</Typography>
              <Typography>{staff.created_at}</Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </>
  );
}

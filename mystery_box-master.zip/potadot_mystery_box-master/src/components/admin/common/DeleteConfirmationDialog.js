import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';
import { useSnackbar } from 'notistack';

export default function DeleteConfirmationDialog({
  isOpen,
  onClose,
  confirmDelete,
}) {
  const [open, setOpen] = useState(false);
  const { enqueueSnackbar } = useSnackbar();

  useEffect(() => {
    setOpen(isOpen);
  }, [isOpen]);

  const handleClose = () => {
    onClose();
  };

  const handleConfirm = async () => {
    onClose();
    const response = await confirmDelete();

    const responseData = response.data;

    if (responseData.success) {
      enqueueSnackbar(responseData.message, {
        variant: 'success',
        autoHideDuration: 3000,
      });
    } else {
      enqueueSnackbar(responseData.message, {
        variant: 'error',
        autoHideDuration: 3000,
      });
    }
  };

  return (
    <>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Are you sure want to delete?</DialogTitle>
        <DialogActions>
          <Button onClick={handleClose} color="dark" variant="contained">
            Cancel
          </Button>
          <Button onClick={handleConfirm} color="error" variant="contained">
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}

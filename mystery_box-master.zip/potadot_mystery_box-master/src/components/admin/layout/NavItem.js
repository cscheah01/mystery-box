import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { Box, Button, ListItem, Collapse, List } from '@mui/material';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';

export default function NavItem({ item, ...others }) {
  const router = useRouter();
  const currentPath = router.pathname;
  const [open, setOpen] = useState(false);

  const handleClick = () => {
    setOpen(!open);
  };

  useEffect(() => {
    if (item.children) {
      item.children.map((children) => {
        if (children.href == currentPath) {
          setOpen(true);
        }
      });
    }
  }, []);

  const button = (
    <Button
      startIcon={item.icon}
      endIcon={
        item.children ? open ? <ExpandLessIcon /> : <ExpandMoreIcon /> : null
      }
      disableRipple
      onClick={handleClick}
      sx={{
        backgroundColor: currentPath == item.href && 'rgba(255,255,255, 0.08)',
        borderRadius: 1,
        color: currentPath == item.href ? 'secondary.main' : 'neutral.300',
        fontWeight: currentPath == item.href && 'fontWeightBold',
        justifyContent: 'flex-start',
        px: 3,
        textAlign: 'left',
        textTransform: 'none',
        width: '100%',
        '& .MuiButton-startIcon': {
          color: currentPath == item.href ? 'secondary.main' : 'neutral.400',
        },
        '&:hover': {
          backgroundColor: 'rgba(255,255,255, 0.08)',
        },
      }}
    >
      <Box sx={{ flexGrow: 1 }}>{item.title}</Box>
    </Button>
  );

  const childButton = (children) => (
    <Button
      startIcon={<FiberManualRecordIcon />}
      disableRipple
      sx={{
        backgroundColor:
          currentPath == children.href && 'rgba(255,255,255, 0.08)',
        borderRadius: 1,
        color: currentPath == children.href ? 'secondary.main' : 'neutral.300',
        fontWeight: currentPath == children.href && 'fontWeightBold',
        justifyContent: 'flex-start',
        px: 3,
        textAlign: 'left',
        textTransform: 'none',
        width: '100%',
        '& .MuiButton-startIcon': {
          color:
            currentPath == children.href ? 'secondary.main' : 'neutral.400',
        },
        '&:hover': {
          backgroundColor: 'rgba(255,255,255, 0.08)',
        },
      }}
    >
      <Box sx={{ flexGrow: 1 }}>{children.title}</Box>
    </Button>
  );

  return (
    <>
      <ListItem
        disableGutters
        sx={{
          display: 'flex',
          mb: 0.5,
          py: 0,
          px: 2,
        }}
        {...others}
      >
        {item.children ? (
          <>{button}</>
        ) : (
          <Link href={item.href} passHref>
            {button}
          </Link>
        )}
      </ListItem>

      {item.children ? (
        <Collapse in={open} unmountOnExit>
          <List component="div" disablePadding sx={{ pl: 2 }}>
            {item.children.map((children) => (
              <ListItem
                disableGutters
                sx={{
                  display: 'flex',
                  mb: 0.5,
                  py: 0,
                  px: 2,
                }}
                {...others}
                key={children.href}
              >
                <Link href={children.href} passHref>
                  {childButton(children)}
                </Link>
              </ListItem>
            ))}
          </List>
        </Collapse>
      ) : (
        <></>
      )}
    </>
  );
}

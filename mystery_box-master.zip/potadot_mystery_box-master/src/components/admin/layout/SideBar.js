import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { Box, Divider, Drawer, useMediaQuery, List } from '@mui/material';
import NavItem from './NavItem';
import SpeedIcon from '@mui/icons-material/Speed';
import BadgeIcon from '@mui/icons-material/Badge';
import CardGiftcardIcon from '@mui/icons-material/CardGiftcard';
import InventoryIcon from '@mui/icons-material/Inventory';
import logo from '../../../assets/img/logo-transparent.png';
import Image from 'next/image';

const items = [
  {
    href: '/admin',
    icon: <SpeedIcon />,
    title: 'Dashboard',
  },
  {
    href: '/admin/staff',
    icon: <BadgeIcon />,
    title: 'Staff',
  },
  {
    icon: <InventoryIcon />,
    title: 'Product',
    children: [
      {
        href: '/admin/product',
        title: 'All',
      },
      {
        href: '/admin/product-category',
        title: 'Product Category',
      },
    ],
  },
  {
    icon: <CardGiftcardIcon />,
    title: 'Box',
    children: [
      {
        href: '/admin/box',
        title: 'All',
      },
      {
        href: '/admin/box-category',
        title: 'Box Category',
      },
    ],
  },
];

export default function Sidebar({ open, onClose }) {
  const router = useRouter();
  const lgUp = useMediaQuery((theme) => theme.breakpoints.up('lg'), {
    defaultMatches: true,
    noSsr: false,
  });

  useEffect(() => {
    if (!router.isReady) {
      return;
    }

    if (open) {
      onClose?.();
    }
  }, [router.asPath]);

  return (
    <Drawer
      anchor="left"
      onClose={onClose}
      open={open}
      PaperProps={{
        sx: {
          backgroundColor: 'neutral.900',
          color: '#FFFFFF',
          width: 280,
        },
      }}
      sx={{ zIndex: (theme) => theme.zIndex.appBar + 100 }}
      variant={lgUp ? 'permanent' : 'temporary'}
    >
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          height: '100%',
        }}
      >
        <div>
          <Box
            sx={{
              height: '64px',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <Image src={logo} width="180" height="50" layout={'fixed'} />
          </Box>
        </div>
        <Divider
          sx={{
            borderColor: '#2D3748',
            marginBottom: 3,
          }}
        />
        <Box sx={{ flexGrow: 1 }}>
          <List sx={{ width: '100%' }} component="nav">
            {items.map((item) => (
              <NavItem key={item.title} item={item} />
            ))}
          </List>
        </Box>
      </Box>
    </Drawer>
  );
}

import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  Grid,
  Typography,
  Divider,
  Box,
  Chip,
} from '@mui/material';
import TableSkeleton from '../../../components/admin/skeleton/TableSkeleton';
import BoxItemTable from '../../../components/admin/box/BoxItemTable';
import BoxItemTableSearchForm from '../../../components/admin/box/BoxItemTableSearchForm';
import {
  getBoxItemList,
  deleteBoxItem,
} from '../../../services/boxItemService';
import { getProductCategoryList } from '../../../services/productCategoryService';
import DeleteConfirmationDialog from '../../../components/admin/common/DeleteConfirmationDialog';
import emptyImage from '../../../assets/img/empty-image.png';
import Image from 'next/image';

export default function BoxDetails({ data }) {
  const [box, setBox] = useState({});

  useEffect(() => {
    setBox(data);
    setSrc(data.image_url);
  }, [data]);
  const [src, setSrc] = useState(emptyImage);
  const [isLoading, setIsLoading] = useState(true);
  const [productCategory, setProductCategory] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [tableSetting, setTableSetting] = useState({
    page: {
      number: 0,
      quantity: 10,
    },
    sort: {
      column: 'products.created_at',
      order: 'desc',
    },
    filter: {
      name: '',
      id: data.id,
      product_category_id: '',
    },
  });
  const [totalResult, setTotalResult] = useState(0);

  const [deleteConfirmation, setDeleteConfirmation] = useState({
    isOpen: false,
    id: null,
  });

  const fetchData = async () => {
    setIsLoading(true);

    const response = await getBoxItemList(tableSetting);

    const responseData = response.data;

    if (responseData.success) {
      setTableData(responseData.data.list);
      setTotalResult(responseData.data.totalResult);
      setIsLoading(false);

      return;
    }
  };

  useEffect(() => {
    fetchData();
  }, [null, tableSetting]);

  const [productCategoryTableSetting, setProductCategoryTableSetting] =
    useState({
      page: {
        number: 0,
        quantity: 10,
      },
      sort: {
        column: 'created_at',
        order: 'desc',
      },
      filter: {
        name: '',
      },
    });

  const fetchProductCategoryData = async () => {
    const response = await getProductCategoryList(productCategoryTableSetting);

    const responseData = response.data;

    if (responseData.success) {
      if (responseData.data.list.length != 0) {
        if (productCategoryTableSetting.page.number == 0) {
          setProductCategory(responseData.data.list);
        } else {
          setProductCategory([...productCategory, ...responseData.data.list]);
        }
      }

      return;
    }
  };

  useEffect(() => {
    fetchProductCategoryData();
  }, [null, productCategoryTableSetting]);

  const handleDeleteConfirmation = (id) => {
    setDeleteConfirmation({ ...deleteConfirmation, isOpen: true, id: id });
  };

  const onDelete = async () => {
    const response = await deleteBoxItem({ id: deleteConfirmation.id });

    const responseData = response.data;
    if (responseData.success) {
      fetchData();
    }

    return response;
  };

  return (
    <>
      <Card sx={{ mb: 5 }}>
        <CardContent>
          <Typography variant="subtitle1" mb={3}>
            General Details
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Box
                sx={{
                  border: 2,
                  borderColor: '#9e9e9e',
                  borderRadius: 2,
                  margin: 'auto',
                  width: '150px',
                  height: '150px',
                  position: 'relative',
                  overflow: 'hidden',
                  mb: 2,
                }}
              >
                <Image
                  src={src}
                  layout="fill"
                  objectFit="cover"
                  onError={() => setSrc(emptyImage)}
                />
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2">Name</Typography>
              <Typography>{box.name}</Typography>
            </Grid>
            <Grid item xs={12} sx={{ display: { xs: 'block', sm: 'none' } }}>
              <Divider />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2">Box Category</Typography>
              <Typography>
                {box.box_category ? box.box_category.name : 'Uncategorized'}
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <Divider />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2">Cost Price</Typography>
              <Typography>RM {box.price}</Typography>
            </Grid>
            <Grid item xs={12}>
              <Divider />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2">Status</Typography>
              {box.is_available == 1 ? (
                <Chip label="Available" color="primary" />
              ) : (
                <Chip label="Not Available" color="error" />
              )}
            </Grid>
          </Grid>
        </CardContent>
      </Card>
      <Typography variant="h5" mb={3}>
        Box Item
      </Typography>
      <Box sx={{ mt: 3 }}>
        <BoxItemTableSearchForm
          data={tableSetting.filter}
          onSubmit={(data) => {
            setTableSetting({ ...tableSetting, filter: data });
          }}
          productCategory={productCategory}
          setTablePageSetting={(data) => {
            setProductCategoryTableSetting({
              ...productCategoryTableSetting,
              page: { number: data, quantity: 10 },
            });
          }}
          setTableSetting={(data) => {
            setProductCategoryTableSetting({
              ...productCategoryTableSetting,
              filter: data,
              page: { number: 0, quantity: 10 },
            });
          }}
        />
      </Box>
      <Box sx={{ mt: 3 }}>
        {isLoading ? (
          <TableSkeleton />
        ) : (
          <BoxItemTable
            tableData={tableData}
            totalResult={totalResult}
            tableSetting={tableSetting}
            handleChange={(data) => {
              setTableSetting(data);
            }}
            handleDelete={(id) => {
              handleDeleteConfirmation(id);
            }}
          />
        )}
      </Box>
      <DeleteConfirmationDialog
        isOpen={deleteConfirmation.isOpen}
        onClose={() => {
          setDeleteConfirmation({ isOpen: false });
        }}
        id={deleteConfirmation.id}
        confirmDelete={onDelete}
      />
    </>
  );
}

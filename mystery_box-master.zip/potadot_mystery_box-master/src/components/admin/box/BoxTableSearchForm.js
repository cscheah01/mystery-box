import React, { useEffect, useState } from 'react';
import {
  Button,
  TextField,
  Card,
  CardContent,
  CardActions,
  Grid,
  Autocomplete,
} from '@mui/material';
import { useFormik } from 'formik';

export default function BoxTableSearchForm({
  data,
  onSubmit,
  boxCategory,
  setBoxCategoryTablePageSetting,
  setBoxCategoryTableSetting,
}) {
  const formik = useFormik({
    initialValues: data,
    onSubmit: (values) => {
      onSubmit(values);
    },
  });

  const [boxCategoryValue, setBoxCategoryValue] = useState(null);
  const [boxPage, setBoxPage] = useState(0);

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Card>
          <CardContent>
            <Grid container spacing={2}>
              <Grid item xs={6} md={3}>
                <TextField
                  label="Name"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="name"
                  value={formik.values.name}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                />
              </Grid>
              <Grid item xs={6} md={3}>
                <Autocomplete
                  disablePortal
                  value={
                    formik.values.box_category_id == '' ? '' : boxCategoryValue
                  }
                  ListboxProps={{
                    onScroll: (event) => {
                      event.stopPropagation();
                      const listboxNode = event.currentTarget;
                      const savedScrollTop = listboxNode.scrollTop;
                      const diff = Math.round(
                        listboxNode.scrollHeight - savedScrollTop
                      );
                      if (diff - 25 <= listboxNode.clientHeight) {
                        setBoxPage((boxPage) => boxPage + 1);
                        setBoxCategoryTablePageSetting(boxPage);
                      }
                    },
                  }}
                  onChange={(event, newValue) => {
                    if (newValue != null) {
                      formik.values.box_category_id = newValue.id;
                      setBoxCategoryValue(newValue);
                    } else {
                      formik.values.box_category_id = '';
                      setBoxCategoryValue(null);
                    }
                  }}
                  onInputChange={(event, newInputValue) => {
                    setBoxCategoryTableSetting({ name: newInputValue });
                    setBoxPage(0);
                  }}
                  options={boxCategory}
                  isOptionEqualToValue={(option, value) =>
                    option.name === value
                  }
                  getOptionLabel={(option) => option.name ?? ''}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Category"
                      InputLabelProps={{ shrink: true }}
                      placeholder="Click to select"
                    />
                  )}
                />
              </Grid>
            </Grid>
          </CardContent>
          <CardActions>
            <Grid container spacing={1} justifyContent="flex-end">
              <Grid item>
                <Button
                  variant="outlined"
                  onClick={() =>
                    formik.resetForm({
                      values: { name: '', box_category_id: '' },
                    })
                  }
                >
                  Reset
                </Button>
              </Grid>
              <Grid item>
                <Button variant="contained" type="submit">
                  Search
                </Button>
              </Grid>
            </Grid>
          </CardActions>
        </Card>
      </form>
    </>
  );
}

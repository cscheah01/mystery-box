import React, { useEffect, useState } from 'react';
import {
  TextField,
  Card,
  CardContent,
  CardActions,
  Grid,
  Typography,
  Button,
  Box,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  Autocomplete,
  Divider,
} from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useSnackbar } from 'notistack';
import Image from 'next/image';
import emptyImage from '../../../assets/img/empty-image.png';

export default function CreateBoxForm({
  onSubmit,
  boxCategory,
  setBoxCategoryTablePageSetting,
  setBoxCategoryTableSetting,
  product,
  setProductTablePageSetting,
  setProductTableSetting,
}) {
  const { enqueueSnackbar } = useSnackbar();
  const [boxImage, setBoxImage] = useState();
  const [boxCategoryValue, setBoxCategoryValue] = useState(null);
  const [boxItems, setBoxItems] = useState(null);
  const [boxPage, setBoxPage] = useState(0);
  const [productPage, setProductPage] = useState(0);
  const [src, setSrc] = useState(emptyImage);

  const supportedFormats = ['image/jpg', 'image/jpeg', 'image/png'];

  const formik = useFormik({
    initialValues: {
      name: '',
      image: '',
      box_category_id: '',
      price: '',
      description: '',
      is_available: '',
    },
    validationSchema: Yup.object({
      name: Yup.string().required(),
      image: Yup.mixed()
        .required()
        .test(
          'fileFormat',
          'Unsupported Format',
          (value) => value && supportedFormats.includes(value.type)
        ),
      box_category_id: Yup.number().required('box category is required field'),
      price: Yup.number().positive().required(),
      description: Yup.string().required().max(3500),
      is_available: Yup.boolean().required(),
    }),
    onSubmit: async (values, { setErrors }) => {
      const formData = new FormData();

      formData.append('image', values.image);
      formData.append('name', values.name);
      formData.append('box_category_id', values.box_category_id);
      formData.append('price', values.price);
      formData.append('description', values.description);
      formData.append('is_available', values.is_available);
      if (boxItems != null) {
        boxItems.forEach((item, index) => {
          formData.append('box_items[' + index + ']', item.id);
        });
      }

      const response = await onSubmit(formData);

      const responseData = response.data;

      if (responseData.success) {
        enqueueSnackbar(responseData.message, {
          variant: 'success',
          autoHideDuration: 3000,
        });
      } else if (response.status == 422) {
        enqueueSnackbar('Please check your input.', {
          variant: 'error',
          autoHideDuration: 3000,
        });

        setErrors(responseData.message);
      }
    },
  });

  useEffect(() => {
    const file = boxImage;

    if (file) {
      formik.values.image = file;
      let reader = new FileReader();
      reader.onload = function (event) {
        setSrc(event.target.result);
      };
      reader.readAsDataURL(file);
    }
  }, [boxImage]);

  const onSubmitClick = () => {
    if (Object.keys(formik.errors).length > 0) {
      enqueueSnackbar('Please check your input.', {
        variant: 'error',
        autoHideDuration: 3000,
      });
    }
  };

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Card>
          <CardContent>
            <Typography variant="subtitle1" mb={3}>
              General Details
            </Typography>

            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Box
                  sx={{
                    border: 2,
                    borderColor: '#9e9e9e',
                    borderRadius: 2,
                    margin: 'auto',
                    width: '150px',
                    height: '150px',
                    position: 'relative',
                    overflow: 'hidden',
                    alignItems: 'center',
                  }}
                >
                  <Image
                    src={src}
                    layout="fill"
                    objectFit="cover"
                    onError={() => setSrc(emptyImage)}
                  />
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Typography
                  sx={{
                    mb: 2,
                    textAlign: 'center',
                    display: formik.values.image != '' ? 'block' : 'none',
                  }}
                >
                  {formik.values.image != ''
                    ? formik.values.image.name
                    : formik.values.image}
                </Typography>
                <Box
                  sx={{
                    textAlign: 'center',
                  }}
                >
                  <Button variant="contained" component="label">
                    Select File
                    <input
                      type="file"
                      hidden
                      name="image"
                      accept=".png,.jpg,.jpeg"
                      onChange={(e) => {
                        setBoxImage(e.target.files[0]);
                      }}
                    />
                  </Button>
                </Box>
                <Typography
                  sx={{
                    display:
                      formik.errors.image != null &&
                      formik.touched.image != null
                        ? 'block'
                        : 'none',
                    color: '#D14343',
                    fontWeight: 400,
                    lineHeight: 1.66,
                    fontSize: '0.75rem',
                    mt: '3px',
                    textAlign: 'center',
                  }}
                >
                  {formik.errors.image}
                </Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Name"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="name"
                  value={formik.values.name}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(formik.touched.name && formik.errors.name)}
                  helperText={formik.touched.name && formik.errors.name}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  disablePortal
                  value={boxCategoryValue}
                  ListboxProps={{
                    onScroll: (event) => {
                      event.stopPropagation();
                      const listboxNode = event.currentTarget;
                      const savedScrollTop = listboxNode.scrollTop;
                      const diff = Math.round(
                        listboxNode.scrollHeight - savedScrollTop
                      );
                      if (diff - 25 <= listboxNode.clientHeight) {
                        setBoxPage((boxPage) => boxPage + 1);
                        setBoxCategoryTablePageSetting(boxPage);
                      }
                    },
                  }}
                  onChange={(event, newValue) => {
                    if (newValue != null) {
                      formik.values.box_category_id = newValue.id;
                      setBoxCategoryValue(newValue);
                    }
                  }}
                  onInputChange={(event, newInputValue) => {
                    setBoxCategoryTableSetting({ name: newInputValue });
                    setBoxPage(0);
                  }}
                  onOpen={formik.handleBlur}
                  options={boxCategory}
                  isOptionEqualToValue={(option, value) =>
                    option.name === value
                  }
                  getOptionLabel={(option) => option.name ?? ''}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Box Category"
                      InputLabelProps={{ shrink: true }}
                      error={Boolean(
                        formik.touched.box_category_id &&
                          formik.errors.box_category_id
                      )}
                      helperText={
                        formik.touched.box_category_id &&
                        formik.errors.box_category_id
                      }
                      placeholder="Click to select"
                    />
                  )}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  label="Description"
                  type="text"
                  fullWidth
                  multiline
                  rows={3}
                  InputLabelProps={{ shrink: true }}
                  name="description"
                  value={formik.values.description}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(
                    formik.touched.description && formik.errors.description
                  )}
                  helperText={
                    formik.touched.description && formik.errors.description
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl sx={{ ml: 1 }}>
                  <FormLabel id="is-available-label">Status</FormLabel>
                  <RadioGroup
                    row
                    aria-labelledby="is-available-label"
                    name="is_available"
                    value={formik.values.is_available}
                    onChange={formik.handleChange}
                  >
                    <FormControlLabel
                      value="1"
                      control={<Radio />}
                      label="Available"
                    />
                    <FormControlLabel
                      value="0"
                      control={<Radio />}
                      label="Not Available"
                    />
                  </RadioGroup>
                  <Typography
                    sx={{
                      display:
                        formik.errors.is_available != null &&
                        formik.touched.is_available != null
                          ? 'block'
                          : 'none',
                      color: '#D14343',
                      fontWeight: 400,
                      lineHeight: 1.66,
                      fontSize: '0.75rem',
                      mt: '3px',
                      mr: 2,
                      mb: 0,
                      ml: 2,
                    }}
                  >
                    {formik.errors.is_available}
                  </Typography>
                </FormControl>
              </Grid>
            </Grid>

            <Box py={3}>
              <Divider />
            </Box>

            <Typography variant="subtitle1" mb={3}>
              Price
            </Typography>

            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  type="number"
                  label="Price"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="price"
                  value={formik.values.price}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(formik.touched.price && formik.errors.price)}
                  helperText={formik.touched.price && formik.errors.price}
                  inputProps={{
                    step: '0.01',
                    min: '0',
                  }}
                />
              </Grid>
            </Grid>

            <Box py={3}>
              <Divider />
            </Box>

            <Typography variant="subtitle1" mb={3}>
              Box Item
            </Typography>

            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  multiple
                  ListboxProps={{
                    onScroll: (event) => {
                      event.stopPropagation();
                      const listboxNode = event.currentTarget;
                      const savedScrollTop = listboxNode.scrollTop;
                      const diff = Math.round(
                        listboxNode.scrollHeight - savedScrollTop
                      );
                      if (diff - 25 <= listboxNode.clientHeight) {
                        setProductPage((productPage) => productPage + 1);
                        setProductTablePageSetting(productPage);
                      }
                    },
                  }}
                  onChange={(event, newValue) => {
                    if (newValue != null) {
                      setBoxItems(newValue);
                    }
                  }}
                  onInputChange={(event, newInputValue) => {
                    setProductTableSetting({ name: newInputValue });
                    setProductPage(0);
                  }}
                  options={product}
                  getOptionLabel={(option) => option.name}
                  filterSelectedOptions
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Box Product"
                      InputLabelProps={{ shrink: true }}
                      placeholder="Click to select"
                    />
                  )}
                />
              </Grid>
            </Grid>
          </CardContent>
          <CardActions>
            <Grid container spacing={1} justifyContent="flex-end">
              <Grid item>
                <LoadingButton
                  variant="contained"
                  type="submit"
                  loading={formik.isSubmitting}
                  disabled={formik.isSubmitting}
                  onClick={() => {
                    onSubmitClick();
                  }}
                >
                  Create
                </LoadingButton>
              </Grid>
            </Grid>
          </CardActions>
        </Card>
      </form>
    </>
  );
}

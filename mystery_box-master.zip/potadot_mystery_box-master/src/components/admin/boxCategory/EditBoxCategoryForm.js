import React from 'react';
import {
  TextField,
  Card,
  CardContent,
  CardActions,
  Grid,
  Typography,
} from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useSnackbar } from 'notistack';

export default function EditBoxCategoryForm({ onSubmit, data }) {
  const { enqueueSnackbar } = useSnackbar();

  const formik = useFormik({
    initialValues: {
      name: '',
      ...data,
    },
    validationSchema: Yup.object({
      name: Yup.string().required(),
    }),
    onSubmit: async (values, { setErrors }) => {
      const response = await onSubmit(values);

      const responseData = response.data;

      if (responseData.success) {
        enqueueSnackbar(responseData.message, {
          variant: 'success',
          autoHideDuration: 3000,
        });
      } else if (response.status == 422) {
        enqueueSnackbar('Please check your input.', {
          variant: 'error',
          autoHideDuration: 3000,
        });

        setErrors(responseData.message);
      }
    },
  });

  const onSubmitClick = () => {
    if (Object.keys(formik.errors).length > 0) {
      enqueueSnackbar('Please check your input.', {
        variant: 'error',
        autoHideDuration: 3000,
      });
    }
  };

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Card>
          <CardContent>
            <Typography variant="subtitle1" mb={3}>
              General Details
            </Typography>

            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  label="Name"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="name"
                  value={formik.values.name}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(formik.touched.name && formik.errors.name)}
                  helperText={formik.touched.name && formik.errors.name}
                />
              </Grid>
            </Grid>
          </CardContent>
          <CardActions>
            <Grid container spacing={1} justifyContent="flex-end">
              <Grid item>
                <LoadingButton
                  variant="contained"
                  type="submit"
                  loading={formik.isSubmitting}
                  disabled={formik.isSubmitting}
                  onClick={() => {
                    onSubmitClick();
                  }}
                >
                  Save
                </LoadingButton>
              </Grid>
            </Grid>
          </CardActions>
        </Card>
      </form>
    </>
  );
}

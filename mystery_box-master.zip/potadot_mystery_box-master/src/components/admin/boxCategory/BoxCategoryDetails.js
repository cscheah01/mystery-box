import React, { useState, useEffect } from 'react';
import { Card, CardContent, Grid, Typography, Divider } from '@mui/material';

export default function BoxDetails({ data }) {
  const [productCategory, setProductCategory] = useState({});

  useEffect(() => {
    setProductCategory(data);
  }, [data]);

  return (
    <>
      <Card>
        <CardContent>
          <Typography variant="subtitle1" mb={3}>
            General Details
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Typography variant="subtitle2">Name</Typography>
              <Typography>{productCategory.name}</Typography>
            </Grid>
            <Grid item xs={12}>
              <Divider />
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle2">Created At</Typography>
              <Typography>{productCategory.created_at}</Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </>
  );
}

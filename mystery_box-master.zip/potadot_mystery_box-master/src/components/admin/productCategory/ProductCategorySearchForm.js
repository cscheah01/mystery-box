import React from 'react';
import {
  Button,
  TextField,
  Card,
  CardContent,
  CardActions,
  Grid,
} from '@mui/material';
import { useFormik } from 'formik';

export default function ProductCategoryTableSearchForm({ data, onSubmit }) {
  const formik = useFormik({
    initialValues: data,
    onSubmit: (values) => {
      onSubmit(values);
    },
  });

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Card>
          <CardContent>
            <Grid container spacing={2}>
              <Grid item xs={6} md={3}>
                <TextField
                  label="Name"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="name"
                  value={formik.values.name}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                />
              </Grid>
            </Grid>
          </CardContent>
          <CardActions>
            <Grid container spacing={1} justifyContent="flex-end">
              <Grid item>
                <Button variant="outlined" onClick={formik.resetForm}>
                  Reset
                </Button>
              </Grid>
              <Grid item>
                <Button variant="contained" type="submit">
                  Search
                </Button>
              </Grid>
            </Grid>
          </CardActions>
        </Card>
      </form>
    </>
  );
}

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TablePagination from '@mui/material/TablePagination';
import TableSortLabel from '@mui/material/TableSortLabel';
import Paper from '@mui/material/Paper';
import IconButton from '@mui/material/IconButton';
import Stack from '@mui/material/Stack';
import DeleteIcon from '@mui/icons-material/Delete';
import VisibilityIcon from '@mui/icons-material/Visibility';
import EditIcon from '@mui/icons-material/Edit';

export default function ProductCategoryTable({
  tableData,
  totalResult,
  tableSetting,
  handleChange,
  handleDelete,
}) {
  const [row, setRow] = useState([]);
  const [total, setTotal] = useState(0);
  const [tableConfig, setTableConfig] = useState(tableSetting);

  const handleChangePage = (event, newPage) => {
    setTableConfig({
      ...tableConfig,
      page: {
        ...tableConfig.page,
        number: newPage,
      },
    });
  };

  const handleChangeRowsPerPage = (event) => {
    setTableConfig({
      ...tableConfig,
      page: {
        number: 0,
        quantity: parseInt(event.target.value),
      },
    });
  };

  const handleSorting = (column) => {
    let sortDirection = 'asc';

    if (tableConfig.sort.column == column) {
      sortDirection = tableConfig.sort.order == 'asc' ? 'desc' : 'asc';
    } else {
      sortDirection = 'desc';
    }

    setTableConfig({
      ...tableConfig,
      sort: {
        column: column,
        order: sortDirection,
      },
    });
  };

  useEffect(() => {
    setRow(tableData);
  }, [tableData]);

  useEffect(() => {
    setTotal(totalResult);
  }, [totalResult]);

  useEffect(() => {
    handleChange(tableConfig);
  }, [tableConfig]);

  const tableHeadColumns = [
    {
      label: 'Name',
      name: 'name',
      sortable: true,
    },
    {
      label: 'Created At',
      name: 'created_at',
      sortable: true,
      props: { align: 'center', width: '200px' },
    },
    {
      label: 'Action',
      name: null,
      sortable: false,
      props: { align: 'center', width: '50px' },
    },
  ];

  return (
    <>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }}>
          <TableHead>
            <TableRow>
              {tableHeadColumns.map((column) => (
                <TableCell key={column.name} {...column.props}>
                  {column.sortable ? (
                    <TableSortLabel
                      active={tableConfig.sort.column == column.name}
                      direction={
                        tableConfig.sort.column == column.name
                          ? tableConfig.sort.order
                          : 'asc'
                      }
                      onClick={() => {
                        handleSorting(column.name);
                      }}
                    >
                      {column.label}
                    </TableSortLabel>
                  ) : (
                    column.label
                  )}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {row.map((row) => (
              <TableRow key={row.id}>
                <TableCell component="th" scope="row">
                  {row.name}
                </TableCell>
                <TableCell align="center">{row.created_at}</TableCell>
                <TableCell align="center">
                  <Stack direction="row">
                    <Link href={`/admin/product-category/${row.id}`} passHref>
                      <IconButton color="primary">
                        <VisibilityIcon />
                      </IconButton>
                    </Link>
                    <Link href={`/admin/product-category/edit/${row.id}`} passHref>
                      <IconButton color="success">
                        <EditIcon />
                      </IconButton>
                    </Link>
                    <IconButton
                      color="error"
                      onClick={() => {
                        handleDelete(row.id);
                      }}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </Stack>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <TablePagination
          rowsPerPageOptions={[10, 25, 50, 75, 100]}
          component="div"
          count={total}
          rowsPerPage={tableConfig.page.quantity}
          page={tableConfig.page.number}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </TableContainer>
    </>
  );
}

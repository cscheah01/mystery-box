import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  Grid,
  Typography,
  Divider,
  Box,
  Chip,
} from '@mui/material';
import emptyImage from '../../../assets/img/empty-image.png';
import Image from 'next/image';

export default function ProductDetails({ data }) {
  const [product, setProduct] = useState({});

  useEffect(() => {
    setProduct(data);
    setSrc(data.image_url);
  }, [data]);
  const [src, setSrc] = useState(emptyImage);
  return (
    <>
      <Card>
        <CardContent>
          <Typography variant="subtitle1" mb={3}>
            General Details
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Box
                sx={{
                  border: 2,
                  borderColor: '#9e9e9e',
                  borderRadius: 2,
                  margin: 'auto',
                  width: '150px',
                  height: '150px',
                  position: 'relative',
                  overflow: 'hidden',
                  alignItems: 'center',
                  mb: 2,
                }}
              >
                <Image
                  src={src}
                  layout="fill"
                  objectFit="cover"
                  onError={() => setSrc(emptyImage)}
                />
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2">Name</Typography>
              <Typography>{product.name}</Typography>
            </Grid>
            <Grid item xs={12} sx={{ display: { xs: 'block', sm: 'none' } }}>
              <Divider />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2">Product Category</Typography>
              <Typography>
                {product.product_category
                  ? product.product_category.name
                  : 'Uncategorized'}
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <Divider />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2">Cost Price</Typography>
              <Typography>RM {product.cost_price}</Typography>
            </Grid>
            <Grid item xs={12} sx={{ display: { xs: 'block', sm: 'none' } }}>
              <Divider />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2">Value Price</Typography>
              <Typography>RM {product.value_price}</Typography>
            </Grid>
            <Grid item xs={12}>
              <Divider />
            </Grid>
            <Grid item xs={12}>
              <Typography variant="subtitle2">Description</Typography>
              <Typography>{product.description}</Typography>
            </Grid>
            <Grid item xs={12}>
              <Divider />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2">Status</Typography>
              {product.is_available == 1 ? (
                <Chip label="Available" color="primary" />
              ) : (
                <Chip label="Not Available" color="error" />
              )}
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </>
  );
}

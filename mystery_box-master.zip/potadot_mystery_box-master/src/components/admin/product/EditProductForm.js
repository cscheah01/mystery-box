import React, { useState, useEffect } from 'react';
import {
  TextField,
  Card,
  CardContent,
  CardActions,
  Grid,
  Typography,
  Button,
  Box,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  Autocomplete,
  Divider,
} from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useSnackbar } from 'notistack';
import Image from 'next/image';
import emptyImage from '../../../assets/img/empty-image.png';

export default function EditProductForm({
  onSubmit,
  data,
  setTableSetting,
  productCategory,
  setTablePageSetting,
}) {
  const { enqueueSnackbar } = useSnackbar();

  const [previousImage, setPreviousImage] = useState(null);
  const [productImage, setProductImage] = useState(null);
  const [productImageURL, setProductImageURL] = useState(null);
  const [productCategoryValue, setProductCategoryValue] = useState(null);
  const [removeBtnShow, setRemoveBtnShow] = useState(false);
  const [page, setPage] = useState(0);

  const formik = useFormik({
    initialValues: {
      name: '',
      image: '',
      product_category_id: '',
      cost_price: '',
      value_price: '',
      description: '',
      is_available: '',
      ...data,
    },
    validationSchema: Yup.object({
      name: Yup.string().required(),
      product_category_id: Yup.number().required(
        'product category is required field'
      ),
      cost_price: Yup.number().positive().required(),
      value_price: Yup.number().positive().required(),
      description: Yup.string().required().max(3500),
      is_available: Yup.boolean().required(),
    }),
    onSubmit: async (values, { setErrors }) => {
      const formData = new FormData();

      if (productImageURL != null) {
        formData.append('image', values.image);
      }
      formData.append('name', values.name);
      formData.append('product_category_id', values.product_category_id);
      formData.append('cost_price', values.cost_price);
      formData.append('value_price', values.value_price);
      formData.append('description', values.description);
      formData.append('is_available', values.is_available);

      const response = await onSubmit(formData);

      const responseData = response.data;

      if (responseData.success) {
        enqueueSnackbar(responseData.message, {
          variant: 'success',
          autoHideDuration: 3000,
        });
      } else if (response.status == 422) {
        enqueueSnackbar('Please check your input.', {
          variant: 'error',
          autoHideDuration: 3000,
        });

        setErrors(responseData.message);
      }
    },
  });

  useEffect(() => {
    const file = productImage;

    if (file) {
      setRemoveBtnShow(true);
      if (previousImage != null) {
        setPreviousImage(formik.values.image);
      }
      formik.values.image = file;
      let reader = new FileReader();
      reader.onload = function (event) {
        setProductImageURL(event.target.result);
      };
      reader.readAsDataURL(file);
    }
  }, [productImage]);

  const onSubmitClick = () => {
    if (Object.keys(formik.errors).length > 0) {
      enqueueSnackbar('Please check your input.', {
        variant: 'error',
        autoHideDuration: 3000,
      });
    }
  };

  const removeImage = () => {
    formik.values.image = previousImage;
    setProductImageURL(null);
    setProductImage(null);
    setRemoveBtnShow(false);
  };

  return (
    <>
      <form onSubmit={formik.handleSubmit}>
        <Card>
          <CardContent>
            <Typography variant="subtitle1" mb={3}>
              General Details
            </Typography>

            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Box
                  sx={{
                    border: 2,
                    borderColor: '#9e9e9e',
                    borderRadius: 2,
                    margin: 'auto',
                    width: '150px',
                    height: '150px',
                    position: 'relative',
                    overflow: 'hidden',
                    alignItems: 'center',
                  }}
                >
                  {formik.values.image != '' && productImageURL != null ? (
                    <Image
                      src={productImageURL}
                      layout="fill"
                      objectFit="cover"
                      onError={() => setProductImageURL(emptyImage)}
                    />
                  ) : (
                    <Image
                      src={formik.values.image_url}
                      layout="fill"
                      objectFit="cover"
                      onError={() => (formik.values.image_url = emptyImage)}
                    />
                  )}
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Typography
                  sx={{
                    mb: 2,
                    textAlign: 'center',
                    display: productImage != null ? 'block' : 'none',
                  }}
                >
                  {productImage != null && formik.values.image != null
                    ? formik.values.image.name
                    : formik.values.image}
                </Typography>

                <Box
                  sx={{
                    textAlign: 'center',
                  }}
                >
                  <Button variant="contained" component="label">
                    Select File
                    <input
                      type="file"
                      hidden
                      name="image"
                      accept=".png,.jpg,.jpeg"
                      onChange={(e) => {
                        setProductImage(e.target.files[0]);
                      }}
                    />
                  </Button>
                  <Button
                    onClick={removeImage}
                    variant="contained"
                    component="label"
                    color="error"
                    sx={{
                      ml: 1,
                      display: removeBtnShow == true ? 'inline-block' : 'none',
                    }}
                  >
                    Remove
                  </Button>
                </Box>

                <Typography
                  sx={{
                    display:
                      formik.errors.image != null &&
                      formik.touched.image != null
                        ? 'block'
                        : 'none',
                    color: '#D14343',
                    fontWeight: 400,
                    lineHeight: 1.66,
                    fontSize: '0.75rem',
                    mt: '3px',
                    textAlign: 'center',
                  }}
                >
                  {formik.errors.image}
                </Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Name"
                  type="text"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="name"
                  value={formik.values.name}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(formik.touched.name && formik.errors.name)}
                  helperText={formik.touched.name && formik.errors.name}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <Autocomplete
                  disablePortal
                  value={productCategoryValue ?? formik.values.product_category}
                  ListboxProps={{
                    onScroll: (event) => {
                      event.stopPropagation();
                      const listboxNode = event.currentTarget;
                      const savedScrollTop = listboxNode.scrollTop;
                      const diff = Math.round(
                        listboxNode.scrollHeight - savedScrollTop
                      );
                      if (diff - 25 <= listboxNode.clientHeight) {
                        setPage((page) => page + 1);
                        setTablePageSetting(page);
                      }
                    },
                  }}
                  onChange={(event, newValue) => {
                    if (newValue != null) {
                      formik.values.product_category_id = newValue.id;
                      setProductCategoryValue(newValue);
                    }
                  }}
                  onInputChange={(event, newInputValue) => {
                    setTableSetting({ name: newInputValue });
                    setPage(0);
                  }}
                  options={productCategory}
                  isOptionEqualToValue={(option, value) =>
                    option.name === value
                  }
                  getOptionLabel={(option) => option.name ?? ''}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Product Category"
                      InputLabelProps={{ shrink: true }}
                      error={Boolean(
                        formik.touched.product_category_id &&
                          formik.errors.product_category_id
                      )}
                      helperText={
                        formik.touched.product_category_id &&
                        formik.errors.product_category_id
                      }
                      placeholder="Click to select"
                    />
                  )}
                />
                <Typography
                  sx={{
                    display:
                      formik.errors.product_category_id != null &&
                      formik.touched.product_category_id != null
                        ? 'block'
                        : 'none',
                    color: '#D14343',
                    fontWeight: 400,
                    lineHeight: 1.66,
                    fontSize: '0.75rem',
                    mt: '3px',
                    mr: 2,
                    mb: 0,
                    ml: 2,
                  }}
                >
                  {formik.errors.product_category_id}
                </Typography>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  label="Description"
                  type="text"
                  fullWidth
                  multiline
                  rows={3}
                  InputLabelProps={{ shrink: true }}
                  name="description"
                  value={formik.values.description}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(
                    formik.touched.description && formik.errors.description
                  )}
                  helperText={
                    formik.touched.description && formik.errors.description
                  }
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl>
                  <FormLabel id="is-available-label">Status</FormLabel>
                  <RadioGroup
                    row
                    aria-labelledby="is-available-label"
                    name="is_available"
                    value={formik.values.is_available}
                    onChange={formik.handleChange}
                  >
                    <FormControlLabel
                      value="1"
                      control={<Radio />}
                      label="Available"
                    />
                    <FormControlLabel
                      value="0"
                      control={<Radio />}
                      label="Not Available"
                    />
                  </RadioGroup>
                  <Typography
                    sx={{
                      display:
                        formik.errors.is_available != null &&
                        formik.touched.is_available != null
                          ? 'block'
                          : 'none',
                      color: '#D14343',
                      fontWeight: 400,
                      lineHeight: 1.66,
                      fontSize: '0.75rem',
                      mt: '3px',
                      mr: 2,
                      mb: 0,
                      ml: 2,
                    }}
                  >
                    {formik.errors.is_available}
                  </Typography>
                </FormControl>
              </Grid>
            </Grid>

            <Box py={3}>
              <Divider />
            </Box>

            <Typography variant="subtitle1" mb={3}>
              Price
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  type="number"
                  label="Cost Price"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="cost_price"
                  value={formik.values.cost_price}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(
                    formik.touched.cost_price && formik.errors.cost_price
                  )}
                  helperText={
                    formik.touched.cost_price && formik.errors.cost_price
                  }
                  inputProps={{
                    step: '0.01',
                    min: '0',
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  type="number"
                  label="Value Price"
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  name="value_price"
                  value={formik.values.value_price}
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  error={Boolean(
                    formik.touched.value_price && formik.errors.value_price
                  )}
                  helperText={
                    formik.touched.value_price && formik.errors.value_price
                  }
                  inputProps={{
                    step: '0.01',
                    min: '0',
                  }}
                />
              </Grid>
            </Grid>
          </CardContent>
          <CardActions>
            <Grid container spacing={1} justifyContent="flex-end">
              <Grid item>
                <LoadingButton
                  variant="contained"
                  type="submit"
                  loading={formik.isSubmitting}
                  disabled={formik.isSubmitting}
                  onClick={() => {
                    onSubmitClick();
                  }}
                >
                  Save
                </LoadingButton>
              </Grid>
            </Grid>
          </CardActions>
        </Card>
      </form>
    </>
  );
}

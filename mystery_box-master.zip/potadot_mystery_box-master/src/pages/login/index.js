import React from 'react';
import Head from 'next/head';
import {
  Box,
  Typography,
  Divider,
  Container,
  Button,
  TextField,
} from '@mui/material';
import Link from 'next/link';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { postRequest } from '../../utils/apiHelper';
import GoogleIcon from '@mui/icons-material/Google';
import Layout from '../../components/public/layout/Layout';

export default function Login() {
  const formik = useFormik({
    initialValues: {
      email: '',
      password: '',
    },
    validationSchema: Yup.object({
      email: Yup.string()
        .email('Must be a valid email')
        .required('Email is required'),
      password: Yup.string().required('Password is required'),
    }),
    onSubmit: async (values) => {
      // const response = await postRequest(`${config.appUrl}/api/login`, values);
      // const responseData = response.data;
      // if (responseData.success) {
      //   router.push('/');
      // }
    },
  });

  return (
    <>
      <Head>
        <title>Login</title>
      </Head>
      <Layout>
        <Container
          maxWidth={false}
          sx={{
            '&': {
              p: 0,
              pt: 20,
              backgroundColor: '#000000',
            },
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: '100vh',
          }}
        >
          <Box
            sx={{
              borderRadius: 5,
              backgroundColor: '#212121',
              p: 3,
              color: '#ffffff',
              mx: 2,
              width: { xs: '100%', md: '50%' },
            }}
          >
            <form onSubmit={formik.handleSubmit}>
              <Typography variant="h5" sx={{ textAlign: 'center' }}>
                Login
              </Typography>
              <TextField
                error={Boolean(formik.touched.email && formik.errors.email)}
                fullWidth
                helperText={formik.touched.email && formik.errors.email}
                label="Email Address"
                margin="normal"
                name="email"
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                type="email"
                value={formik.values.email}
                variant="outlined"
                InputLabelProps={{
                  shrink: true,
                  style: { color: '#ffffff', backgroundColor: '#212121' },
                }}
                sx={{
                  input: { color: '#ffffff' },
                  '& fieldset': {
                    borderColor: '#ffffff',
                  },
                }}
              />
              <TextField
                error={Boolean(
                  formik.touched.password && formik.errors.password
                )}
                fullWidth
                helperText={formik.touched.password && formik.errors.password}
                label="Password"
                margin="normal"
                name="password"
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                type="password"
                value={formik.values.password}
                variant="outlined"
                InputLabelProps={{
                  shrink: true,
                  style: { color: '#ffffff' },
                }}
                sx={{
                  input: { color: '#ffffff' },
                  '& fieldset': {
                    borderColor: 'white',
                    color: 'white',
                  },
                }}
              />
              <Link
                passHref
                href={'forgot-password'}
                sx={{ color: '#ffffff', textDecoration: 'none' }}
              >
                Forgot your password?
              </Link>
              <Box sx={{ py: 2 }}>
                <Button
                  color="primary"
                  disabled={formik.isSubmitting}
                  fullWidth
                  size="large"
                  type="submit"
                  variant="contained"
                >
                  Login
                </Button>
              </Box>
              <Divider
                sx={{
                  '&::before,&::after': {
                    borderTop: 3,
                    borderColor: '#ffffff',
                  },
                }}
              >
                Or log in as
              </Divider>
              <Box sx={{ textAlign: 'center', my: 2 }}>
                <Link passhref href={'#'} sx={{ textDecoration: 'none' }}>
                  <Button
                    sx={{ color: '#ffffff', fontWeight: 'bold' }}
                    startIcon={<GoogleIcon />}
                  >
                    <Typography sx={{ fontWeight: 'bold', lineHeight: 0 }}>
                      Google
                    </Typography>
                  </Button>
                </Link>
              </Box>
              <Typography
                gutterBottom
                variant="body2"
                sx={{ textAlign: 'center' }}
              >
                Don't have an account?
                <Link
                  passhref
                  href={'register'}
                  sx={{ ml: 2, color: '#3f51b5' }}
                >
                  Create an account
                </Link>
              </Typography>
            </form>
          </Box>
        </Container>
      </Layout>
    </>
  );
}

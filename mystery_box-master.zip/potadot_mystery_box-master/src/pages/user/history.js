import React, { useState } from 'react';
import Head from 'next/head';
import Layout from '../../components/public/layout/Layout';
import { Box, Typography, Tabs, Tab } from '@mui/material';

export default function History() {
  const [tabIndex, setTabIndex] = useState(0);

  const handleTabChange = (event, newTabIndex) => {
    setTabIndex(newTabIndex);
  };

  return (
    <>
      <Head>
        <title>History</title>
      </Head>
      <Layout>
        <Box sx={{ px: { xs: 4, md: 10 }, paddingTop: 20, minHeight: '100vh' }}>
          <Typography variant="h4" sx={{ color: '#ffffff', mb: 2 }}>
            History
          </Typography>
          <Box sx={{ backgroundColor: '#212121', px: 2, color: '#ffffff' }}>
            <Box>
              <Tabs value={tabIndex} onChange={handleTabChange}>
                <Tab label="Unboxings" />
                <Tab label="Deposit" />
                <Tab label="Order" />
              </Tabs>
            </Box>
            <Box sx={{ padding: 2 }}>
              {tabIndex === 0 && (
                <Box>
                  <Typography>The first tab</Typography>
                </Box>
              )}
              {tabIndex === 1 && (
                <Box>
                  <Typography>The second tab</Typography>
                </Box>
              )}
              {tabIndex === 2 && (
                <Box>
                  <Typography>The third tab</Typography>
                </Box>
              )}
            </Box>
          </Box>
        </Box>
      </Layout>
    </>
  );
}

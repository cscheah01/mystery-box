import React, { useState } from 'react';
import Head from 'next/head';
import Layout from '../../components/public/layout/Layout';
import {
  Box,
  Typography,
  FormControlLabel,
  Checkbox,
  TextField,
  Button,
  Divider,
  Grid,
} from '@mui/material';
import InventoryItems from '../../public/InventoryItems';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';

export default function Inventory() {
  const array = [...Array(15)];
  const [desc, setDecs] = useState(false);

  const handlePriceFilterClick = () => {
    if (desc == false) {
      setDecs(true);
    } else {
      setDecs(false);
    }
  };
  return (
    <>
      <Head>
        <title>Inventory</title>
      </Head>
      <Layout>
        <Box sx={{ px: { xs: 4, md: 10 }, paddingTop: 20 }}>
          <Typography variant="h4" sx={{ color: '#ffffff', mb: 2 }}>
            Inventory
          </Typography>
          <Box
            sx={{ backgroundColor: '#212121', px: 2, pt: 1, color: '#ffffff' }}
          >
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
              }}
            >
              <FormControlLabel
                control={<Checkbox />}
                label="Select All"
                sx={{
                  width: '150px',
                  display: { xs: 'none', md: 'inline-flex' },
                }}
              />

              <TextField
                variant="standard"
                name="search"
                fullWidth
                placeholder="Search Item..."
                InputProps={{
                  disableUnderline: true,
                }}
                sx={{ mr: 2 }}
              />
              <Button
                sx={{ ml: 'auto', display: { xs: 'none', md: 'inline-flex' } }}
                endIcon={desc ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                onClick={handlePriceFilterClick}
              >
                Price
              </Button>
            </Box>
            <Box
              sx={{
                display: { xs: 'flex', md: 'none' },
                justifyContent: 'center',
              }}
            >
              <Divider sx={{ my: 1 }} />
              <FormControlLabel
                control={<Checkbox />}
                label="Select All"
                sx={{
                  mr: 2,
                }}
              />
              <Button
                endIcon={desc ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                onClick={handlePriceFilterClick}
              >
                Price
              </Button>
            </Box>
            <Divider sx={{ my: 1 }} />
            <Box>
              <Typography>Total Result : {array.length}</Typography>
              <Box sx={{ my: 4 }}>
                <Grid container columnSpacing={3}>
                  {array.map(() => (
                    <Grid item xs={6} sm={4} md={3} xl={2}>
                      <InventoryItems />
                    </Grid>
                  ))}
                </Grid>
              </Box>
            </Box>
          </Box>
        </Box>
      </Layout>
    </>
  );
}

import React, { useEffect, useState } from 'react';
import Head from 'next/head';
import Layout from '../../components/public/layout/Layout';
import { Box, Typography, Button } from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import AccountDetailsForm from '../../components/public/user/profile/accountDetailsForm';
import ShippingInformationForm from '../../components/public/user/profile/ShippingInformationForm';
import isLoggedIn from '../../utils/isLoggedIn';
import { getProfileDetails, updateProfile } from '../../services/userService';
import { getShippingAddressDetails } from '../../services/shippingAddressService';
import ProfileSkeleton from '../../components/user/skeleton/ProfileSkeleton';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function Profile() {
  const [isLoading, setIsLoading] = useState(true);
  const [profile, setProfile] = useState();
  const [shippingAddress, setShippingAddress] = useState();

  const onSubmitChangeAccountDetails = async (data) => {
    // const response = await createStaff(data);
    // const responseData = response.data;
    // if (responseData.success) {
    //   router.push(`/admin/staff/${responseData.data.id}`);
    // }
    // return response;
  };

  const onSubmitChangeShippingAccount = async (data) => {
    // const response = await createStaff(data);
    // const responseData = response.data;
    // if (responseData.success) {
    //   router.push(`/admin/staff/${responseData.data.id}`);
    // }
    // return response;
  };

  const fetchProfileData = async () => {
    const response = await getProfileDetails();
    return response;
  };

  const fetchShippingAddressData = async () => {
    const response = await getShippingAddressDetails();
    return response;
  };

  useEffect(() => {
    setIsLoading(true);

    fetchProfileData().then((response) => {
      const responseData = response.data;

      if (responseData.success) {
        setProfile(responseData.data);

        return;
      }
    });

    fetchShippingAddressData().then((response) => {
      const responseData = response.data;

      if (responseData.success) {
        setShippingAddress(responseData.data);
        setIsLoading(false);

        return;
      }
    });
  }, []);

  return (
    <>
      <Head>
        <title>Profile</title>
      </Head>
      <Layout>
        {isLoading ? (
          <ProfileSkeleton />
        ) : (
          <>
            <Box sx={{ px: { xs: 4, md: 10 }, paddingTop: 20 }}>
              <Box
                sx={{
                  backgroundColor: '#212121',
                  borderRadius: 5,
                }}
              >
                <Box
                  sx={{
                    backgroundColor: '#4D4D4D',
                    px: 3,
                    py: 2,
                    color: '#ffffff',
                    display: 'flex',
                  }}
                >
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
                      RM 10,000,000
                    </Typography>
                    <Typography variant="body2">Wallet Balance</Typography>
                  </Box>

                  <Button startIcon={<AddCircleOutlineIcon />}>
                    Add Money To Wallet
                  </Button>
                </Box>

                <AccountDetailsForm
                  data={profile}
                  onSubmit={onSubmitChangeAccountDetails}
                />
              </Box>
            </Box>

            <Box sx={{ px: { xs: 4, md: 10 }, paddingTop: 5 }}>
              <Box
                sx={{
                  backgroundColor: '#212121',
                  borderRadius: 5,
                }}
              >
                <Box
                  sx={{
                    backgroundColor: '#4D4D4D',
                    px: 3,
                    py: 2,
                    color: '#ffffff',
                    display: 'flex',
                  }}
                >
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
                      Shipping Information
                    </Typography>
                  </Box>
                </Box>

                <ShippingInformationForm
                  data={shippingAddress}
                  onSubmit={onSubmitChangeShippingAccount}
                />
              </Box>
            </Box>
          </>
        )}
      </Layout>
    </>
  );
}

import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../components/public/layout/Layout';
import { Box, Grid, Typography } from '@mui/material';
import CategoryScrollMenu from '../components/public/scrollMenu/CategoryScrollMenu';
import SingleBox from '../components/public/box/SingleBox';
import DividerWithText from '../components/public/divider/DividerWithText';
import { getAllBoxCategory } from '../services/boxCategoryService';
import { getAllBox } from '../services/boxService';
import PublicPageSkeleton from '../components/public/skeleton/publicPageSkeleton';
import emptyData from '../assets/img/empty-data.png';
import Image from 'next/image';
import InfiniteScroll from 'react-infinite-scroll-component';

export default function Home() {
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState({
    box_category_id: null,
    page: 0,
  });

  const fetchBoxCategoryData = async () => {
    setIsLoading(true);
    const response = await getAllBoxCategory();

    const responseData = response.data;

    if (responseData.success) {
      setCategories(responseData.data);

      return;
    }
  };

  useEffect(() => {
    fetchBoxCategoryData();
  }, [null]);

  const [boxes, setBoxes] = useState([]);
  const [hasMore, setHasMore] = useState(true);

  const fetchBoxData = async () => {
    setHasMore(true);
    const response = await getAllBox(filter);

    const responseData = response.data;

    if (responseData.success) {
      if (responseData.data.length != 0) {
        if (filter.page == 0) {
          setBoxes(responseData.data);
        } else {
          setBoxes([...boxes, ...responseData.data]);
        }
      } else {
        if (filter.page == 0) {
          setBoxes(null);
        }

        setHasMore(false);
      }

      setIsLoading(false);

      return;
    }
  };

  useEffect(() => {
    fetchBoxData();
  }, [null, filter]);

  const fetchMoreBoxData = () => {
    var page = filter.page;
    setFilter({
      ...filter,
      page: page + 1,
    });
  };

  return (
    <>
      <Head>
        <title>Home</title>
      </Head>
      <Layout>
        {isLoading ? (
          <PublicPageSkeleton />
        ) : (
          <>
            <Box sx={{ px: { xs: 4, md: 8.5 }, paddingTop: 20 }}>
              <DividerWithText text={'LIST OF MYSTERY BOXES'} />
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'center',
                }}
              >
                <Box
                  sx={{
                    marginTop: '5%',
                    maxWidth: '100%',
                  }}
                >
                  <CategoryScrollMenu
                    categories={categories}
                    setFilter={(data) => {
                      setFilter({
                        ...filter,
                        box_category_id: data,
                        page: 0,
                      });
                      setBoxes([]);
                    }}
                  />
                </Box>
              </Box>

              <Box sx={{ my: 10 }}>
                {boxes == null ? (
                  <>
                    <Box sx={{ margin: 'auto' }}>
                      <Box
                        sx={{
                          width: '150px',
                          height: '150px',
                          position: 'relative',
                          margin: 'auto',
                          overflow: 'hidden',
                        }}
                      >
                        <Image
                          src={emptyData}
                          layout="fill"
                          objectFit="cover"
                        />
                      </Box>
                      <Typography
                        sx={{ color: '#ffffff', textAlign: 'center', mt: 2 }}
                      >
                        No Box Found
                      </Typography>
                    </Box>
                  </>
                ) : (
                  <InfiniteScroll
                    dataLength={boxes.length}
                    next={fetchMoreBoxData}
                    hasMore={hasMore}
                    loader={
                      <Box>
                        <Box className="center">
                          <Box className="wave"></Box>
                          <Box className="wave"></Box>
                          <Box className="wave"></Box>
                          <Box className="wave"></Box>
                          <Box className="wave"></Box>
                          <Box className="wave"></Box>
                          <Box className="wave"></Box>
                          <Box className="wave"></Box>
                          <Box className="wave"></Box>
                          <Box className="wave"></Box>
                        </Box>
                        <Typography
                          sx={{
                            color: '#ffffff',
                            textAlign: 'center',
                            mt: 2,
                          }}
                        >
                          Loading...
                        </Typography>
                      </Box>
                    }
                  >
                    <Grid container columnSpacing={3}>
                      {boxes.map((box) => (
                        <Grid item xs={6} sm={4} md={3} xl={2} key={box.id}>
                          <SingleBox data={box} />
                        </Grid>
                      ))}
                    </Grid>
                  </InfiniteScroll>
                )}
              </Box>
            </Box>
          </>
        )}
      </Layout>
    </>
  );
}

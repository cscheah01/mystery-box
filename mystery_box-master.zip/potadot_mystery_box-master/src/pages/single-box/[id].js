import React, { useEffect, useState } from 'react';
import Head from 'next/head';
import Layout from '../../components/public/layout/Layout';
import { Box, Typography, Grid } from '@mui/material';
import emptyImage from '../../assets/img/empty-image.png';
import DividerWithText from '../../components/public/divider/DividerWithText';
import BoxItems from '../../components/public/box/BoxItem';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { getSingleBoxDetails } from '../../services/boxService';
import SingleBoxSkeleton from '../../components/public/skeleton/SingleBoxSkeleton';
import { getAllBoxItem } from '../../services/boxItemService';
import emptyData from '../../assets/img/empty-data.png';
import Roulette from '../../components/public/roulette/Roulette';

export default function SingleBox() {
  const router = useRouter();
  const { id } = router.query;

  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!id) {
      return;
    }

    setIsLoading(true);

    fetchData(id).then((response) => {
      const responseData = response.data;

      if (responseData.success) {
        setBoxDetails(responseData.data);
        setIsLoading(false);

        return;
      }
    });

    fetchBoxItemData(id);
  }, [id]);

  const [boxDetails, setBoxDetails] = useState(null);

  const fetchData = async (id) => {
    const response = await getSingleBoxDetails({ id: id });
    return response;
  };

  useEffect(() => {
    if (boxDetails != null) {
      if (boxDetails.image_url != null) {
        setSrc(boxDetails.image_url);
      }
    }
  }, [boxDetails]);

  const [src, setSrc] = useState(emptyImage);

  const [boxItems, setBoxItems] = useState([]);

  const fetchBoxItemData = async (id) => {
    const response = await getAllBoxItem({ id: id });

    const responseData = response.data;
    if (responseData.success) {
      if (responseData.data.length != 0) {
        setBoxItems(responseData.data);
      } else {
        setBoxItems(null);
      }

      return;
    }
  };

  const ReadMore = ({ children }) => {
    const text = children;
    const [isReadMore, setIsReadMore] = useState(true);
    const toggleReadMore = () => {
      setIsReadMore(!isReadMore);
    };
    return (
      <Box
        fontSize={15}
        sx={{
          color: '#ffffff',
        }}
      >
        {isReadMore ? text.slice(0, 500) : text}
        {text.length >= 500 ? (
          <span onClick={toggleReadMore} className="read-or-hide">
            {isReadMore ? '...read more' : ' show less'}
          </span>
        ) : null}
      </Box>
    );
  };

  return (
    <>
      <Head>
        <title>Single Box</title>
      </Head>
      <Layout>
        {isLoading ? (
          <SingleBoxSkeleton />
        ) : (
          <>
            <Box
              sx={{ px: { xs: 4, md: 8.5 }, paddingTop: { xs: 15, md: 20 } }}
            >
              <Roulette />

              <DividerWithText text={'BOX DETAILS'} />
              <Box
                sx={{
                  bgcolor: 'grey.900',
                  border: 0.5,
                  borderColor: '#646262',
                  borderRadius: 10,
                  mx: { xs: 1, sm: 2, md: 5 },
                  my: 5,
                  pt: { xs: 2, md: 5 },
                  pb: 5,
                  px: 2,
                }}
              >
                <Grid container>
                  <Grid
                    item
                    xs={12}
                    md={6}
                    sx={{
                      mb: 2,
                    }}
                  >
                    <Box
                      sx={{
                        width: { xs: '150px', md: '300px' },
                        height: { xs: '150px', md: '300px' },
                        position: 'relative',
                        margin: 'auto',
                        overflow: 'hidden',
                      }}
                    >
                      <Image
                        src={src}
                        layout="fill"
                        objectFit="cover"
                        onError={() => setSrc(emptyImage)}
                      />
                    </Box>
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <Typography
                          variant="h5"
                          sx={{
                            textAlign: { xs: 'center', md: 'left' },
                            fontWeight: 'bold',
                            color: '#ff9800',
                          }}
                        >
                          {boxDetails.name}
                        </Typography>
                      </Grid>
                      <Grid item xs={12}>
                        <Typography
                          variant="h5"
                          sx={{
                            textAlign: { xs: 'center', md: 'left' },
                            fontWeight: 'bold',
                            color: '#ffffff',
                          }}
                        >
                          RM {boxDetails.price}
                        </Typography>
                      </Grid>
                      <Grid item xs={12}>
                        <ReadMore>{boxDetails.description}</ReadMore>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Box>
              <DividerWithText text={'WHAT ITEMS IN THE BOX'} />

              <Box sx={{ my: 5 }}>
                <Grid container columnSpacing={3}>
                  {boxItems == null ? (
                    <>
                      <Box sx={{ margin: 'auto' }}>
                        <Box
                          sx={{
                            width: '150px',
                            height: '150px',
                            position: 'relative',
                            margin: 'auto',
                            overflow: 'hidden',
                          }}
                        >
                          <Image
                            src={emptyData}
                            layout="fill"
                            objectFit="cover"
                          />
                        </Box>
                        <Typography
                          sx={{ color: '#ffffff', textAlign: 'center', mt: 2 }}
                        >
                          No Box Item Found
                        </Typography>
                      </Box>
                    </>
                  ) : (
                    boxItems.map((boxitem) => (
                      <Grid item xs={6} sm={4} md={3} xl={2}>
                        <BoxItems data={boxitem} />
                      </Grid>
                    ))
                  )}
                </Grid>
              </Box>
            </Box>
          </>
        )}
      </Layout>
    </>
  );
}

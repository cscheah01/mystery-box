import Cookies from 'cookies';
import { login } from '../../services/authService';

export default async (req, res) => {
  const cookies = new Cookies(req, res);

  const data = {
    email: req.body.email,
    password: req.body.password,
  };

  const response = await login(data);

  const responseData = response.data;

  if (responseData.success == true) {
    cookies.set('jwt', responseData.data.token, {
      httpOnly: true,
      sameSite: 'lax',
    });
  }

  return res.status(response.status).json(responseData);
};

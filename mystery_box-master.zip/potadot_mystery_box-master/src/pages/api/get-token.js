import Cookies from 'cookies';

export default async (req, res) => {
  const cookies = new Cookies(req, res);
  const token = cookies.get('jwt');

  return res.status(200).json({
    success: true,
    token,
  });
};

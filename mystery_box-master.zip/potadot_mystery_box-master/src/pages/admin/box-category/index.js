import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../../../components/admin/layout/Layout';
import Link from 'next/link';
import { Box, Container, Typography, Button, Grid } from '@mui/material';
import BoxCategoryTableSearchForm from '../../../components/admin/boxCategory/BoxCategorySearchForm';
import BoxCategoryTable from '../../../components/admin/boxCategory/BoxCategoryTable';
import isLoggedIn from '../../../utils/isLoggedIn';
import {
  getBoxCategoryList,
  deleteBoxCategory,
} from '../../../services/boxCategoryService';
import TableSkeleton from '../../../components/admin/skeleton/TableSkeleton';
import DeleteConfirmationDialog from '../../../components/admin/common/DeleteConfirmationDialog';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function ProductCategoryIndex() {
  const [isLoading, setIsLoading] = useState(true);

  const [tableData, setTableData] = useState([]);
  const [tableSetting, setTableSetting] = useState({
    page: {
      number: 0,
      quantity: 10,
    },
    sort: {
      column: 'created_at',
      order: 'desc',
    },
    filter: {
      name: '',
    },
  });
  const [totalResult, setTotalResult] = useState(0);

  const [deleteConfirmation, setDeleteConfirmation] = useState({
    isOpen: false,
    id: null,
  });

  const fetchData = async () => {
    setIsLoading(true);

    const response = await getBoxCategoryList(tableSetting);

    const responseData = response.data;

    if (responseData.success) {
      setTableData(responseData.data.list);
      setTotalResult(responseData.data.totalResult);
      setIsLoading(false);

      return;
    }
  };

  useEffect(() => {
    fetchData();
  }, [null, tableSetting]);

  const handleDeleteConfirmation = (id) => {
    setDeleteConfirmation({ ...deleteConfirmation, isOpen: true, id: id });
  };

  const onDelete = async () => {
    const response = await deleteBoxCategory({ id: deleteConfirmation.id });

    const responseData = response.data;
    if (responseData.success) {
      fetchData();
    }

    return response;
  };

  return (
    <>
      <Head>
        <title>Box Category | Admin Portal</title>
      </Head>
      <Layout>
        <Box
          sx={{
            py: 8,
          }}
        >
          <Container maxWidth={false}>
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
              }}
            >
              <Typography sx={{ m: 1 }} variant="h4">
                Box Category
              </Typography>
              <Box sx={{ m: 1 }}>
                <Grid container spacing={1} justifyContent="flex-end">
                  <Grid item>
                    <Link href={'/admin/box-category/create'} passHref>
                      <Button color="primary" variant="contained">
                        Create Box Category
                      </Button>
                    </Link>
                  </Grid>
                </Grid>
              </Box>
            </Box>

            <Box sx={{ mt: 3 }}>
              <BoxCategoryTableSearchForm
                data={tableSetting.filter}
                onSubmit={(data) => {
                  setTableSetting({ ...tableSetting, filter: data });
                }}
              />
            </Box>

            <Box sx={{ mt: 3 }}>
              {isLoading ? (
                <TableSkeleton />
              ) : (
                <BoxCategoryTable
                  tableData={tableData}
                  totalResult={totalResult}
                  tableSetting={tableSetting}
                  handleChange={(data) => {
                    setTableSetting(data);
                  }}
                  handleDelete={(id) => {
                    handleDeleteConfirmation(id);
                  }}
                />
              )}
            </Box>

            <DeleteConfirmationDialog
              isOpen={deleteConfirmation.isOpen}
              onClose={() => {
                setDeleteConfirmation({ isOpen: false });
              }}
              id={deleteConfirmation.id}
              confirmDelete={onDelete}
            />
          </Container>
        </Box>
      </Layout>
    </>
  );
}

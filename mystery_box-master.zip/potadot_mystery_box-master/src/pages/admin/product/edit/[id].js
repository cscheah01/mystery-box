import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../../../../components/admin/layout/Layout';
import Link from 'next/link';
import { Box, Container, Typography, Button, Grid } from '@mui/material';
import isLoggedIn from '../../../../utils/isLoggedIn';
import { useRouter } from 'next/router';
import {
  getProductDetails,
  updateProduct,
} from '../../../../services/productService';
import { getProductCategoryList } from '../../../../services/productCategoryService';
import EditProductForm from '../../../../components/admin/product/EditProductForm';
import DetailsSkeleton from '../../../../components/admin/skeleton/DetailsSkeleton';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function EditProduct() {
  const router = useRouter();
  const { id } = router.query;

  const [product, setProduct] = useState({ id: id });
  const [productCategory, setProductCategory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const [tableSetting, setTableSetting] = useState({
    page: {
      number: 0,
      quantity: 10,
    },
    sort: {
      column: 'created_at',
      order: 'desc',
    },
    filter: {
      name: '',
    },
  });

  const fetchProductCategory = async () => {
    const response = await getProductCategoryList(tableSetting);

    const responseData = response.data;

    if (responseData.success) {
      if (responseData.data.list.length != 0) {
        if (tableSetting.page.number == 0) {
          setProductCategory(responseData.data.list);
        } else {
          setProductCategory([...productCategory, ...responseData.data.list]);
        }
      }

      return;
    }
  };

  useEffect(() => {
    fetchProductCategory();
  }, [null, tableSetting]);

  const fetchData = async () => {
    const response = await getProductDetails(product);
    return response;
  };

  useEffect(() => {
    setIsLoading(true);

    fetchData().then((response) => {
      const responseData = response.data;

      if (responseData.success) {
        setProduct(responseData.data);
        setIsLoading(false);

        return;
      }
    });
  }, []);

  const onSubmit = async (data) => {
    const response = await updateProduct(id, data);
    const responseData = response.data;

    if (responseData.success) {
      router.push(`/admin/product/${responseData.data.id}`);
    }

    return response;
  };

  return (
    <>
      <Head>
        <title>Edit Product | Admin Portal</title>
      </Head>
      <Layout>
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            py: 8,
          }}
        >
          <Container maxWidth={false}>
            {isLoading ? (
              <DetailsSkeleton />
            ) : (
              <>
                <Box
                  sx={{
                    alignItems: 'center',
                    display: 'flex',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    m: -1,
                  }}
                >
                  <Typography sx={{ m: 1 }} variant="h4">
                    Edit Product
                  </Typography>
                  <Box sx={{ m: 1 }}>
                    <Grid container spacing={1} justifyContent="flex-end">
                      <Grid item>
                        <Link href={`/admin/product/${id}`} passHref>
                          <Button color="dark" variant="contained">
                            Back
                          </Button>
                        </Link>
                      </Grid>
                    </Grid>
                  </Box>
                </Box>

                <Box sx={{ mt: 3 }}>
                  <EditProductForm
                    data={product}
                    onSubmit={onSubmit}
                    productCategory={productCategory}
                    setTablePageSetting={(data) => {
                      setTableSetting({
                        ...tableSetting,
                        page: { number: data, quantity: 10 },
                      });
                    }}
                    setTableSetting={(data) => {
                      setTableSetting({
                        ...tableSetting,
                        filter: data,
                        page: { number: 0, quantity: 10 },
                      });
                    }}
                  />
                </Box>
              </>
            )}
          </Container>
        </Box>
      </Layout>
    </>
  );
}

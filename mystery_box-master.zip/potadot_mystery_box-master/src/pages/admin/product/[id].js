import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../../../components/admin/layout/Layout';
import Link from 'next/link';
import { Box, Container, Typography, Button, Grid } from '@mui/material';
import ProductDetails from '../../../components/admin/product/ProductDetails';
import isLoggedIn from '../../../utils/isLoggedIn';
import { useRouter } from 'next/router';
import {
  getProductDetails,
  deleteProduct,
} from '../../../services/productService';
import DetailsSkeleton from '../../../components/admin/skeleton/DetailsSkeleton';
import DeleteConfirmationDialog from '../../../components/admin/common/DeleteConfirmationDialog';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function ViewProduct() {
  const router = useRouter();
  const { id } = router.query;

  const [product, setProduct] = useState({ id: id });
  const [isLoading, setIsLoading] = useState(true);

  const [deleteConfirmation, setDeleteConfirmation] = useState({
    isOpen: false,
    id: id,
  });

  const fetchData = async () => {
    const response = await getProductDetails(product);
    return response;
  };

  useEffect(() => {
    setIsLoading(true);

    fetchData().then((response) => {
      const responseData = response.data;

      if (responseData.success) {
        setProduct(responseData.data);
        setIsLoading(false);

        return;
      }
    });
  }, []);

  const handleDeleteConfirmation = () => {
    setDeleteConfirmation({ ...deleteConfirmation, isOpen: true });
  };

  const onDelete = async () => {
    const response = await deleteProduct({ id: deleteConfirmation.id });

    const responseData = response.data;
    if (responseData.success) {
      router.push('/admin/product');
    }

    return response;
  };

  return (
    <>
      <Head>
        <title>Product Details | Admin Portal</title>
      </Head>
      <Layout>
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            py: 8,
          }}
        >
          <Container maxWidth={false}>
            {isLoading ? (
              <DetailsSkeleton />
            ) : (
              <>
                <Box
                  sx={{
                    alignItems: 'center',
                    display: 'flex',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    m: -1,
                  }}
                >
                  <Typography sx={{ m: 1 }} variant="h4">
                    Product Details
                  </Typography>
                  <Box sx={{ m: 1 }}>
                    <Grid container spacing={1} justifyContent="flex-end">
                      <Grid item>
                        <Link href={'/admin/product'} passHref>
                          <Button color="dark" variant="contained">
                            Back
                          </Button>
                        </Link>
                      </Grid>
                      <Grid item>
                        <Button
                          color="error"
                          variant="contained"
                          onClick={handleDeleteConfirmation}
                        >
                          Delete
                        </Button>
                      </Grid>
                      <Grid item>
                        <Link href={`/admin/product/edit/${id}`} passHref>
                          <Button color="success" variant="contained">
                            Edit
                          </Button>
                        </Link>
                      </Grid>
                    </Grid>
                  </Box>
                </Box>

                <Box sx={{ mt: 3 }}>
                  <ProductDetails data={product} />
                </Box>
              </>
            )}

            <DeleteConfirmationDialog
              isOpen={deleteConfirmation.isOpen}
              onClose={() => {
                setDeleteConfirmation({ isOpen: false });
              }}
              id={deleteConfirmation.id}
              confirmDelete={onDelete}
            />
          </Container>
        </Box>
      </Layout>
    </>
  );
}

import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../../../components/admin/layout/Layout';
import Link from 'next/link';
import { Box, Container, Typography, Button, Grid } from '@mui/material';
import ProductTableSearchForm from '../../../components/admin/product/ProductSearchForm';
import ProductTable from '../../../components/admin/product/ProductTable';
import isLoggedIn from '../../../utils/isLoggedIn';
import {
  getProductList,
  deleteProduct,
} from '../../../services/productService';
import { getProductCategoryList } from '../../../services/productCategoryService';
import TableSkeleton from '../../../components/admin/skeleton/TableSkeleton';
import DeleteConfirmationDialog from '../../../components/admin/common/DeleteConfirmationDialog';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function ProductCategoryIndex() {
  const [isLoading, setIsLoading] = useState(true);

  const [productCategory, setProductCategory] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [tableSetting, setTableSetting] = useState({
    page: {
      number: 0,
      quantity: 10,
    },
    sort: {
      column: 'products.created_at',
      order: 'desc',
    },
    filter: {
      name: '',
      product_category_id: '',
    },
  });
  const [totalResult, setTotalResult] = useState(0);

  const [deleteConfirmation, setDeleteConfirmation] = useState({
    isOpen: false,
    id: null,
  });

  const fetchData = async () => {
    setIsLoading(true);

    const response = await getProductList(tableSetting);

    const responseData = response.data;

    if (responseData.success) {
      setTableData(responseData.data.list);
      setTotalResult(responseData.data.totalResult);
      setIsLoading(false);

      return;
    }
  };

  useEffect(() => {
    fetchData();
  }, [null, tableSetting]);

  const [productCategoryTableSetting, setProductCategoryTableSetting] =
    useState({
      page: {
        number: 0,
        quantity: 10,
      },
      sort: {
        column: 'created_at',
        order: 'desc',
      },
      filter: {
        name: '',
      },
    });

  const handleDeleteConfirmation = (id) => {
    setDeleteConfirmation({ ...deleteConfirmation, isOpen: true, id: id });
  };

  const fetchProductCategoryData = async () => {
    const response = await getProductCategoryList(productCategoryTableSetting);

    const responseData = response.data;

    if (responseData.success) {
      if (responseData.data.list.length != 0) {
        if (productCategoryTableSetting.page.number == 0) {
          setProductCategory(responseData.data.list);
        } else {
          setProductCategory([...productCategory, ...responseData.data.list]);
        }
      }

      return;
    }
  };

  useEffect(() => {
    fetchProductCategoryData();
  }, [null, productCategoryTableSetting]);

  const onDelete = async () => {
    const response = await deleteProduct({ id: deleteConfirmation.id });

    const responseData = response.data;
    if (responseData.success) {
      fetchData();
    }

    return response;
  };

  return (
    <>
      <Head>
        <title>Product | Admin Portal</title>
      </Head>
      <Layout>
        <Box
          sx={{
            py: 8,
          }}
        >
          <Container maxWidth={false}>
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
              }}
            >
              <Typography sx={{ m: 1 }} variant="h4">
                Product
              </Typography>
              <Box sx={{ m: 1 }}>
                <Grid container spacing={1} justifyContent="flex-end">
                  <Grid item>
                    <Link href={'/admin/product/create'} passHref>
                      <Button color="primary" variant="contained">
                        Create Product
                      </Button>
                    </Link>
                  </Grid>
                </Grid>
              </Box>
            </Box>

            <Box sx={{ mt: 3 }}>
              <ProductTableSearchForm
                data={tableSetting.filter}
                onSubmit={(data) => {
                  setTableSetting({ ...tableSetting, filter: data });
                }}
                productCategory={productCategory}
                setTablePageSetting={(data) => {
                  setProductCategoryTableSetting({
                    ...productCategoryTableSetting,
                    page: { number: data, quantity: 10 },
                  });
                }}
                setTableSetting={(data) => {
                  setProductCategoryTableSetting({
                    ...productCategoryTableSetting,
                    filter: data,
                    page: { number: 0, quantity: 10 },
                  });
                }}
              />
            </Box>

            <Box sx={{ mt: 3 }}>
              {isLoading ? (
                <TableSkeleton />
              ) : (
                <ProductTable
                  tableData={tableData}
                  totalResult={totalResult}
                  tableSetting={tableSetting}
                  handleChange={(data) => {
                    setTableSetting(data);
                  }}
                  handleDelete={(id) => {
                    handleDeleteConfirmation(id);
                  }}
                />
              )}
            </Box>

            <DeleteConfirmationDialog
              isOpen={deleteConfirmation.isOpen}
              onClose={() => {
                setDeleteConfirmation({ isOpen: false });
              }}
              id={deleteConfirmation.id}
              confirmDelete={onDelete}
            />
          </Container>
        </Box>
      </Layout>
    </>
  );
}

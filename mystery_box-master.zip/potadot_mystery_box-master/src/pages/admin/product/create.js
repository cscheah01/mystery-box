import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../../../components/admin/layout/Layout';
import Link from 'next/link';
import { Box, Container, Typography, Button, Grid } from '@mui/material';
import CreateProductForm from '../../../components/admin/product/CreateProductForm';
import isLoggedIn from '../../../utils/isLoggedIn';
import { createProduct } from '../../../services/productService';
import { getProductCategoryList } from '../../../services/productCategoryService';
import { useRouter } from 'next/router';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function CreateProduct() {
  const router = useRouter();

  const [productCategory, setProductCategory] = useState([]);
  const [tableSetting, setTableSetting] = useState({
    page: {
      number: 0,
      quantity: 10,
    },
    sort: {
      column: 'created_at',
      order: 'desc',
    },
    filter: {
      name: '',
    },
  });

  const onSubmit = async (data) => {
    const response = await createProduct(data);
    const responseData = response.data;

    if (responseData.success) {
      router.push(`/admin/product/${responseData.data.id}`);
    }

    return response;
  };

  const fetchData = async () => {
    const response = await getProductCategoryList(tableSetting);

    const responseData = response.data;

    if (responseData.success) {
      if (responseData.data.list.length != 0) {
        if (tableSetting.page.number == 0) {
          setProductCategory(responseData.data.list);
        } else {
          setProductCategory([...productCategory, ...responseData.data.list]);
        }
      }

      return;
    }
  };

  useEffect(() => {
    fetchData();
  }, [null, tableSetting]);

  return (
    <>
      <Head>
        <title>Create Product | Admin Portal</title>
      </Head>
      <Layout>
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            py: 8,
          }}
        >
          <Container maxWidth={false}>
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
              }}
            >
              <Typography sx={{ m: 1 }} variant="h4">
                Create Product
              </Typography>
              <Box sx={{ m: 1 }}>
                <Grid container spacing={1} justifyContent="flex-end">
                  <Grid item>
                    <Link href={'/admin/product'} passHref>
                      <Button color="dark" variant="contained">
                        Back
                      </Button>
                    </Link>
                  </Grid>
                </Grid>
              </Box>
            </Box>

            <Box sx={{ mt: 3 }}>
              <CreateProductForm
                onSubmit={onSubmit}
                productCategory={productCategory}
                setTablePageSetting={(data) => {
                  setTableSetting({
                    ...tableSetting,
                    page: { number: data, quantity: 10 },
                  });
                }}
                setTableSetting={(data) => {
                  setTableSetting({
                    ...tableSetting,
                    filter: data,
                    page: { number: 0, quantity: 10 },
                  });
                }}
              />
            </Box>
          </Container>
        </Box>
      </Layout>
    </>
  );
}

import React from 'react';
import Head from 'next/head';
import Layout from '../../components/admin/layout/Layout';
import isLoggedIn from '../../utils/isLoggedIn';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function Dashboard() {
  return (
    <>
      <Head>
        <title>Dashboard | Admin Portal</title>
      </Head>
      <Layout></Layout>
    </>
  );
}

import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../../../components/admin/layout/Layout';
import Link from 'next/link';
import { Box, Container, Typography, Button, Grid } from '@mui/material';
import StaffTableSearchForm from '../../../components/admin/staff/StaffTableSearchForm';
import StaffTable from '../../../components/admin/staff/StaffTable';
import isLoggedIn from '../../../utils/isLoggedIn';
import { getStaffList, deleteStaff } from '../../../services/staffService';
import TableSkeleton from '../../../components/admin/skeleton/TableSkeleton';
import DeleteConfirmationDialog from '../../../components/admin/common/DeleteConfirmationDialog';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function StaffIndex() {
  const [isLoading, setIsLoading] = useState(true);

  const [tableData, setTableData] = useState([]);
  const [tableSetting, setTableSetting] = useState({
    page: {
      number: 0,
      quantity: 10,
    },
    sort: {
      column: 'created_at',
      order: 'desc',
    },
    filter: {
      name: '',
      email: '',
    },
  });
  const [totalResult, setTotalResult] = useState(0);

  const [deleteConfirmation, setDeleteConfirmation] = useState({
    isOpen: false,
    id: null,
  });

  const fetchData = async () => {
    setIsLoading(true);

    const response = await getStaffList(tableSetting);

    const responseData = response.data;

    if (responseData.success) {
      setTableData(responseData.data.list);
      setTotalResult(responseData.data.totalResult);
      setIsLoading(false);

      return;
    }
  };

  useEffect(() => {
    fetchData();
  }, [null, tableSetting]);

  const handleDeleteConfirmation = (id) => {
    setDeleteConfirmation({ ...deleteConfirmation, isOpen: true, id: id });
  };

  const onDelete = async () => {
    const response = await deleteStaff({ id: deleteConfirmation.id });

    const responseData = response.data;
    if (responseData.success) {
      fetchData();
    }

    return response;
  };

  return (
    <>
      <Head>
        <title>Staff | Admin Portal</title>
      </Head>
      <Layout>
        <Box
          sx={{
            py: 8,
          }}
        >
          <Container maxWidth={false}>
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
              }}
            >
              <Typography sx={{ m: 1 }} variant="h4">
                Staff Management
              </Typography>
              <Box sx={{ m: 1 }}>
                <Grid container spacing={1} justifyContent="flex-end">
                  <Grid item>
                    <Link href={'/admin/staff/create'} passHref>
                      <Button color="primary" variant="contained">
                        Create Staff
                      </Button>
                    </Link>
                  </Grid>
                </Grid>
              </Box>
            </Box>

            <Box sx={{ mt: 3 }}>
              <StaffTableSearchForm
                data={tableSetting.filter}
                onSubmit={(data) => {
                  setTableSetting({ ...tableSetting, filter: data });
                }}
              />
            </Box>

            <Box sx={{ mt: 3 }}>
              {isLoading ? (
                <TableSkeleton />
              ) : (
                <StaffTable
                  tableData={tableData}
                  totalResult={totalResult}
                  tableSetting={tableSetting}
                  handleChange={(data) => {
                    setTableSetting(data);
                  }}
                  handleDelete={(id) => {
                    handleDeleteConfirmation(id);
                  }}
                />
              )}
            </Box>

            <DeleteConfirmationDialog
              isOpen={deleteConfirmation.isOpen}
              onClose={() => {
                setDeleteConfirmation({ isOpen: false });
              }}
              id={deleteConfirmation.id}
              confirmDelete={onDelete}
            />
          </Container>
        </Box>
      </Layout>
    </>
  );
}

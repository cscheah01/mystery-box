import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../../../../components/admin/layout/Layout';
import Link from 'next/link';
import { Box, Container, Typography, Button, Grid } from '@mui/material';
import isLoggedIn from '../../../../utils/isLoggedIn';
import { useRouter } from 'next/router';
import {
  getStaffDetails,
  updateStaff,
} from '../../../../services/staffService';
import EditStaffForm from '../../../../components/admin/staff/EditStaffForm';
import DetailsSkeleton from '../../../../components/admin/skeleton/DetailsSkeleton';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function EditStaff() {
  const router = useRouter();
  const { id } = router.query;

  const [staff, setStaff] = useState({ id: id });
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = async () => {
    const response = await getStaffDetails(staff);
    return response;
  };

  useEffect(() => {
    setIsLoading(true);

    fetchData().then((response) => {
      const responseData = response.data;

      if (responseData.success) {
        setStaff(responseData.data);
        setIsLoading(false);

        return;
      }
    });
  }, []);

  const onSubmit = async (data) => {
    const response = await updateStaff(data);
    const responseData = response.data;

    if (responseData.success) {
      router.push(`/admin/staff/${responseData.data.id}`);
    }

    return response;
  };

  return (
    <>
      <Head>
        <title>Edit Staff | Admin Portal</title>
      </Head>
      <Layout>
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            py: 8,
          }}
        >
          <Container maxWidth={false}>
            {isLoading ? (
              <DetailsSkeleton />
            ) : (
              <>
                <Box
                  sx={{
                    alignItems: 'center',
                    display: 'flex',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    m: -1,
                  }}
                >
                  <Typography sx={{ m: 1 }} variant="h4">
                    Edit Staff
                  </Typography>
                  <Box sx={{ m: 1 }}>
                    <Grid container spacing={1} justifyContent="flex-end">
                      <Grid item>
                        <Link href={`/admin/staff/${id}`} passHref>
                          <Button color="dark" variant="contained">
                            Back
                          </Button>
                        </Link>
                      </Grid>
                    </Grid>
                  </Box>
                </Box>

                <Box sx={{ mt: 3 }}>
                  <EditStaffForm data={staff} onSubmit={onSubmit} />
                </Box>
              </>
            )}
          </Container>
        </Box>
      </Layout>
    </>
  );
}

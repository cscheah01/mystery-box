import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../../../../components/admin/layout/Layout';
import Link from 'next/link';
import { Box, Container, Typography, Button, Grid } from '@mui/material';
import isLoggedIn from '../../../../utils/isLoggedIn';
import { useRouter } from 'next/router';
import {
  getProductCategoryDetails,
  updateProductCategory,
} from '../../../../services/productCategoryService';
import EditProductCategoryForm from '../../../../components/admin/productCategory/EditProductCategoryForm';
import DetailsSkeleton from '../../../../components/admin/skeleton/DetailsSkeleton';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function EditProductCategory() {
  const router = useRouter();
  const { id } = router.query;

  const [productCategory, setProductCategory] = useState({ id: id });
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = async () => {
    const response = await getProductCategoryDetails(productCategory);
    return response;
  };

  useEffect(() => {
    setIsLoading(true);

    fetchData().then((response) => {
      const responseData = response.data;

      if (responseData.success) {
        setProductCategory(responseData.data);
        setIsLoading(false);

        return;
      }
    });
  }, []);

  const onSubmit = async (data) => {
    const response = await updateProductCategory(data);
    const responseData = response.data;

    if (responseData.success) {
      router.push(`/admin/product-category/${responseData.data.id}`);
    }

    return response;
  };

  return (
    <>
      <Head>
        <title>Edit Product Category | Admin Portal</title>
      </Head>
      <Layout>
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            py: 8,
          }}
        >
          <Container maxWidth={false}>
            {isLoading ? (
              <DetailsSkeleton />
            ) : (
              <>
                <Box
                  sx={{
                    alignItems: 'center',
                    display: 'flex',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    m: -1,
                  }}
                >
                  <Typography sx={{ m: 1 }} variant="h4">
                    Edit Product Category
                  </Typography>
                  <Box sx={{ m: 1 }}>
                    <Grid container spacing={1} justifyContent="flex-end">
                      <Grid item>
                        <Link href={`/admin/product-category/${id}`} passHref>
                          <Button color="dark" variant="contained">
                            Back
                          </Button>
                        </Link>
                      </Grid>
                    </Grid>
                  </Box>
                </Box>

                <Box sx={{ mt: 3 }}>
                  <EditProductCategoryForm
                    data={productCategory}
                    onSubmit={onSubmit}
                  />
                </Box>
              </>
            )}
          </Container>
        </Box>
      </Layout>
    </>
  );
}

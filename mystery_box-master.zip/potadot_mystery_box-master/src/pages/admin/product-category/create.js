import React from 'react';
import Head from 'next/head';
import Layout from '../../../components/admin/layout/Layout';
import Link from 'next/link';
import { Box, Container, Typography, Button, Grid } from '@mui/material';
import CreateProductCategoryForm from '../../../components/admin/productCategory/CreateProductCategoryForm';
import isLoggedIn from '../../../utils/isLoggedIn';
import { createProductCategory } from '../../../services/productCategoryService';
import { useRouter } from 'next/router';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function CreateProductCategory() {
  const router = useRouter();

  const onSubmit = async (data) => {
    const response = await createProductCategory(data);
    const responseData = response.data;

    if (responseData.success) {
      router.push(`/admin/product-category/${responseData.data.id}`);
    }

    return response;
  };

  return (
    <>
      <Head>
        <title>Create Product Category | Admin Portal</title>
      </Head>
      <Layout>
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            py: 8,
          }}
        >
          <Container maxWidth={false}>
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
              }}
            >
              <Typography sx={{ m: 1 }} variant="h4">
                Create Product Category
              </Typography>
              <Box sx={{ m: 1 }}>
                <Grid container spacing={1} justifyContent="flex-end">
                  <Grid item>
                    <Link href={'/admin/product-category'} passHref>
                      <Button color="dark" variant="contained">
                        Back
                      </Button>
                    </Link>
                  </Grid>
                </Grid>
              </Box>
            </Box>

            <Box sx={{ mt: 3 }}>
              <CreateProductCategoryForm onSubmit={onSubmit} />
            </Box>
          </Container>
        </Box>
      </Layout>
    </>
  );
}

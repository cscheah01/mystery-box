import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../../../components/admin/layout/Layout';
import Link from 'next/link';
import { Box, Container, Typography, Button, Grid } from '@mui/material';
import BoxTableSearchForm from '../../../components/admin/box/BoxTableSearchForm';
import BoxTable from '../../../components/admin/box/BoxTable';
import isLoggedIn from '../../../utils/isLoggedIn';
import { getBoxList, deleteBox } from '../../../services/boxService';
import { getBoxCategoryList } from '../../../services/boxCategoryService';
import TableSkeleton from '../../../components/admin/skeleton/TableSkeleton';
import DeleteConfirmationDialog from '../../../components/admin/common/DeleteConfirmationDialog';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function BoxIndex() {
  const [isLoading, setIsLoading] = useState(true);

  const [boxCategory, setBoxCategory] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [tableSetting, setTableSetting] = useState({
    page: {
      number: 0,
      quantity: 10,
    },
    sort: {
      column: 'boxes.created_at',
      order: 'desc',
    },
    filter: {
      name: '',
      box_category_id: '',
    },
  });
  const [totalResult, setTotalResult] = useState(0);

  const [deleteConfirmation, setDeleteConfirmation] = useState({
    isOpen: false,
    id: null,
  });

  const fetchData = async () => {
    setIsLoading(true);

    const response = await getBoxList(tableSetting);

    const responseData = response.data;

    if (responseData.success) {
      setTableData(responseData.data.list);
      setTotalResult(responseData.data.totalResult);
      setIsLoading(false);

      return;
    }
  };

  useEffect(() => {
    fetchData();
  }, [null, tableSetting]);

  const [boxCategoryTableSetting, setBoxCategoryTableSetting] = useState({
    page: {
      number: 0,
      quantity: 10,
    },
    sort: {
      column: 'created_at',
      order: 'desc',
    },
    filter: {
      name: '',
    },
  });

  const fetchBoxCategoryData = async () => {
    const response = await getBoxCategoryList(boxCategoryTableSetting);

    const responseData = response.data;

    if (responseData.success) {
      if (responseData.data.list.length != 0) {
        if (boxCategoryTableSetting.page.number == 0) {
          setBoxCategory(responseData.data.list);
        } else {
          setBoxCategory([...boxCategory, ...responseData.data.list]);
        }
      }

      return;
    }
  };

  useEffect(() => {
    fetchBoxCategoryData();
  }, [null, boxCategoryTableSetting]);

  const handleDeleteConfirmation = (id) => {
    setDeleteConfirmation({ ...deleteConfirmation, isOpen: true, id: id });
  };

  const onDelete = async () => {
    const response = await deleteBox({ id: deleteConfirmation.id });

    const responseData = response.data;
    if (responseData.success) {
      fetchData();
    }

    return response;
  };

  return (
    <>
      <Head>
        <title>Box | Admin Portal</title>
      </Head>
      <Layout>
        <Box
          sx={{
            py: 8,
          }}
        >
          <Container maxWidth={false}>
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
              }}
            >
              <Typography sx={{ m: 1 }} variant="h4">
                Box
              </Typography>
              <Box sx={{ m: 1 }}>
                <Grid container spacing={1} justifyContent="flex-end">
                  <Grid item>
                    <Link href={'/admin/box/create'} passHref>
                      <Button color="primary" variant="contained">
                        Create Box
                      </Button>
                    </Link>
                  </Grid>
                </Grid>
              </Box>
            </Box>

            <Box sx={{ mt: 3 }}>
              <BoxTableSearchForm
                data={tableSetting.filter}
                onSubmit={(data) => {
                  setTableSetting({ ...tableSetting, filter: data });
                }}
                boxCategory={boxCategory}
                setBoxCategoryTablePageSetting={(data) => {
                  setBoxCategoryTableSetting({
                    ...boxCategoryTableSetting,
                    page: { number: data, quantity: 10 },
                  });
                }}
                setBoxCategoryTableSetting={(data) => {
                  setBoxCategoryTableSetting({
                    ...boxCategoryTableSetting,
                    filter: data,
                    page: { number: 0, quantity: 10 },
                  });
                }}
              />
            </Box>

            <Box sx={{ mt: 3 }}>
              {isLoading ? (
                <TableSkeleton />
              ) : (
                <BoxTable
                  tableData={tableData}
                  totalResult={totalResult}
                  tableSetting={tableSetting}
                  handleChange={(data) => {
                    setTableSetting(data);
                  }}
                  handleDelete={(id) => {
                    handleDeleteConfirmation(id);
                  }}
                />
              )}
            </Box>

            <DeleteConfirmationDialog
              isOpen={deleteConfirmation.isOpen}
              onClose={() => {
                setDeleteConfirmation({ isOpen: false });
              }}
              id={deleteConfirmation.id}
              confirmDelete={onDelete}
            />
          </Container>
        </Box>
      </Layout>
    </>
  );
}

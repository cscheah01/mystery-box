import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../../../components/admin/layout/Layout';
import Link from 'next/link';
import { Box, Container, Typography, Button, Grid } from '@mui/material';
import CreateBoxForm from '../../../components/admin/box/CreateBoxForm';
import isLoggedIn from '../../../utils/isLoggedIn';
import { createBox } from '../../../services/boxService';
import { getBoxCategoryList } from '../../../services/boxCategoryService';
import { getProductList } from '../../../services/productService';
import { useRouter } from 'next/router';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function CreateBox() {
  const router = useRouter();

  const [boxCategory, setBoxCategory] = useState([]);
  const [product, setProduct] = useState([]);
  const [boxCategoryTableSetting, setBoxCategoryTableSetting] = useState({
    page: {
      number: 0,
      quantity: 10,
    },
    sort: {
      column: 'created_at',
      order: 'desc',
    },
    filter: {
      name: '',
    },
  });

  const [productTableSetting, setProductTableSetting] = useState({
    page: {
      number: 0,
      quantity: 10,
    },
    sort: {
      column: 'created_at',
      order: 'desc',
    },
    filter: {
      name: '',
    },
  });

  const onSubmit = async (data) => {
    const response = await createBox(data);
    const responseData = response.data;

    if (responseData.success) {
      router.push(`/admin/box/${responseData.data.id}`);
    }

    return response;
  };

  const fetchBoxCategoryData = async () => {
    const response = await getBoxCategoryList(boxCategoryTableSetting);

    const responseData = response.data;

    if (responseData.success) {
      if (responseData.data.list.length != 0) {
        if (boxCategoryTableSetting.page.number == 0) {
          setBoxCategory(responseData.data.list);
        } else {
          setBoxCategory([...boxCategory, ...responseData.data.list]);
        }
      }

      return;
    }
  };

  useEffect(() => {
    fetchBoxCategoryData();
  }, [null, boxCategoryTableSetting]);

  const fetchProductData = async () => {
    const response = await getProductList(productTableSetting);

    const responseData = response.data;

    if (responseData.success) {
      if (responseData.data.list.length != 0) {
        if (productTableSetting.page.number == 0) {
          setProduct(responseData.data.list);
        } else {
          setProduct([...product, ...responseData.data.list]);
        }
      }

      return;
    }
  };

  useEffect(() => {
    fetchProductData();
  }, [null, productTableSetting]);

  return (
    <>
      <Head>
        <title>Create Box | Admin Portal</title>
      </Head>
      <Layout>
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            py: 8,
          }}
        >
          <Container maxWidth={false}>
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
              }}
            >
              <Typography sx={{ m: 1 }} variant="h4">
                Create Box
              </Typography>
              <Box sx={{ m: 1 }}>
                <Grid container spacing={1} justifyContent="flex-end">
                  <Grid item>
                    <Link href={'/admin/box'} passHref>
                      <Button color="dark" variant="contained">
                        Back
                      </Button>
                    </Link>
                  </Grid>
                </Grid>
              </Box>
            </Box>

            <Box sx={{ mt: 3 }}>
              <CreateBoxForm
                onSubmit={onSubmit}
                boxCategory={boxCategory}
                setBoxCategoryTablePageSetting={(data) => {
                  setBoxCategoryTableSetting({
                    ...boxCategoryTableSetting,
                    page: { number: data, quantity: 10 },
                  });
                }}
                setBoxCategoryTableSetting={(data) => {
                  setBoxCategoryTableSetting({
                    ...boxCategoryTableSetting,
                    filter: data,
                    page: { number: 0, quantity: 10 },
                  });
                }}
                product={product}
                setProductTablePageSetting={(data) => {
                  setProductTableSetting({
                    ...productTableSetting,
                    page: { number: data, quantity: 10 },
                  });
                }}
                setProductTableSetting={(data) => {
                  setProductTableSetting({
                    ...productTableSetting,
                    filter: data,
                    page: { number: 0, quantity: 10 },
                  });
                }}
              />
            </Box>
          </Container>
        </Box>
      </Layout>
    </>
  );
}

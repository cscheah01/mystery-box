import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../../../../components/admin/layout/Layout';
import Link from 'next/link';
import { Box, Container, Typography, Button, Grid } from '@mui/material';
import isLoggedIn from '../../../../utils/isLoggedIn';
import { useRouter } from 'next/router';
import { getBoxDetails, updateBox } from '../../../../services/boxService';
import { getBoxItem } from '../../../../services/boxItemService';
import { getBoxCategoryList } from '../../../../services/boxCategoryService';
import { getProductList } from '../../../../services/productService';
import EditBoxForm from '../../../../components/admin/Box/EditBoxForm';
import DetailsSkeleton from '../../../../components/admin/skeleton/DetailsSkeleton';

export const getServerSideProps = isLoggedIn(() => {
  return {
    props: {},
  };
});

export default function EditBox() {
  const router = useRouter();
  const { id } = router.query;

  const [box, setBox] = useState({ id: id });
  const [boxItem, setBoxItem] = useState({ id: id });
  const [boxCategory, setBoxCategory] = useState([]);
  const [product, setProduct] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = async () => {
    const response = await getBoxDetails(box);
    return response;
  };

  const fetchBoxItemData = async () => {
    const response = await getBoxItem(boxItem);
    return response;
  };

  useEffect(() => {
    setIsLoading(true);

    fetchData().then((response) => {
      const responseData = response.data;

      if (responseData.success) {
        setBox(responseData.data);

        return;
      }
    });

    fetchBoxItemData().then((response) => {
      const responseData = response.data;

      if (responseData.success) {
        setBoxItem(responseData.data);
        setIsLoading(false);

        return;
      }
    });
  }, []);

  const [boxCategoryTableSetting, setBoxCategoryTableSetting] = useState({
    page: {
      number: 0,
      quantity: 10,
    },
    sort: {
      column: 'created_at',
      order: 'desc',
    },
    filter: {
      name: '',
    },
  });

  const [productTableSetting, setProductTableSetting] = useState({
    page: {
      number: 0,
      quantity: 10,
    },
    sort: {
      column: 'created_at',
      order: 'desc',
    },
    filter: {
      name: '',
    },
  });

  const fetchBoxCategoryData = async () => {
    const response = await getBoxCategoryList(boxCategoryTableSetting);

    const responseData = response.data;

    if (responseData.success) {
      if (responseData.data.list.length != 0) {
        if (boxCategoryTableSetting.page.number == 0) {
          setBoxCategory(responseData.data.list);
        } else {
          setBoxCategory([...boxCategory, ...responseData.data.list]);
        }
      }

      return;
    }
  };

  useEffect(() => {
    fetchBoxCategoryData();
  }, [null, boxCategoryTableSetting]);

  const fetchProductData = async () => {
    const response = await getProductList(productTableSetting);

    const responseData = response.data;

    if (responseData.success) {
      if (responseData.data.list.length != 0) {
        if (productTableSetting.page.number == 0) {
          setProduct(responseData.data.list);
        } else {
          setProduct([...product, ...responseData.data.list]);
        }
      }

      return;
    }
  };

  useEffect(() => {
    fetchProductData();
  }, [null, productTableSetting]);

  const onSubmit = async (data) => {
    const response = await updateBox(id, data);
    const responseData = response.data;

    if (responseData.success) {
      router.push(`/admin/box/${responseData.data.id}`);
    }

    return response;
  };

  return (
    <>
      <Head>
        <title>Edit Box | Admin Portal</title>
      </Head>
      <Layout>
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            py: 8,
          }}
        >
          <Container maxWidth={false}>
            {isLoading ? (
              <DetailsSkeleton />
            ) : (
              <>
                <Box
                  sx={{
                    alignItems: 'center',
                    display: 'flex',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    m: -1,
                  }}
                >
                  <Typography sx={{ m: 1 }} variant="h4">
                    Edit Box
                  </Typography>
                  <Box sx={{ m: 1 }}>
                    <Grid container spacing={1} justifyContent="flex-end">
                      <Grid item>
                        <Link href={`/admin/box/${id}`} passHref>
                          <Button color="dark" variant="contained">
                            Back
                          </Button>
                        </Link>
                      </Grid>
                    </Grid>
                  </Box>
                </Box>

                <Box sx={{ mt: 3 }}>
                  <EditBoxForm
                    data={box}
                    onSubmit={onSubmit}
                    boxCategory={boxCategory}
                    product={product}
                    boxItem={boxItem}
                    setBoxCategoryTablePageSetting={(data) => {
                      setBoxCategoryTableSetting({
                        ...boxCategoryTableSetting,
                        page: { number: data, quantity: 10 },
                      });
                    }}
                    setBoxCategoryTableSetting={(data) => {
                      setBoxCategoryTableSetting({
                        ...boxCategoryTableSetting,
                        filter: data,
                        page: { number: 0, quantity: 10 },
                      });
                    }}
                    setProductTablePageSetting={(data) => {
                      setProductTableSetting({
                        ...productTableSetting,
                        page: { number: data, quantity: 10 },
                      });
                    }}
                    setProductTableSetting={(data) => {
                      setProductTableSetting({
                        ...productTableSetting,
                        filter: data,
                        page: { number: 0, quantity: 10 },
                      });
                    }}
                  />
                </Box>
              </>
            )}
          </Container>
        </Box>
      </Layout>
    </>
  );
}

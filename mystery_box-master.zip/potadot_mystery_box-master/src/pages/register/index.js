import React, { useEffect, useState } from 'react';
import Head from 'next/head';
import {
  Box,
  Typography,
  Container,
  Button,
  TextField,
} from '@mui/material';

import Link from 'next/link';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { postRequest } from '../../utils/apiHelper';
import PhoneInput from 'react-phone-input-2';
import Layout from '../../components/public/layout/Layout';

import 'react-phone-input-2/lib/material.css';

export default function Register() {
  const formik = useFormik({
    initialValues: {
      name: '',
      email: '',
      phone_number: '',
      password: '',
      password_confirmation: '',
    },
    validationSchema: Yup.object({
      name: Yup.string().required('Name is required'),
      email: Yup.string()
        .email('Must be a valid email')
        .required('Email is required'),
      phone_number: Yup.string().required('Phone number is required'),
      password: Yup.string().required('Password is required'),
      password_confirmation: Yup.string().oneOf(
        [Yup.ref('password'), null],
        'Passwords must match'
      ),
    }),
    onSubmit: async (values) => {
      // const response = await postRequest(`${config.appUrl}/api/login`, values);
      // const responseData = response.data;
      // if (responseData.success) {
      //   router.push('/');
      // }
    },
  });

  const [borderPhoneNumberField, setBorderPhoneNumberField] = useState(false);
  useEffect(() => {
    if (formik.errors.phone_number != null) {
      setBorderPhoneNumberField('#f44336');
    } else {
      setBorderPhoneNumberField('#ffffff');
    }
  }, [formik.errors.phone_number]);

  return (
    <>
      <Head>
        <title>Register</title>
      </Head>
      <Layout>
        <Container
          maxWidth={false}
          sx={{
            '&': {
              p: 0,
              backgroundColor: '#000000',
              pt: 20,
            },
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: '100vh',
          }}
        >
          <Box
            sx={{
              borderRadius: 5,
              backgroundColor: '#212121',
              p: 3,
              color: '#ffffff',
              mx: 2,
              width: { xs: '100%', md: '50%' },
            }}
          >
            <form onSubmit={formik.handleSubmit}>
              <Typography variant="h5" sx={{ textAlign: 'center' }}>
                Register
              </Typography>
              <TextField
                error={Boolean(formik.touched.name && formik.errors.name)}
                fullWidth
                helperText={formik.touched.name && formik.errors.name}
                label="Full Name"
                margin="normal"
                name="name"
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                type="text"
                value={formik.values.name}
                variant="outlined"
                InputLabelProps={{
                  shrink: true,
                  style: { color: '#ffffff', backgroundColor: '#212121' },
                }}
                sx={{
                  input: { color: '#ffffff' },
                  '& fieldset': {
                    borderColor: '#ffffff',
                  },
                }}
              />
              <PhoneInput
                containerStyle={{
                  color: '#ffffff',
                  marginTop: 2,
                  marginBottom: 1,
                }}
                inputStyle={{
                  backgroundColor: '#212121',
                  color: '#ffffff',
                  width: '100%',
                  borderColor: borderPhoneNumberField,
                }}
                dropdownStyle={{ color: '#000000' }}
                value={formik.values.phone_number}
                onChange={(phone) => {
                  formik.values.phone_number = phone;
                  formik.errors.phone_number = null;
                }}
              />
              <Typography
                sx={{
                  display:
                    formik.errors.phone_number != null &&
                    formik.touched.phone_number != null
                      ? 'block'
                      : 'none',
                  color: '#f44336',
                  fontWeight: 400,
                  lineHeight: 1.66,
                  fontSize: '0.75rem',
                  mt: '3px',
                  mr: 2,
                  mb: 0,
                  ml: 2,
                }}
              >
                {formik.errors.phone_number}
              </Typography>
              <TextField
                error={Boolean(formik.touched.email && formik.errors.email)}
                fullWidth
                helperText={formik.touched.email && formik.errors.email}
                label="Email Address"
                margin="normal"
                name="email"
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                type="email"
                value={formik.values.email}
                variant="outlined"
                InputLabelProps={{
                  shrink: true,
                  style: { color: '#ffffff', backgroundColor: '#212121' },
                }}
                sx={{
                  input: { color: '#ffffff' },
                  '& fieldset': {
                    borderColor: '#ffffff',
                  },
                }}
              />
              <TextField
                error={Boolean(
                  formik.touched.password && formik.errors.password
                )}
                fullWidth
                helperText={formik.touched.password && formik.errors.password}
                label="Password"
                margin="normal"
                name="password"
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                type="password"
                value={formik.values.password}
                variant="outlined"
                InputLabelProps={{
                  shrink: true,
                  style: { color: '#ffffff' },
                }}
                sx={{
                  input: { color: '#ffffff' },
                  '& fieldset': {
                    borderColor: 'white',
                    color: 'white',
                  },
                }}
              />
              <TextField
                error={Boolean(
                  formik.touched.password_confirmation &&
                    formik.errors.password_confirmation
                )}
                fullWidth
                helperText={
                  formik.touched.password_confirmation &&
                  formik.errors.password_confirmation
                }
                label="Password Confirmation"
                margin="normal"
                name="password_confirmation"
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                type="password_confirmation"
                value={formik.values.password_confirmation}
                variant="outlined"
                InputLabelProps={{
                  shrink: true,
                  style: { color: '#ffffff' },
                }}
                sx={{
                  input: { color: '#ffffff' },
                  '& fieldset': {
                    borderColor: 'white',
                    color: 'white',
                  },
                }}
              />
              <Box sx={{ py: 2 }}>
                <Button
                  color="primary"
                  disabled={formik.isSubmitting}
                  fullWidth
                  size="large"
                  type="submit"
                  variant="contained"
                >
                  Register
                </Button>
              </Box>
              <Typography
                gutterBottom
                variant="body2"
                sx={{ textAlign: 'center' }}
              >
                Already have an account?
                <Link passhref href={'login'} sx={{ ml: 2, color: '#3f51b5' }}>
                  Login account
                </Link>
              </Typography>
            </form>
          </Box>
        </Container>
      </Layout>
    </>
  );
}

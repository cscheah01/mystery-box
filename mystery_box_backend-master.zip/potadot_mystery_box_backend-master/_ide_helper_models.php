<?php

// @formatter:off
/**
 * A helper file for your Eloquent Models
 * Copy the phpDocs from this file to the correct Model,
 * And remove them from this file, to prevent double declarations.
 *
 * @author Barry vd. Heuvel <barryvdh@gmail.com>
 */


namespace App\Models{
/**
 * App\Models\Box
 *
 * @property int $id
 * @property string $name
 * @property string $image
 * @property int|null $box_category_id
 * @property string $price
 * @property int $is_available
 * @property \Illuminate\Support\Carbon|null $deleted_at
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\BoxCategory|null $boxCategory
 * @method static \Illuminate\Database\Eloquent\Builder|Box newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Box newQuery()
 * @method static \Illuminate\Database\Query\Builder|Box onlyTrashed()
 * @method static \Illuminate\Database\Eloquent\Builder|Box query()
 * @method static \Illuminate\Database\Eloquent\Builder|Box whereBoxCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Box whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Box whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Box whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Box whereImage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Box whereIsAvailable($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Box whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Box wherePrice($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Box whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|Box withTrashed()
 * @method static \Illuminate\Database\Query\Builder|Box withoutTrashed()
 */
	class Box extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\BoxCategory
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|BoxCategory newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BoxCategory newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BoxCategory query()
 * @method static \Illuminate\Database\Eloquent\Builder|BoxCategory whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BoxCategory whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BoxCategory whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BoxCategory whereUpdatedAt($value)
 */
	class BoxCategory extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\BoxItem
 *
 * @property int $id
 * @property int $box_id
 * @property int $product_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|BoxItem newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BoxItem newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BoxItem query()
 * @method static \Illuminate\Database\Eloquent\Builder|BoxItem whereBoxId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BoxItem whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BoxItem whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BoxItem whereProductId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BoxItem whereUpdatedAt($value)
 */
	class BoxItem extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\Product
 *
 * @property int $id
 * @property string $name
 * @property string $image
 * @property int|null $product_category_id
 * @property string $cost_price
 * @property string $value_price
 * @property string $description
 * @property int $is_available
 * @property string|null $deleted_at
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\ProductCategory|null $productCategory
 * @method static \Illuminate\Database\Eloquent\Builder|Product newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Product newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Product query()
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereCostPrice($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereDeletedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereImage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereIsAvailable($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereProductCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Product whereValuePrice($value)
 */
	class Product extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\ProductCategory
 *
 * @property int $id
 * @property string $name
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory query()
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ProductCategory whereUpdatedAt($value)
 */
	class ProductCategory extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\User
 *
 * @property int $id
 * @property string $name
 * @property string $email
 * @property \Illuminate\Support\Carbon|null $email_verified_at
 * @property string $password
 * @property string|null $remember_token
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\Laravel\Passport\Client[] $clients
 * @property-read int|null $clients_count
 * @property-read \Illuminate\Notifications\DatabaseNotificationCollection|\Illuminate\Notifications\DatabaseNotification[] $notifications
 * @property-read int|null $notifications_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\Laravel\Passport\Token[] $tokens
 * @property-read int|null $tokens_count
 * @method static \Database\Factories\UserFactory factory(...$parameters)
 * @method static \Illuminate\Database\Eloquent\Builder|User newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|User newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|User query()
 * @method static \Illuminate\Database\Eloquent\Builder|User whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereEmailVerifiedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User wherePassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereRememberToken($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereUpdatedAt($value)
 */
	class User extends \Eloquent {}
}

namespace App\Models{
/**
 * App\Models\UserInventory
 *
 * @property int $id
 * @property int $user_id
 * @property int $product_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|UserInventory newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|UserInventory newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|UserInventory query()
 * @method static \Illuminate\Database\Eloquent\Builder|UserInventory whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserInventory whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserInventory whereProductId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserInventory whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|UserInventory whereUserId($value)
 */
	class UserInventory extends \Eloquent {}
}


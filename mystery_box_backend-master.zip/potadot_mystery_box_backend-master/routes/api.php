<?php

use Illuminate\Http\Response;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\BoxApiController;
use App\Http\Controllers\Api\AuthApiController;
use App\Http\Controllers\Api\BoxCategoryApiController;
use App\Http\Controllers\Api\Admin\BoxAdminApiController;
use App\Http\Controllers\Api\Admin\StaffAdminApiController;
use App\Http\Controllers\Api\User\ProfileUserApiController;
use App\Http\Controllers\Api\Admin\BoxItemAdminApiController;
use App\Http\Controllers\Api\Admin\ProductAdminApiController;
use App\Http\Controllers\User\ShippingAddressUserApiController;
use App\Http\Controllers\Api\Admin\BoxCategoryAdminApiController;
use App\Http\Controllers\Api\Admin\ProductCategoryAdminApiController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('register', [AuthApiController::class, 'register']);
Route::post('login', [AuthApiController::class, 'login']);

Route::post('box-list', [BoxApiController::class, 'getList']);
Route::get('items/{id}', [BoxApiController::class, 'getBoxItemList']);
Route::get('box-details/{id}', [BoxApiController::class, 'show']);
Route::get('box-category-list', [BoxCategoryApiController::class, 'getList']);

Route::middleware('auth:api')->group(function () {
    Route::post('logout', [AuthApiController::class, 'logout']);


    Route::get('profile', function () {
        return response([
            "success" => true,
            "message" => "hi",
        ], Response::HTTP_OK);
    });


    Route::prefix('admin')->group(function () {
        Route::prefix('staff')->group(function () {
            Route::post('/', [StaffAdminApiController::class, 'store']);
            Route::post('table-list', [StaffAdminApiController::class, 'getList']);
            Route::get('{id}', [StaffAdminApiController::class, 'show']);
            Route::patch('{id}', [StaffAdminApiController::class, 'update']);
            Route::delete('{id}', [StaffAdminApiController::class, 'destroy']);
        });

        Route::prefix('box-category')->group(function () {
            Route::post('/', [BoxCategoryAdminApiController::class, 'store']);
            Route::post('table-list', [BoxCategoryAdminApiController::class, 'getList']);
            Route::get('{id}', [BoxCategoryAdminApiController::class, 'show']);
            Route::patch('{id}', [BoxCategoryAdminApiController::class, 'update']);
            Route::delete('{id}', [BoxCategoryAdminApiController::class, 'destroy']);
        });

        Route::prefix('box')->group(function () {
            Route::post('/', [BoxAdminApiController::class, 'store']);
            Route::post('table-list', [BoxAdminApiController::class, 'getList']);
            Route::get('{id}', [BoxAdminApiController::class, 'show']);
            Route::patch('{id}', [BoxAdminApiController::class, 'update']);
            Route::delete('{id}', [BoxAdminApiController::class, 'destroy']);
        });

        Route::prefix('box-item')->group(function () {
            Route::post('table-list', [BoxItemAdminApiController::class, 'getList']);
            Route::delete('{id}', [BoxItemAdminApiController::class, 'destroy']);
            Route::get('{id}', [BoxItemAdminApiController::class, 'show']);
        });

        Route::prefix('product-category')->group(function () {
            Route::post('/', [ProductCategoryAdminApiController::class, 'store']);
            Route::post('table-list', [ProductCategoryAdminApiController::class, 'getList']);
            Route::get('{id}', [ProductCategoryAdminApiController::class, 'show']);
            Route::patch('{id}', [ProductCategoryAdminApiController::class, 'update']);
            Route::delete('{id}', [ProductCategoryAdminApiController::class, 'destroy']);
        });

        Route::prefix('product')->group(function () {
            Route::post('/', [ProductAdminApiController::class, 'store']);
            Route::post('table-list', [ProductAdminApiController::class, 'getList']);
            Route::get('{id}', [ProductAdminApiController::class, 'show']);
            Route::patch('{id}', [ProductAdminApiController::class, 'update']);
            Route::delete('{id}', [ProductAdminApiController::class, 'destroy']);
        });
    });

    Route::prefix('user')->group(function () {
        Route::prefix('profile')->group(function () {
            Route::get('/', [ProfileUserApiController::class, 'show']);
        });
        Route::prefix('shipping_address')->group(function () {
            Route::get('/', [ShippingAddressUserApiController::class, 'show']);
        });
    });
});

<?php

namespace App\Repositories;

use App\Models\BoxCategory;

class BoxCategoryRepository extends Repository
{
    protected $_db;

    public function __construct(BoxCategory $boxCategory)
    {
        $this->_db = $boxCategory;
    }

    public function save($data)
    {
        $model = new BoxCategory;
        $model->name = $data['name'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->name = $data['name'] ?? $model->name;

        $model->update();
        return $model;
    }
}

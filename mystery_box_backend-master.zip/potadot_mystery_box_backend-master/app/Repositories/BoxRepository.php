<?php

namespace App\Repositories;

use App\Models\Box;

class BoxRepository extends Repository
{
    protected $_db;

    public function __construct(Box $box)
    {
        $this->_db = $box;
    }

    public function save($data)
    {
        $model = new Box;
        $model->name = $data['name'];
        $model->image = $data['image'];
        $model->box_category_id = $data['box_category_id'];
        $model->price = $data['price'];
        $model->description = $data['description'];
        $model->is_available = $data['is_available'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->name = $data['name'] ?? $model->name;
        $model->image = $data['image'] ?? $model->image;
        $model->box_category_id = $data['box_category_id'] ?? $model->box_category_id;
        $model->price = $data['price'] ?? $model->price;
        $model->description = $data['description'] ?? $model->description;
        $model->is_available = $data['is_available'] ?? $model->is_available;

        $model->update();
        return $model;
    }

    public function removeBoxCategoryIdByBoxCategoryId($boxCategoryId)
    {
        $model = $this->_db->where('box_category_id', '=', $boxCategoryId);

        $model->update([
            'box_category_id' => null,
        ]);

        return true;
    }
}

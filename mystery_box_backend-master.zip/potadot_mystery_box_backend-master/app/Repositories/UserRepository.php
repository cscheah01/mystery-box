<?php

namespace App\Repositories;

use App\Models\User;
use Illuminate\Support\Facades\Hash;


class UserRepository extends Repository
{
    protected $_db;

    public function __construct(User $user)
    {
        $this->_db = $user;
    }

    public function save($data)
    {
        $model = new User;
        $model->name = $data['name'];
        $model->email = $data['email'];
        $model->phone_number = $data['phone_number'] ?? null;
        $model->password = Hash::make($data['password']);
        $model->bank_name = $data['bank_name'];
        $model->bank_account_name = $data['bank_account_name'];
        $model->bank_account_number = $data['bank_account_number'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->name = $data['name'] ?? $model->name;
        $model->email = $data['email'] ?? $model->email;
        $model->phone_number = $data['phone_number'] ?? $model->phone_number;
        $model->password = ($data['password'] ?? false) ? Hash::make($data['password']) : $model->password;
        $model->bank_name = $data['bank_name'] ?? $model->bank_name;
        $model->bank_account_name = $data['bank_account_name'] ?? $model->bank_account_name;
        $model->bank_account_number = $data['bank_account_number'] ?? $model->bank_account_number;

        $model->update();
        return $model;
    }
}

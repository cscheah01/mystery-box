<?php

namespace App\Repositories;

use App\Models\ShippingAddress;

class ShippingAddressRepository extends Repository
{
    protected $_db;

    public function __construct(ShippingAddress $shippingAddress)
    {
        $this->_db = $shippingAddress;
    }

    public function save($data)
    {
        $model = new ShippingAddress;
        $model->user_id = $data['user_id'];
        $model->name = $data['name'];
        $model->phone_number = $data['phone_number'];
        $model->address = $data['address'];
        $model->state = $data['state'];
        $model->city = $data['city'];
        $model->postcode = $data['postcode'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->user_id = $data['user_id'] ?? $model->user_id;
        $model->name = $data['name'] ?? $model->name;
        $model->phone_number = $data['phone_number'] ?? $model->phone_number;
        $model->address = $data['address'] ?? $model->address;
        $model->state = $data['state'] ?? $model->state;
        $model->city = $data['city'] ?? $model->city;
        $model->postcode = $data['postcode'] ?? $model->postcode;

        $model->update();
        return $model;
    }

    public function getByUserId($userId)
    {
        $data = $this->_db
            ->where('user_id', '=', $userId)
            ->first();

        if (empty($data)) {
            return null;
        }
        return $data;
    }
}

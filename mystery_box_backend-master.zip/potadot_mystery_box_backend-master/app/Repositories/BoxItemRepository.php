<?php

namespace App\Repositories;

use Carbon\Carbon;
use App\Models\BoxItem;

class BoxItemRepository extends Repository
{
    protected $_db;

    public function __construct(BoxItem $boxItem)
    {
        $this->_db = $boxItem;
    }

    public function bulkSave($data, $boxId)
    {
        $boxItems = [];
        foreach ($data as $product) {
            $boxItems[] = [
                "box_id" => $boxId,
                "product_id" =>  $product,
                'created_at' => Carbon::now()->toDateTimeString(),
                'updated_at' => Carbon::now()->toDateTimeString()
            ];
        }

        $this->_db->insert($boxItems);
        return $data;
    }

    public function getAllByBoxId($boxId)
    {
        $data = $this->_db->leftJoin('products', 'box_items.product_id', 'products.id')
            ->leftJoin('product_categories', 'products.product_category_id', 'product_categories.id')
            ->select(
                "products.id",
                "products.name",
                "products.cost_price",
                "products.created_at",
                "products.image",
                "products.is_available",
                "products.product_category_id",
                "products.value_price",
                "product_categories.name as product_category_name",
            )
            ->where('box_items.box_id', '=', $boxId)
            ->where('is_available', '=', true)
            ->get();

        if (empty($data)) {
            return null;
        }
        return $data;
    }

    public function deleteByBoxId($boxId)
    {
        $this->_db->where('box_id', '=', $boxId)->delete();

        return true;
    }
}

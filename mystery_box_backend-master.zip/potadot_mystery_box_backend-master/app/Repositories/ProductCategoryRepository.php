<?php

namespace App\Repositories;

use App\Models\ProductCategory;

class ProductCategoryRepository extends Repository
{
    protected $_db;

    public function __construct(ProductCategory $productCategory)
    {
        $this->_db = $productCategory;
    }

    public function save($data)
    {
        $model = new ProductCategory;
        $model->name = $data['name'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->name = $data['name'] ?? $model->name;

        $model->update();
        return $model;
    }
}

<?php

namespace App\Repositories;

use App\Models\Product;

class ProductRepository extends Repository
{
    protected $_db;

    public function __construct(Product $product)
    {
        $this->_db = $product;
    }

    public function save($data)
    {
        $model = new Product;
        $model->name = $data['name'];
        $model->image = $data['image'];
        $model->product_category_id = $data['product_category_id'];
        $model->cost_price = $data['cost_price'];
        $model->value_price = $data['value_price'];
        $model->description = $data['description'];
        $model->is_available = $data['is_available'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->name = $data['name'] ?? $model->name;
        $model->image = $data['image'] ?? $model->image;
        $model->product_category_id = $data['product_category_id'] ?? $model->product_category_id;
        $model->cost_price = $data['cost_price'] ?? $model->cost_price;
        $model->value_price = $data['value_price'] ?? $model->value_price;
        $model->description = $data['description'] ?? $model->description;
        $model->is_available = $data['is_available'] ?? $model->is_available;

        $model->update();
        return $model;
    }

    public function removeProductCategoryIdByProductCategoryId($productCategoryId)
    {
        $model = $this->_db->where('product_category_id', '=', $productCategoryId);

        $model->update([
            'product_category_id' => null,
        ]);

        return true;
    }
}

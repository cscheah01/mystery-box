<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Box extends Model
{
    use HasFactory, SoftDeletes;

    public function boxCategory()
    {
        return $this->belongsTo(BoxCategory::class, 'box_category_id', 'id');
    }
}

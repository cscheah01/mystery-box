<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Api\Controller;
use App\Services\User\ShippingAddressUserApiService;

class ShippingAddressUserApiController extends Controller
{
    protected $_shippingAddressUserApiService;

    public function __construct(
        ShippingAddressUserApiService $shippingAddressUserApiService
    ) {
        $this->_shippingAddressUserApiService = $shippingAddressUserApiService;
    }

    public function show()
    {
        $result = $this->_shippingAddressUserApiService->getShippingAddressDetails();

        return $result;
    }
}

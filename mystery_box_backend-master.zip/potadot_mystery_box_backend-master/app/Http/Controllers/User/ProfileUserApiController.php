<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Api\Controller;
use App\Services\User\ProfileUserApiService;

class ProfileUserApiController extends Controller
{
    protected $_profileUserApiService;

    public function __construct(
        ProfileUserApiService $profileUserApiService
    ) {
        $this->_profileUserApiService = $profileUserApiService;
    }

    public function show()
    {
        $result = $this->_profileUserApiService->getProfileDetails();

        return $result;
    }
}

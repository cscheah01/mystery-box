<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Services\Api\AuthApiService;

class AuthApiController extends Controller
{
    protected $_authApiService;

    public function __construct(
        AuthApiService $authApiService
    ) {
        $this->_authApiService = $authApiService;
    }

    public function register(Request $request)
    {
        $data = $request->only([
            'name',
            'email',
            'password'
        ]);

        $result = $this->_authApiService->registerUser($data);

        return $result;
    }

    public function login(Request $request)
    {
        $data = $request->only([
            'email',
            'password'
        ]);

        $result = $this->_authApiService->loginUser($data);

        return $result;
    }

    public function logout()
    {
        $result = $this->_authApiService->logoutUser();

        return $result;
    }
}

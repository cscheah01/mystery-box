<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Services\Api\BoxApiService;

class BoxApiController extends Controller
{
    protected $_boxApiService;

    public function __construct(
        BoxApiService $boxApiService
    ) {
        $this->_boxApiService = $boxApiService;
    }

    public function getList(Request $request)
    {
        $data = $request->only([
            'box_category_id',
            'page',
        ]);

        $result = $this->_boxApiService->getAllBox($data);

        return $result;
    }

    public function getBoxItemList($id)
    {
        $result = $this->_boxApiService->getAllBoxItemByBoxId($id);

        return $result;
    }

    public function show($id)
    {
        $result = $this->_boxApiService->getBoxDetails($id);

        return $result;
    }
}

<?php

namespace App\Http\Controllers\Api;

use App\Services\Api\BoxCategoryApiService;

class BoxCategoryApiController extends Controller
{
    protected $_boxCategoryApiService;

    public function __construct(
        BoxCategoryApiService $boxCategoryApiService
    ) {
        $this->_boxCategoryApiService = $boxCategoryApiService;
    }

    public function getList()
    {
        $result = $this->_boxCategoryApiService->getAllBoxCategory();

        return $result;
    }
}

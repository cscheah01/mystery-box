<?php

namespace App\Http\Controllers\Api\Admin;

use Illuminate\Http\Request;
use App\Services\Api\Admin\ProductAdminApiService;

class ProductAdminApiController extends Controller
{
    protected $_productAdminApiService;

    public function __construct(
        ProductAdminApiService $productAdminApiService
    ) {
        $this->_productAdminApiService = $productAdminApiService;
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'name',
            'image',
            'product_category_id',
            'cost_price',
            'value_price',
            'description',
            'is_available',
        ]);

        $result = $this->_productAdminApiService->createProduct($data);

        return $result;
    }

    public function show($id)
    {
        $result = $this->_productAdminApiService->getProductDetails($id);

        return $result;
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
            'image',
            'product_category_id',
            'cost_price',
            'value_price',
            'description',
            'is_available',
        ]);

        $result = $this->_productAdminApiService->updateProduct($data, $id);

        return $result;
    }

    public function getList(Request $request)
    {
        $data = $request->only([
            'page.number',
            'page.quantity',
            'sort.column',
            'sort.order',
            'filter.name',
            'filter.product_category_id',
        ]);

        $result = $this->_productAdminApiService->getListData($data);

        return $result;
    }

    public function destroy($id)
    {
        $result = $this->_productAdminApiService->deleteById($id);

        return $result;
    }
}

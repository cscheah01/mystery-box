<?php

namespace App\Http\Controllers\Api\Admin;

use Illuminate\Http\Request;
use App\Services\Api\Admin\BoxItemAdminApiService;

class BoxItemAdminApiController extends Controller
{
    protected $_boxItemAdminApiService;

    public function __construct(
        BoxItemAdminApiService $boxItemAdminApiService
    ) {
        $this->_boxItemAdminApiService = $boxItemAdminApiService;
    }

    public function getList(Request $request)
    {
        $data = $request->only([
            'page.number',
            'page.quantity',
            'sort.column',
            'sort.order',
            'filter.name',
            'filter.id',
            'filter.product_category_id',
        ]);

        $result = $this->_boxItemAdminApiService->getListData($data);

        return $result;
    }

    public function destroy($id)
    {
        $result = $this->_boxItemAdminApiService->deleteById($id);

        return $result;
    }

    public function show($id)
    {
        $result = $this->_boxItemAdminApiService->getBoxItem($id);

        return $result;
    }
}

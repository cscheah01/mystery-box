<?php

namespace App\Http\Controllers\Api\Admin;

use Illuminate\Http\Request;
use App\Services\Api\Admin\BoxAdminApiService;

class BoxAdminApiController extends Controller
{
    protected $_boxAdminApiService;

    public function __construct(
        BoxAdminApiService $boxAdminApiService
    ) {
        $this->_boxAdminApiService = $boxAdminApiService;
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'name',
            'image',
            'box_category_id',
            'price',
            'description',
            'is_available',
            'box_items'
        ]);

        $result = $this->_boxAdminApiService->createBox($data);

        return $result;
    }

    public function show($id)
    {
        $result = $this->_boxAdminApiService->getBoxDetails($id);

        return $result;
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
            'image',
            'box_category_id',
            'price',
            'description',
            'is_available',
            'box_items'
        ]);

        $result = $this->_boxAdminApiService->updateBox($data, $id);

        return $result;
    }

    public function getList(Request $request)
    {
        $data = $request->only([
            'page.number',
            'page.quantity',
            'sort.column',
            'sort.order',
            'filter.name',
            'filter.box_category_id',
        ]);

        $result = $this->_boxAdminApiService->getListData($data);

        return $result;
    }

    public function destroy($id)
    {
        $result = $this->_boxAdminApiService->deleteById($id);

        return $result;
    }
}

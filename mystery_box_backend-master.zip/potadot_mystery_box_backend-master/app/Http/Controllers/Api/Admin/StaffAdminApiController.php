<?php

namespace App\Http\Controllers\Api\Admin;

use Illuminate\Http\Request;
use App\Services\Api\Admin\StaffAdminApiService;

class StaffAdminApiController extends Controller
{
    protected $_staffAdminApiService;

    public function __construct(
        StaffAdminApiService $staffAdminApiService
    ) {
        $this->_staffAdminApiService = $staffAdminApiService;
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'name',
            'email',
            'password',
        ]);

        $result = $this->_staffAdminApiService->createStaff($data);

        return $result;
    }

    public function show($id)
    {
        $result = $this->_staffAdminApiService->getStaffDetails($id);

        return $result;
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
            'email',
            'password',
        ]);

        if ($data['password'] == null) {
            unset($data['password']);
        }

        $result = $this->_staffAdminApiService->updateStaff($data, $id);

        return $result;
    }

    public function getList(Request $request)
    {
        $data = $request->only([
            'page.number',
            'page.quantity',
            'sort.column',
            'sort.order',
            'filter.name',
            'filter.email',
        ]);


        $result = $this->_staffAdminApiService->getListData($data);

        return $result;
    }

    public function destroy($id)
    {
        $result = $this->_staffAdminApiService->deleteById($id);

        return $result;
    }
}

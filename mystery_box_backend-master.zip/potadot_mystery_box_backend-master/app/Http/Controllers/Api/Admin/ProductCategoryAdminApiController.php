<?php

namespace App\Http\Controllers\Api\Admin;

use Illuminate\Http\Request;
use App\Services\Api\Admin\ProductCategoryAdminApiService;

class ProductCategoryAdminApiController extends Controller
{
    protected $_productCategoryAdminApiService;

    public function __construct(
        ProductCategoryAdminApiService $productCategoryAdminApiService
    ) {
        $this->_productCategoryAdminApiService = $productCategoryAdminApiService;
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'name',
        ]);

        $result = $this->_productCategoryAdminApiService->createProductCategory($data);

        return $result;
    }

    public function show($id)
    {
        $result = $this->_productCategoryAdminApiService->getProductCategoryDetails($id);

        return $result;
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
        ]);

        $result = $this->_productCategoryAdminApiService->updateProductCategory($data, $id);

        return $result;
    }

    public function getList(Request $request)
    {
        $data = $request->only([
            'page.number',
            'page.quantity',
            'sort.column',
            'sort.order',
            'filter.name',
        ]);

        $result = $this->_productCategoryAdminApiService->getListData($data);

        return $result;
    }

    public function destroy($id)
    {
        $result = $this->_productCategoryAdminApiService->deleteById($id);

        return $result;
    }
}

<?php

namespace App\Http\Controllers\Api\Admin;

use Illuminate\Http\Request;
use App\Services\Api\Admin\BoxCategoryAdminApiService;

class BoxCategoryAdminApiController extends Controller
{
    protected $_boxCategoryAdminApiService;

    public function __construct(
        BoxCategoryAdminApiService $boxCategoryAdminApiService
    ) {
        $this->_boxCategoryAdminApiService = $boxCategoryAdminApiService;
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'name',
        ]);

        $result = $this->_boxCategoryAdminApiService->createBoxCategory($data);

        return $result;
    }

    public function show($id)
    {
        $result = $this->_boxCategoryAdminApiService->getBoxCategoryDetails($id);

        return $result;
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
        ]);

        $result = $this->_boxCategoryAdminApiService->updateBoxCategory($data, $id);

        return $result;
    }

    public function getList(Request $request)
    {
        $data = $request->only([
            'page.number',
            'page.quantity',
            'sort.column',
            'sort.order',
            'filter.name',
        ]);

        $result = $this->_boxCategoryAdminApiService->getListData($data);

        return $result;
    }

    public function destroy($id)
    {
        $result = $this->_boxCategoryAdminApiService->deleteById($id);

        return $result;
    }
}

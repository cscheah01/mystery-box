<?php

namespace App\Services\Api;

use Exception;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Repositories\UserRepository;
use Laravel\Passport\TokenRepository;
use Illuminate\Support\Facades\Validator;

class AuthApiService extends Service
{
    protected $_userRepository;

    public function __construct(
        UserRepository $userRepository
    ) {
        $this->_userRepository = $userRepository;
    }

    public function registerUser($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string',
                'email' => 'required|email|max:255|unique:users,email',
                'password' => 'required|min:8',
            ]);

            if ($validator->fails()) {
                return response([
                    "success" => false,
                    "message" => $validator->errors(),
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $user = $this->_userRepository->save($data);

            DB::commit();
            return response([
                "success" => true,
                "message" => "Successfully registered."
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to register.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function loginUser($data)
    {
        try {
            $validator = Validator::make($data, [
                'email' => 'required',
                'password' => 'required',
            ]);

            if (auth()->attempt($data)) {
                $token = auth()->user()->createToken('passport_token')->accessToken;

                return response([
                    "success" => true,
                    "message" => "Successfully login.",
                    "data" => [
                        'token' => $token
                    ]
                ], Response::HTTP_OK);
            }

            return response([
                "success" => false,
                "message" => "Invalid email or password.",
            ], Response::HTTP_UNAUTHORIZED);
        } catch (Exception $e) {

            return response([
                "success" => false,
                "message" => 'Fail to login.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function logoutUser()
    {
        try {
            $access_token = auth()->user()->token();

            $tokenRepository = app(TokenRepository::class);
            $tokenRepository->revokeAccessToken($access_token->id);

            return response([
                "success" => true,
                "message" => "Successfully logout.",
            ], Response::HTTP_OK);
        } catch (Exception $e) {

            return response([
                "success" => false,
                "message" => 'Fail to logout.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}

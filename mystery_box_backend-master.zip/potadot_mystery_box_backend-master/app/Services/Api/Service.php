<?php

namespace App\Services\Api;

use Illuminate\Support\Facades\DB;

class Service
{
    public $_errorMessage = array();

    public function dataTable($page, $sort, $tableName, $tableJoins, $defaultWhere, $targetColumn, $optionalWhere, $optionalCustomWhere)
    {
        //pagination
        $page['quantity'] = $page['quantity'] ?? 10;
        $page['quantity'] = $page['quantity'] > 100 ? 100 : $page['quantity']; //check max cant exceed 100

        $page['number'] = $page['number'] ?? 0;

        //table offset
        $offset = ($page['number']) * $page['quantity'];

        //sorting
        $sort['column'] = $sort['column'] ?? $tableName . ".id";
        $sort['order'] = $sort['order'] ?? "desc";


        $table = DB::table($tableName);


        //join table
        if ($tableJoins) {
            foreach ($tableJoins as $key => $value) {
                $table->leftJoin($value['table'], $value['foreignKey'], "=", $value['primaryKey']);
            }
        }

        //select only the targeted column
        if ($targetColumn) {
            $table->select($targetColumn);
        }


        //default filter
        if ($defaultWhere) {
            $table->where($defaultWhere);
        }

        //optional custom filter
        if ($optionalCustomWhere) {
            $table->where($optionalCustomWhere);
        }

        //optional filter
        if ($optionalWhere) {
            foreach ($optionalWhere as $key => $value) {
                $table->where($key, 'LIKE', '%' . $value . '%');
            }
        }


        //total result count
        $result['totalResult'] = $table->count();

        //sorting
        $table->orderBy($sort['column'], $sort['order']);
        if ($sort['column'] != $tableName . ".id") {
            //optimization sorting speed
            $table->orderBy($tableName . ".id", $sort['order']);
        }

        //pagination
        $table->limit($page['quantity']);
        $table->offset($offset);


        $result['tableData'] = $table->get();

        return $result;
    }
}

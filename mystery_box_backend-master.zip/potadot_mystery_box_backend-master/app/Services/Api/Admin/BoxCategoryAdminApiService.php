<?php

namespace App\Services\Api\Admin;

use Exception;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\BoxCategoryRepository;
use App\Repositories\BoxRepository;

class BoxCategoryAdminApiService extends Service
{
    protected $_boxCategoryRepository;
    protected $_boxRepository;

    public function __construct(
        BoxCategoryRepository $boxCategoryRepository,
        BoxRepository $boxRepository
    ) {
        $this->_boxCategoryRepository = $boxCategoryRepository;
        $this->_boxRepository = $boxRepository;
    }

    public function createBoxCategory($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                return response([
                    "success" => false,
                    "message" => $validator->errors(),
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $boxCategory = $this->_boxCategoryRepository->save($data);

            DB::commit();
            return response([
                "success" => true,
                "message" => "Box category successfully added.",
                "data" => [
                    "id" => $boxCategory->id
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to add box category.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getBoxCategoryDetails($id)
    {
        DB::beginTransaction();

        try {
            $boxCategory = $this->_boxCategoryRepository->getById($id);

            if ($boxCategory == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            DB::commit();
            return response([
                "success" => true,
                "data" =>  $boxCategory->toArray()
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to get box category details.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    public function updateBoxCategory($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                return response([
                    "success" => false,
                    "message" => $validator->errors(),
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $boxCategory = $this->_boxCategoryRepository->update($data, $id);

            DB::commit();
            return response([
                "success" => true,
                "message" => "Box category successfully updated.",
                "data" => [
                    "id" => $boxCategory->id
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to update box category.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getListData($data)
    {
        try {
            $tableName = "box_categories";
            $tableJoins = null;
            $defaultWhere = null;
            $targetColumn = ['id', 'name', 'created_at'];
            $page = $data['page'] ?? null;
            $sort = $data['sort'] ?? null;
            $optionalCustomWhere = [];
            $optionalWhere = $data['filter'] ?? [];

            $result = $this->dataTable($page, $sort, $tableName, $tableJoins, $defaultWhere, $targetColumn, $optionalWhere, $optionalCustomWhere);

            return response([
                "success" => true,
                'data' => [
                    'list' => $result['tableData'],
                    'totalResult' => $result['totalResult'],
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            return response([
                "success" => false,
                'message' => 'Fail to get box category list.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $this->_boxRepository->removeBoxCategoryIdByBoxCategoryId($id);
            $boxCategory = $this->_boxCategoryRepository->deleteById($id);

            if ($boxCategory == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            DB::commit();
            return response([
                "success" => true,
                "message" => "Box Category successfully deleted.",
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                'message' => 'Fail to delete box category.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}

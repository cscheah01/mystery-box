<?php

namespace App\Services\Api\Admin;

use Exception;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Repositories\BoxItemRepository;

class BoxItemAdminApiService extends Service
{
    protected $_boxItemRepository;

    public function __construct(
        BoxItemRepository $boxItemRepository
    ) {
        $this->_boxItemRepository = $boxItemRepository;
    }

    public function getListData($data)
    {
        try {
            $tableName = "box_items";
            $tableJoins = array(
                array(
                    'table' => 'products',
                    'foreignKey' => 'box_items.product_id',
                    'primaryKey' => 'products.id'
                ),
                array(
                    'table' => 'product_categories',
                    'foreignKey' => 'products.product_category_id',
                    'primaryKey' => 'product_categories.id'
                )
            );
            $defaultWhere = null;
            $targetColumn = [
                'box_items.id',
                'box_items.box_id',
                'products.id as product_id',
                'products.name as product_name',
                'products.cost_price',
                'products.product_category_id',
                'products.value_price',
                'products.is_available',
                'products.created_at',
                'product_categories.name as product_category_name'
            ];
            $page = $data['page'] ?? null;
            $sort = $data['sort'] ?? null;
            $optionalCustomWhere = [];

            if (!empty($data['filter']['name'])) {
                $optionalCustomWhere[] = [
                    'products.name', 'LIKE', '%' . $data['filter']['name'] . '%',
                ];
            }

            if (!empty($data['filter']['id'])) {
                $optionalCustomWhere[] = [
                    'box_items.box_id', '=', $data['filter']['id'],
                ];
            }

            if (!empty($data['filter']['product_category_id'])) {
                $optionalCustomWhere[] = [
                    'products.product_category_id', '=', $data['filter']['product_category_id'],
                ];
            }

            $optionalWhere = [];

            $result = $this->dataTable($page, $sort, $tableName, $tableJoins, $defaultWhere, $targetColumn, $optionalWhere, $optionalCustomWhere);

            return response([
                "success" => true,
                'data' => [
                    'list' => $result['tableData'],
                    'totalResult' => $result['totalResult'],
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            return response([
                "success" => false,
                'message' => 'Fail to get box item list.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $boxItem = $this->_boxItemRepository->deleteById($id);

            if ($boxItem == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            DB::commit();
            return response([
                "success" => true,
                "message" => "Box item successfully deleted.",
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                'message' => 'Fail to delete box item.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getBoxItem($id)
    {
        DB::beginTransaction();

        try {
            $boxItem = $this->_boxItemRepository->getAllByBoxId($id);

            if ($boxItem == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            DB::commit();
            return response([
                "success" => true,
                "data" =>  $boxItem->toArray()
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to get box items.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function deleteByBoxId($boxId)
    {
        DB::beginTransaction();

        try {
            $boxItem = $this->_boxItemRepository->deleteByBoxId($boxId);

            if ($boxItem == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            DB::commit();
            return response([
                "success" => true,
                "message" => "Box item successfully deleted.",
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                'message' => 'Fail to delete box item.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}

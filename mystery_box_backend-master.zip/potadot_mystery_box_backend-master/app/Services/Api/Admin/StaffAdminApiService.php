<?php

namespace App\Services\Api\Admin;

use Exception;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Validator;

class StaffAdminApiService extends Service
{
    protected $_userRepository;

    public function __construct(
        UserRepository $userRepository
    ) {
        $this->_userRepository = $userRepository;
    }

    public function createStaff($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'email' => 'required|string|max:255|unique:users,email',
                'password' => 'required|min:8',
            ]);

            if ($validator->fails()) {
                return response([
                    "success" => false,
                    "message" => $validator->errors(),
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $user = $this->_userRepository->save($data);

            DB::commit();
            return response([
                "success" => true,
                "message" => "Staff successfully added.",
                "data" => [
                    "id" => $user->id
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to add staff.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getStaffDetails($id)
    {
        DB::beginTransaction();

        try {
            $user = $this->_userRepository->getById($id);

            if ($user == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            DB::commit();
            return response([
                "success" => true,
                "data" =>  $user->toArray()
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to get staff details.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    public function updateStaff($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'email' => 'required|string|max:255|unique:users,email,' . $id,
                'password' => 'nullable|min:8',
            ]);

            if ($validator->fails()) {
                return response([
                    "success" => false,
                    "message" => $validator->errors(),
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $user = $this->_userRepository->update($data, $id);

            DB::commit();
            return response([
                "success" => true,
                "message" => "Staff successfully updated.",
                "data" => [
                    "id" => $user->id
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to update staff.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getListData($data)
    {
        try {
            $tableName = "users";
            $tableJoins = null;
            $defaultWhere = null;
            $targetColumn = ['id', 'name', 'email', 'created_at'];
            $page = $data['page'] ?? null;
            $sort = $data['sort'] ?? null;
            $optionalCustomWhere = [];
            $optionalWhere = $data['filter'] ?? [];

            $result = $this->dataTable($page, $sort, $tableName, $tableJoins, $defaultWhere, $targetColumn, $optionalWhere, $optionalCustomWhere);

            return response([
                "success" => true,
                'data' => [
                    'list' => $result['tableData'],
                    'totalResult' => $result['totalResult'],
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            return response([
                "success" => false,
                'message' => 'Fail to get staff list.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $user = $this->_userRepository->deleteById($id);

            if ($user == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            DB::commit();
            return response([
                "success" => true,
                "message" => "Staff successfully deleted.",
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                'message' => 'Fail to delete staff.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}

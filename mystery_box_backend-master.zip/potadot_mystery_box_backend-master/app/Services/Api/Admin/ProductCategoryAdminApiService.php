<?php

namespace App\Services\Api\Admin;

use Exception;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\ProductCategoryRepository;
use App\Repositories\ProductRepository;

class ProductCategoryAdminApiService extends Service
{
    protected $_productCategoryRepository;
    protected $_productRepository;

    public function __construct(
        ProductCategoryRepository $productCategoryRepository,
        ProductRepository $productRepository
    ) {
        $this->_productCategoryRepository = $productCategoryRepository;
        $this->_productRepository = $productRepository;
    }

    public function createProductCategory($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                return response([
                    "success" => false,
                    "message" => $validator->errors(),
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $productCategory = $this->_productCategoryRepository->save($data);

            DB::commit();
            return response([
                "success" => true,
                "message" => "Product category successfully added.",
                "data" => [
                    "id" => $productCategory->id
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to add product category.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getProductCategoryDetails($id)
    {
        DB::beginTransaction();

        try {
            $productCategory = $this->_productCategoryRepository->getById($id);

            if ($productCategory == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            DB::commit();
            return response([
                "success" => true,
                "data" =>  $productCategory->toArray()
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to get product category details.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    public function updateProductCategory($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                return response([
                    "success" => false,
                    "message" => $validator->errors(),
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $productCategory = $this->_productCategoryRepository->update($data, $id);

            DB::commit();
            return response([
                "success" => true,
                "message" => "Product category successfully updated.",
                "data" => [
                    "id" => $productCategory->id
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to update product category.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getListData($data)
    {
        try {
            $tableName = "product_categories";
            $tableJoins = null;
            $defaultWhere = null;
            $targetColumn = ['id', 'name', 'created_at'];
            $page = $data['page'] ?? null;
            $sort = $data['sort'] ?? null;
            $optionalCustomWhere = [];
            $optionalWhere = $data['filter'] ?? [];

            $result = $this->dataTable($page, $sort, $tableName, $tableJoins, $defaultWhere, $targetColumn, $optionalWhere, $optionalCustomWhere);

            return response([
                "success" => true,
                'data' => [
                    'list' => $result['tableData'],
                    'totalResult' => $result['totalResult'],
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            return response([
                "success" => false,
                'message' => 'Fail to get product category list.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $this->_productRepository->removeProductCategoryIdByProductCategoryId($id);

            $productCategory = $this->_productCategoryRepository->deleteById($id);

            if ($productCategory == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            DB::commit();
            return response([
                "success" => true,
                "message" => "Product category successfully deleted.",
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                'message' => 'Fail to delete product category.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}

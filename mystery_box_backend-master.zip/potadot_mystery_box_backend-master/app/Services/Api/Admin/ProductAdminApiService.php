<?php

namespace App\Services\Api\Admin;

use Image;
use Exception;
use Illuminate\Support\Str;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Repositories\ProductRepository;
use Illuminate\Support\Facades\Validator;

class ProductAdminApiService extends Service
{
    protected $_productRepository;

    public function __construct(
        ProductRepository $productRepository
    ) {
        $this->_productRepository = $productRepository;
    }

    public function createProduct($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'image' => 'required|mimes:jpeg,png,jpg|max:2048',
                'product_category_id' => 'required',
                'cost_price' => 'required|numeric|between: 0.00,99999999999.99',
                'value_price' => 'required|numeric|between: 0.00,99999999999.99',
                'description' => 'required|string|max:3500',
                'is_available' => 'required|boolean',
            ]);

            if ($validator->fails()) {
                return response([
                    "success" => false,
                    "message" => $validator->errors(),
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            if (isset($data['image']) && !empty($data['image'])) {
                $image = $data['image'];
                $fileName = $this->generateFileName();
                $fileExtension = $data['image']->extension();
                $fileName = $fileName . '.' . $fileExtension;

                $destinationPath = public_path('storage/product_image');
                File::ensureDirectoryExists($destinationPath);
                $image = Image::make($image->getRealPath());
                $image->resize(600, null, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . '/' . $fileName);

                $data['image'] = $fileName;
            } else {
                $data['image'] = null;
            }

            $product = $this->_productRepository->save($data);

            DB::commit();
            return response([
                "success" => true,
                "message" => "Product successfully added.",
                "data" => [
                    "id" => $product->id
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to add product.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function generateFileName()
    {
        return Str::random(5) . Str::uuid() . Str::random(5);
    }

    public function getProductDetails($id)
    {
        DB::beginTransaction();

        try {
            $product = $this->_productRepository->getById($id);

            if ($product->product_category_id != null) {
                $product->product_category = $product->productCategory->name;
            }

            $product->image_url = asset('storage/product_image/' . $product->image);

            if ($product == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            DB::commit();
            return response([
                "success" => true,
                "data" =>  $product->toArray()
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to get product details.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    public function updateProduct($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'image' => 'nullable|max:2048',
                'product_category_id' => 'nullable',
                'cost_price' => 'required|numeric|between: 0.00,99999999999.99',
                'value_price' => 'required|numeric|between: 0.00,99999999999.99',
                'description' => 'required|string|max:3500',
                'is_available' => 'required|boolean',
            ]);

            if ($validator->fails()) {
                return response([
                    "success" => false,
                    "message" => $validator->errors(),
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $product = $this->_productRepository->getById($id);

            if (isset($data['image']) && !empty($data['image'])) {
                $image = $data['image'];
                $fileName = $this->generateFileName();
                $fileExtension = $data['image']->extension();
                $fileName = $fileName . '.' . $fileExtension;

                $destinationPath = public_path('storage/product_image');
                $image = Image::make($image->getRealPath());
                $image->resize(600, null, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . '/' . $fileName);

                File::delete($destinationPath . '/' . $product->image);

                $data['image'] = $fileName;
            }

            $product = $this->_productRepository->update($data, $id);

            DB::commit();
            return response([
                "success" => true,
                "message" => "Product successfully updated.",
                "data" => [
                    "id" => $product->id
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to update product.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getListData($data)
    {
        try {
            $tableName = "products";
            $tableJoins = array(
                array(
                    'table' => 'product_categories',
                    'foreignKey' => 'products.product_category_id',
                    'primaryKey' => 'product_categories.id'
                )
            );
            $defaultWhere = null;
            $targetColumn = ['products.id', 'products.name', 'products.image', 'products.product_category_id', 'product_categories.name as product_category_name', 'products.cost_price', 'products.value_price', 'products.is_available', 'products.created_at'];
            $page = $data['page'] ?? null;
            $sort = $data['sort'] ?? null;
            $optionalCustomWhere = [];

            if (!empty($data['filter']['name'])) {
                $optionalCustomWhere[] = [
                    'products.name', 'LIKE', '%' . $data['filter']['name'] . '%',
                ];
            }

            if (!empty($data['filter']['product_category_id'])) {
                $optionalCustomWhere[] = [
                    'products.product_category_id', '=', $data['filter']['product_category_id'],
                ];
            }

            $optionalWhere = [];

            $result = $this->dataTable($page, $sort, $tableName, $tableJoins, $defaultWhere, $targetColumn, $optionalWhere, $optionalCustomWhere);

            return response([
                "success" => true,
                'data' => [
                    'list' => $result['tableData'],
                    'totalResult' => $result['totalResult'],
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            return response([
                "success" => false,
                'message' => 'Fail to get product list.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $product = $this->_productRepository->deleteById($id);

            if ($product == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            DB::commit();
            return response([
                "success" => true,
                "message" => "Product successfully deleted.",
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                'message' => 'Fail to delete product.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}

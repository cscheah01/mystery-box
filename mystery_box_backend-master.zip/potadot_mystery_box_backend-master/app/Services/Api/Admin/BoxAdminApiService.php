<?php

namespace App\Services\Api\Admin;

use Image;
use Exception;
use Illuminate\Support\Str;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Repositories\BoxRepository;
use Illuminate\Support\Facades\File;
use App\Repositories\BoxItemRepository;
use Illuminate\Support\Facades\Validator;
use App\Services\Api\Admin\BoxItemAdminApiService;

class BoxAdminApiService extends Service
{
    protected $_boxRepository;
    protected $_boxItemRepository;
    protected $_boxItemAdminApiService;

    public function __construct(
        BoxRepository $boxRepository,
        BoxItemRepository $boxItemRepository,
        BoxItemAdminApiService $boxItemAdminApiService
    ) {
        $this->_boxRepository = $boxRepository;
        $this->_boxItemRepository = $boxItemRepository;
        $this->_boxItemAdminApiService = $boxItemAdminApiService;
    }

    public function createBox($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'image' => 'required|mimes:jpeg,png,jpg|max:2048',
                'box_category_id' => 'required',
                'price' => 'required|numeric|between: 0.00,99999999999.99',
                'description' => 'required|string|max:3500',
                'is_available' => 'required|boolean',
                'box_items' => 'nullable'
            ]);

            if ($validator->fails()) {
                return response([
                    "success" => false,
                    "message" => $validator->errors(),
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            if (isset($data['image']) && !empty($data['image'])) {
                $image = $data['image'];
                $fileName = $this->generateFileName();
                $fileExtension = $data['image']->extension();
                $fileName = $fileName . '.' . $fileExtension;

                $destinationPath = public_path('storage/box_image');
                File::ensureDirectoryExists($destinationPath);
                $image = Image::make($image->getRealPath());
                $image->resize(600, null, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . '/' . $fileName);

                $data['image'] = $fileName;
            }

            $box = $this->_boxRepository->save($data);

            if (!empty($data['box_items'])) {
                $boxItems =  $this->_boxItemRepository->bulkSave($data['box_items'], $box->id);
            }

            DB::commit();
            return response([
                "success" => true,
                "message" => "Box successfully added.",
                "data" => [
                    "id" => $box->id
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => "Fail to add box."
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function generateFileName()
    {
        return Str::random(5) . Str::uuid() . Str::random(5);
    }

    public function getBoxDetails($id)
    {
        DB::beginTransaction();

        try {
            $box = $this->_boxRepository->getById($id);

            if ($box == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            if ($box->box_category_id != null) {
                $box->box_category = $box->boxCategory->name;
            }

            $box->image_url = asset('storage/box_image/' . $box->image);

            DB::commit();
            return response([
                "success" => true,
                "data" =>  $box->toArray()
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to get box details.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    public function updateBox($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'image' => 'nullable|max:2048',
                'box_category_id' => 'required',
                'price' => 'required|numeric|between: 0.00,99999999999.99',
                'description' => 'required|string|max:3500',
                'is_available' => 'required|boolean',
                'box_items' => 'nullable'
            ]);

            if ($validator->fails()) {
                return response([
                    "success" => false,
                    "message" => $validator->errors(),
                ], Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $box = $this->_boxRepository->getById($id);

            if (isset($data['image']) && !empty($data['image'])) {
                $image = $data['image'];
                $fileName = $this->generateFileName();
                $fileExtension = $data['image']->extension();
                $fileName = $fileName . '.' . $fileExtension;

                $destinationPath = public_path('storage/box_image');
                $image = Image::make($image->getRealPath());
                $image->resize(600, null, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . '/' . $fileName);

                File::delete($destinationPath . '/' . $box->image);

                $data['image'] = $fileName;
            }

            $box = $this->_boxRepository->update($data, $id);

            $this->_boxItemAdminApiService->deleteByBoxId($id);
            if (array_key_exists('box_items', $data)) {
                $boxItems =  $this->_boxItemRepository->bulkSave($data['box_items'], $box->id);
            }

            DB::commit();
            return response([
                "success" => true,
                "message" => "Box successfully updated.",
                "data" => [
                    "id" => $box->id
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to update box.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getListData($data)
    {
        try {
            $tableName = "boxes";
            $tableJoins =
                array(
                    array(
                        'table' => 'box_categories',
                        'foreignKey' => 'boxes.box_category_id',
                        'primaryKey' => 'box_categories.id'
                    )
                );;
            $defaultWhere[] = [$tableName . '.deleted_at', '=', null];
            $targetColumn = ['boxes.id', 'boxes.name', 'boxes.box_category_id', 'box_categories.name as box_category_name', 'boxes.price', 'boxes.is_available', 'boxes.created_at'];
            $page = $data['page'] ?? null;
            $sort = $data['sort'] ?? null;
            $optionalCustomWhere = [];

            if (!empty($data['filter']['name'])) {
                $optionalCustomWhere[] = [
                    'boxes.name', 'LIKE', '%' . $data['filter']['name'] . '%',
                ];
            }

            if (!empty($data['filter']['box_category_id'])) {
                $optionalCustomWhere[] = [
                    'boxes.box_category_id', '=', $data['filter']['box_category_id'],
                ];
            }
            $optionalWhere = [];

            $result = $this->dataTable($page, $sort, $tableName, $tableJoins, $defaultWhere, $targetColumn, $optionalWhere, $optionalCustomWhere);

            return response([
                "success" => true,
                'data' => [
                    'list' => $result['tableData'],
                    'totalResult' => $result['totalResult'],
                ]
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            return response([
                "success" => false,
                'message' => 'Fail to get box list.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $box = $this->_boxRepository->deleteById($id);

            if ($box == null) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            DB::commit();
            return response([
                "success" => true,
                "message" => "Box successfully deleted.",
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                'message' => 'Fail to delete box.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}

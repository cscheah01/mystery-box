<?php

namespace App\Services\Api;

use App\Repositories\BoxItemRepository;
use Exception;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Repositories\BoxRepository;

class BoxApiService extends Service
{
    protected $_boxRepository;
    protected $_boxItemRepository;

    public function __construct(
        BoxRepository $boxRepository,
        BoxItemRepository $boxItemRepository
    ) {
        $this->_boxRepository = $boxRepository;
        $this->_boxItemRepository = $boxItemRepository;
    }

    public function getAllBox($data)
    {
        DB::beginTransaction();

        try {
            $data['quantity'] = 25;
            $data['page'] = ['number' => $data['page'], 'quantity' => $data['quantity']];
            $tableName = "boxes";
            $tableJoins = null;
            $defaultWhere[] = [$tableName . '.is_available', '=', true];
            $targetColumn = ['id', 'name', 'image', 'box_category_id', 'price', 'is_available'];
            $page = $data['page'] ?? null;
            $sort = $data['sort'] ?? null;
            $optionalCustomWhere = [];
            $optionalWhere = [];

            if (!empty($data['box_category_id'])) {
                $defaultWhere[] = [
                    $tableName . '.box_category_id', '=', $data['box_category_id'],
                ];
            }

            $boxes = $this->dataTable($page, $sort, $tableName, $tableJoins, $defaultWhere, $targetColumn, $optionalWhere, $optionalCustomWhere);

            if ($boxes == null) {
                return response([
                    "success" => true,
                    "data" =>  []
                ], Response::HTTP_OK);
            }

            $boxList = [];
            foreach ($boxes['tableData'] as $box) {
                $boxList[] = [
                    'id' => $box->id,
                    'name' => $box->name,
                    'image' => asset('storage/box_image/' . $box->image),
                    'box_category' => $box->box_category_id,
                    'price' => $box->price,
                    'is_available' => $box->is_available,
                ];
            }

            DB::commit();
            return response([
                "success" => true,
                "data" =>  $boxList
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to get box list.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getAllBoxItemByBoxId($boxId)
    {
        DB::beginTransaction();

        try {
            $boxItems = $this->_boxItemRepository->getAllByBoxId($boxId);

            if ($boxItems == null) {
                return response([
                    "success" => true,
                    "data" =>  []
                ], Response::HTTP_OK);
            }

            $boxItemList = [];
            foreach ($boxItems as $boxitem) {
                $boxItemList[] = [
                    'id' => $boxitem->id,
                    'name' => $boxitem->name,
                    'image' => asset('storage/product_image/' . $boxitem->image),
                    'product_category' => $boxitem->product_category_id ? $boxitem->product_category_name : null,
                    'price' => $boxitem->value_price,
                    'is_available' => $boxitem->is_available,
                ];
            }

            DB::commit();
            return response([
                "success" => true,
                "data" =>  $boxItemList
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to get box item list.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function getBoxDetails($id)
    {
        DB::beginTransaction();

        try {
            $box = $this->_boxRepository->getById($id);

            if ($box == null || $box->is_available == false) {
                return response([
                    "success" => false,
                ], Response::HTTP_NOT_FOUND);
            }

            if ($box->box_category_id != null) {
                $box->box_category = $box->boxCategory->name;
            }

            $box->image_url = asset('storage/box_image/' . $box->image);

            DB::commit();
            return response([
                "success" => true,
                "data" =>  $box->toArray()
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to get box details.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}

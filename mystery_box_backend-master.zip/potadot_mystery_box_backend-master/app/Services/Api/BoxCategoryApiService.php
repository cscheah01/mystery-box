<?php

namespace App\Services\Api;

use Exception;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Repositories\BoxCategoryRepository;

class BoxCategoryApiService extends Service
{
    protected $_boxCategoryRepository;

    public function __construct(
        BoxCategoryRepository $boxCategoryRepository
    ) {
        $this->_boxCategoryRepository = $boxCategoryRepository;
    }

    public function getAllBoxCategory()
    {
        DB::beginTransaction();

        try {
            $boxCategories = $this->_boxCategoryRepository->getAll();

            if ($boxCategories == null) {
                return response([
                    "success" => true,
                    "data" =>  []
                ], Response::HTTP_OK);
            }

            DB::commit();
            return response([
                "success" => true,
                "data" =>  $boxCategories
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to get box category list.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}

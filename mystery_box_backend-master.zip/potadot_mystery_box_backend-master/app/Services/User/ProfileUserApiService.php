<?php

namespace App\Services\User;

use Exception;
use App\Services\Api\Service;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Auth;

class ProfileUserApiService extends Service
{
    protected $_userRepository;

    public function __construct(
        UserRepository $userRepository
    ) {
        $this->_userRepository = $userRepository;
    }

    public function getProfileDetails()
    {
        DB::beginTransaction();

        try {
            $id = Auth::id();
            $profile = $this->_userRepository->getById($id);

            DB::commit();
            return response([
                "success" => true,
                "data" =>  $profile->toArray()
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to get profile details.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}

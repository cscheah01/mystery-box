<?php

namespace App\Services\User;

use Exception;
use App\Services\Api\Service;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Repositories\ShippingAddressRepository;

class ShippingAddressUserApiService extends Service
{
    protected $_shippingAddressRepository;

    public function __construct(
        ShippingAddressRepository $shippingAddressRepository
    ) {
        $this->_shippingAddressRepository = $shippingAddressRepository;
    }

    public function getShippingAddressDetails()
    {
        DB::beginTransaction();

        try {
            $userId = Auth::id();
            $shippingAddress = $this->_shippingAddressRepository->getByUserId($userId);

            DB::commit();
            return response([
                "success" => true,
                "data" =>  $shippingAddress
            ], Response::HTTP_OK);
        } catch (Exception $e) {
            DB::rollBack();

            return response([
                "success" => false,
                "message" => 'Fail to get shipping address details.'
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
